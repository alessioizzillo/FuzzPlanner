var w3gisp_js = 
{
	location0 :
	{
		location_mcc : "722",
		location_name : "Argentina",
		isp0 :
		{
			isp_mnc : "310",
			isp_mnc : "320",
			isp_mnc : "330",
			isp_name : "claro",
			dial_num : "*99#",
			apn : "igprs.claro.com.ar",
            username : "clarogprs",
            password : "clarogprs999"
		},
		isp1 :
		{
			isp_mnc : "010",
			isp_mnc : "070",
			isp_name : "Movistar",
			dial_num : "*99#",
			apn : "Internet.gprs.unifon.com.ar",
            username : "gprs",
            password : "gprs"
		},
		isp2 :
		{
			isp_mnc : "34",
			isp_mnc : "341",
			isp_mnc : "36",
			isp_name : "Personal",
			dial_num : "*99#",
			apn : "gprs.personal.com",
            username : "gprs",
            password : "gprs"
		}
	},
	
	location1 :
	{
		location_mcc : "283",
		location_name : "Armenia",
		isp0 :
		{
			isp_mnc : "10",
			isp_name : "Orange Armenia",
			dial_num : "*99#",
			apn : "internet.orange",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "01",
			isp_name : "Beeline",
			dial_num : "*99#",
			apn : "beeline.internet.am",
            username : "internet",
            password : "internet"
		},
		isp2 :
		{
			isp_mnc : "05",
			isp_name : "Vivacell-MTS",
			dial_num : "*99#",
			apn : "connect.vivacell.am",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_name : "Vivacell-MTS",
			dial_num : "*99#",
			apn : "inet.vivacell.am",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_name : "Vivacell-MTS",
			dial_num : "*99#",
			apn : "connect",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_name : "Vivacell-MTS",
			dial_num : "*99#",
			apn : "static.vivacell.am",
            username : "",
            password : ""
		}
	},	
	
	location2 :
	{
		location_mcc : "505",
		location_name : "Australia",
		isp0 :
		{
			isp_name : "Bigpond",
			dial_num : "*99**#",
			apn : "telstra.bigpond",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "06",
			isp_mnc : "12",
			isp_name : "Hutchison 3G",
			dial_num : "*99***1#",
			apn : "3netaccess",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "02",
			isp_mnc : "90",
			isp_name : "Optus",
			dial_num : "*99#",
			apn : "Internet",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "01",
			isp_mnc : "71",
			isp_mnc : "72",
			isp_name : "Telstra",
			dial_num : "*99#",
			apn : "telstra.internet",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "03",
			isp_name : "Vodafone(Australia)",
			dial_num : "*99#",
			apn : "vfinternet.au",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_name : "Vodafone(Australia)",
			dial_num : "*99#",
			apn : "vfprepaymbb",
            username : "web",
            password : "web"
		}
	},	
	
	location3 :
	{
		location_mcc : "232",
		location_name : "Austria",
        isp0 :
		{
			isp_mnc : "10",
			isp_mnc : "14",
			isp_name : "Hutchison 3G Austria GmbH (3 AT)",
			dial_num : "*99***1#",
			apn : "drei.at",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "01",
			isp_mnc : "09",
			isp_name : "Mobilkom Austria AG (A1)",
			dial_num : "*99#",
			apn : "A1.net",
            username : "ppp@A1plus.at",
            password : "ppp"
		},
        isp2 :
		{
			isp_mnc : "05",
			isp_name : "One",
			dial_num : "*99#",
			apn : "web.one.at",
            username : "",
            password : ""
		},
        isp3 :
		{
			isp_mnc : "07",
			isp_name : "tele.ring",
			dial_num : "*99#",
			apn : "web",
            username : "webppp@a1plus.at",
            password : "web"
		},
		isp4 :
		{
			isp_mnc : "03",
			isp_name : "T-Mobile, Max Online Business(Austria)",
			dial_num : "*99#",
			apn : "business.gprsinternet",
            username : "GPRS",
            password : ""
		},		
		isp5 :
		{
			isp_name : "Telering",
			dial_num : "*99#",
			apn : "web",
            username : "web@telering.at",
            password : "web"
		}		
	},	
    
	location4 :
	{
		location_mcc : "400",
		location_name : "Azerbaijan",
        isp0 :
		{
			isp_mnc : "01",
			isp_name : "Azersell Telekom",
			dial_num : "*99450",
			apn : "internet",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "02",
			isp_name : "Baksell",
			dial_num : "*99455",
			apn : "internet.bakcell.com",
            username : "",
            password : ""
		},
        isp2 :
		{
			isp_mnc : "04",
			isp_name : "Nar Mobile",
			dial_num : "*99470",
			apn : "nar",
            username : "Nar",
            password : "Nar"
		},
		isp3 :
		{
			isp_name : "Nar Mobile",
			dial_num : "*99477",
			apn : "nar",
            username : "Nar",
            password : "Nar"
		},
		isp4 :
		{
			isp_name : "Azersell Telekom",
			dial_num : "*99451",
			apn : "internet",
            username : "",
            password : ""
		}
	},		
	
	location20 :	
	{
		location_mcc : "426",
		location_name : "Bahrain",
		isp0 :
		{
			isp_mnc : "01",
			isp_name : "Batelco",
			dial_num : "*99#",
			apn : "internet.btcbahamas.com",
            username : "",
            password : ""
		}
	},	
		
	location21 :	
	{
		location_mcc : "206",
		location_name : "Belgium",
		isp0 :
		{
			isp_mnc : "10",
			isp_name : "Mobistar",
			dial_num : "*99#",
			apn : "mworld.be",
            username : "mobistar",
            password : "mobistar"
		},
        isp1 :
		{
			isp_mnc : "01",
			isp_name : "Proximus",
			dial_num : "*99#",
			apn : "internet.proximus.be",
            username : "",
            password : ""
		}
	},	
	
	location22 :	
	{
		location_mcc : "724",
		location_name : "Brazil",
		isp0 :
		{
			isp_mnc : "16",
			isp_name : "Brasil Telecom",
			dial_num : "*99***1#",
			apn : "brt.br",
            username : "brt",
            password : "brt"
		},
        isp1 :
		{
			isp_mnc : "05",
			isp_name : "Claro",
			dial_num : "*99***1#",
			apn : "bandalarga.claro.com.br",
            username : "claro",
            password : "claro"
		},	
		isp2 :
		{
			isp_mnc : "15",
			isp_mnc : "32",
			isp_mnc : "33",
			isp_mnc : "34",
			isp_name : "CTBC",
			dial_num : "*99***1#",
			apn : "ctbc.br",
            username : "ctbc",
            password : "1212"
		},
		isp3 :
		{
			isp_mnc : "31",
			isp_name : "Oi",
			dial_num : "*99***1#",
			apn : "gprs.oi.com.br",
            username : "Oi",
            password : "Oi"
		},
        isp4 :
		{
			isp_mnc : "07",
			isp_name : "Sercomtel",
			dial_num : "*99***1#",
			apn : "sercomtel.com.br",
            username : "sercomtel",
            password : "sercomtel"
		},
		isp5 :
		{
			isp_mnc : "02",
			isp_mnc : "03",
			isp_mnc : "04",
			isp_name : "TIM",
			dial_num : "*99***1#",
			apn : "tim.br",
            username : "tim",
            password : "tim"
		},	
		isp6 :
		{
			isp_mnc : "06",
			isp_mnc : "10",
			isp_mnc : "11",
			isp_mnc : "23",
			isp_name : "Vivo",
			dial_num : "*99***1#",
			apn : "zap.vivo.com.br",
            username : "vivo",
            password : "vivo"
		}
	},	
		
	location23 :	
	{
		location_mcc : "528",
		location_name : "Brunei",
		isp0 :
		{
			isp_mnc : "02",
			isp_name : "B-Mobile",
			dial_num : "*99#",
			apn : "bmobilewap",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_mnc : "11",
			isp_name : "DST Mobile",
			dial_num : "*99#",
			apn : "dst.internet",
            username : "",
            password : ""
		}
	},	
	
    location40 :
	{
		location_mcc : "456",
        location_name : "Cambodia",
		isp0 :
		{
			isp_mnc : "09",
			isp_name : "Beeline",
			dial_num : "*99#",
			apn : "beeline",
            username : "",
            password : ""
		},
		
		isp1 :
		{
			isp_mnc : "02",
			isp_name : "Hello",
			dial_num : "*99#",
			apn : "hello",
            username : "",
            password : ""
		},
		
		isp2 :
		{
			isp_mnc : "08",
			isp_name : "Metfone",
			dial_num : "*99#",
			apn : "metfone",
            username : "",
            password : ""
		},
		
		isp3 :
		{
			isp_mnc : "18",		
			isp_name : "Mfone",
			dial_num : "*99#",
			apn : "mfone",
            username : "",
            password : ""
		},
		
		isp4 :
		{
			isp_mnc : "01",	
			isp_name : "Mobitel",
			dial_num : "*99#",
			apn : "cellcard",
            username : "mobitel",
            password : "mobitel"
		},
		
		isp5 :
		{
			isp_mnc : "04",	
			isp_name : "QB",
			dial_num : "*99***1#",
			apn : "wap",
            username : "",
            password : ""
		},
				
		isp6 :
		{
			isp_mnc : "06",	
			isp_name : "Smart",
			dial_num : "*99#",
			apn : "smart",
            username : "",
            password : ""
		}
    },
    
    location41 :
    {
		location_mcc : "302",
        location_name : "Canada",
		isp0 :
		{
			isp_mnc : "610",
			isp_mnc : "640",
			isp_mnc : "880",
			isp_name : "Bell(New Stick)",
			dial_num : "*99***1#",
			apn : "inet.bell.ca",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_name : "Bell 7.2 SIM Based stick",
			dial_num : "*99***1#",
			apn : "inet.bell.ca",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_name : "Bell(EVDO), NO SIM",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "320",
			isp_name : "Mobilicity",
			dial_num : "*99***1#",
			apn : "internet.davewireless.com",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "720",
			isp_name : "Rogers(1)",
			dial_num : "*99***1#",
			apn : "internet.com",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_name : "Rogers(2)",
			dial_num : "*99***1#",
			apn : "internet.com",
            username : "wapuser1",
            password : "wap"
		},
		isp6 :
		{
			isp_mnc : "370",
			isp_name : "Fido(1)",
			dial_num : "*99***1#",
			apn : "internet.fido.ca",
            username : "",
            password : ""
		},
		isp7 :
		{
			isp_name : "Fido(2)",
			dial_num : "*99***1#",
			apn : "internet.fido.ca",
            username : "fido",
            password : "fido"
		},
		isp8 :
		{
			isp_name : "Telus(New Stick)",
			dial_num : "*99***1#",
			apn : "sp.telus.com",
            username : "",
            password : ""
		},
		isp9 :
		{
			isp_mnc : "220",
			isp_mnc : "221",
			isp_mnc : "361",
			isp_mnc : "653",
			isp_mnc : "657",
			isp_name : "Telus(New Stick)",
			dial_num : "*99***1#",
			apn : "isp.telus.com",
            username : "",
            password : ""
		},
		isp10 :
		{
			isp_name : "Telus(EVDO), NO SIM",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		},
		isp11 :
		{
			isp_mnc : "490",
			isp_name : "WindMobile",
			dial_num : "*99***1#",
			apn : "broadband.windmobile.ca",
            username : "",
            password : ""
		},
		isp12 :
		{
			isp_name : "Verizon",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		},
		isp13 :
		{
			isp_mnc : "500",
			isp_mnc : "510",
			isp_name : "Videotron",
			dial_num : "*99#",
			apn : "ihvm.vediotron",
            username : "",
            password : ""
		},
		isp14 :
		{
			isp_name : "AT&T",
			dial_num : "*99***1#",
			apn : "isp.cingular",
            username : "",
            password : ""
		},
		isp15 :
		{
			isp_name : "T-Mobile",
			dial_num : "*99***1#",
			apn : "epc.tmobile.com",
            username : "",
            password : ""
		},
		isp16 :
		{
			isp_name : "Bell",
			dial_num : "*99#",
			apn : "pda2.bell.ca",
            username : "",
            password : ""
		}
    },
    
	location42 :
	{
		location_mcc : "730",
        location_name : "Chile",
		isp0 :
		{
			isp_name : "Claro Prepago",
			dial_num : "*99#",
			apn : "bap.clarochile.cl",
            username : "",
            password : ""
		},
		
		isp1 :
		{
			isp_mnc : "03",
			isp_name : "Claro plan",
			dial_num : "*99#",
			apn : "bam.clarochile.cl",
            username : "clarochile",
            password : "clarochile"
		},
		
		isp2 :
		{
			isp_name : "EntelPcs Prepago",
			dial_num : "*99#",
			apn : "bam.entelpcs.cl",
            username : "entelpcs",
            password : "entelpcs"
		},
		
		isp3 :
		{
			isp_mnc : "01",
			isp_mnc : "10",			
			isp_name : "Entel Pcs Plan",
			dial_num : "*99#",
			apn : "imovil.entelpcs.cl",
            username : "entelpcs",
            password : "entelpcs"
		},
		
		isp4 :
		{
			isp_name : "Movistar Prepago",
			dial_num : "*99#",
			apn : "wap.tmovil.cl",
            username : "wap",
            password : "wap"
		},
		
		isp5 :
		{
			isp_mnc : "02",	
			isp_name : "Movistar Plan",
			dial_num : "*99#",
			apn : "web.tmovil.cl",
            username : "web",
            password : "web"
		}
    },
    
	location43 :
	{
		location_mcc : "460",
		location_name : "China",
		isp0 :
		{
			isp_mnc : "03",
			isp_mnc : "05",		
			isp_name : "China Telecom",
			dial_num : "#777",
			apn : "",
            username : "ctnet@mycdma.cn",
            password : "vnet.mobi"
		},
		isp1 :
		{
			isp_mnc : "01",
			isp_mnc : "06",		
			isp_name : "China Unicom",
			dial_num : "*99#",
			apn : "3gnet",
            username : "",
            password : ""
		},
        isp2 :
       {
			isp_mnc : "00",
			isp_mnc : "02",
			isp_mnc : "07",	   
            isp_name : "China Mobile",
			dial_num : "*98*1#",
			apn : "cmnet",
            username : "",
            password : ""
       }
	},
	
	location44 :
	{
		location_mcc : "230",
		location_name : "Czech",
		isp0 :
		{
			isp_mnc : "01",	
			isp_name : "T-Mobile CZ",
			dial_num : "*99#",
			apn : "internet.t-mobile.cz",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "02",
			isp_name : "Telefonica O2 CZ",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
        isp2 :
        {
			isp_mnc : "03",
			isp_mnc : "99",
            isp_name : "Vodafone CZ",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
        },
		isp3 :
		{
            isp_name : "Vodafone CZ prepaid",
			dial_num : "*99#",
			apn : "ointernet",
            username : "",
            password : ""
		}	   
	},
	
	location60 :
	{
		location_mcc : "238",
		location_name : "Denmark",
		isp0 :
		{
			isp_mnc : "06",
			isp_name : "3.dk",
			dial_num : "*99#",
			apn : "bredband.tre.dk",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_name : "Callme",
			dial_num : "*99#",
			apn : "websp",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_name : "CBB",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_name : "Fullrate",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_name : "Oister",
			dial_num : "*99#",
			apn : "data.dk",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_mnc : "01",
			isp_mnc : "10",
			isp_name : "TDC(LTE)",
			dial_num : "*99#",
			apn : "internet-lte",
            username : "",
            password : ""
		},
		isp6 :
		{
			isp_mnc : "01",
			isp_mnc : "10",
			isp_name : "TDC",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},		
		isp7 :
		{
			isp_mnc : "02",
			isp_mnc : "77",
			isp_name : "Telenor",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp8 :
		{
			isp_mnc : "20",
			isp_mnc : "30",
			isp_name : "Telia",
			dial_num : "*99#",
			apn : "www.internet.mtelia.dk",
            username : "",
            password : ""
		},
		isp9 :
		{
			isp_name : "Telmore",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		}
	},
	
	location61 :
	{
		location_mcc : "370",
		location_name : "Dominican Republic",
		isp0 :
		{
			isp_name : "Telmex",
			dial_num : "*99#",
			apn : "internet.ideasclaro.com.do",
            username : "",
            password : ""
		}
	},
    
	location80 :
	{
		location_mcc : "706",
		location_name : "El Salvador",
		isp0 :
		{
			isp_name : "Telmex",
			dial_num : "*99#",
			apn : "internet.ideasclaro",
            username : "",
            password : ""
		}
	},
    
	location81 :
	{
		location_mcc : "602",
		location_name : "Egypt",
		isp0 :
		{
			isp_mnc : "03",
			isp_name : "Etisalat",
			dial_num : "*99***1#",
			apn : "internet.etisalat",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "02",
			isp_name : "Vodafone",
			dial_num : "*99***1#",
			apn : "internet.vodafone.net",
            username : "internet",
            password : "internet"
		},
		isp2 :
		{
			isp_mnc : "01",
			isp_name : "Mobinil",
			dial_num : "*99***1#",
			apn : "mobinilweb",
            username : "",
            password : ""
		}
	},
    
    location100 :
    {
		location_mcc : "244",
		location_name : "Finland",
        isp0 :
		{
			isp_mnc : "21",
			isp_name : "Saunalahti",
			dial_num : "*99#",
			apn : "internet.saunalahti",
            username : "rlnet",
            password : "rlnet"
		},
		isp1 :
		{
			isp_mnc : "05",
			isp_name : "Elisa",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "91",
			isp_name : "Sonera",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
        isp3 :
		{
			isp_mnc : "12",
			isp_name : "DNA",
			dial_num : "*99#",
			apn : "data.dna.fi",
            username : "",
            password : ""
		}
	},
        
	location101 :
	{
		location_mcc : "208",
		location_name : "France",
        isp0 :
		{
			isp_mnc : "20",
			isp_mnc : "21",
			isp_mnc : "88",
			isp_name : "Bouygues Telecom",
			dial_num : "*99#",
			apn : "ebouygtel.com",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_name : "Orange M6 Mobile(France)",
			dial_num : "*99#",
			apn : "orange",
            username : "orange",
            password : "orange"
		},
		isp2 :
		{
			isp_name : "Orange(Enterprise)",
			dial_num : "*99#",
			apn : "internet-entreprise",
            username : "orange",
            password : "orange"
		},
		isp3 :
		{
			isp_mnc : "00",
			isp_mnc : "01",
			isp_mnc : "02",
			isp_name : "Orange(Personal)",
			dial_num : "*99#",
			apn : "orange.fr",
            username : "orange",
            password : "orange"
		},
		isp4 :
		{
			isp_mnc : "10",
			isp_mnc : "11",
			isp_mnc : "13",
			isp_name : "SFR",
			dial_num : "*99#",
			apn : "websfr",
            username : "",
            password : ""
		}
	},
    
    location120 :
	{
		location_mcc : "262",
		location_name : "Germany",
		isp0 :
		{
			isp_name : "blau.de",
			dial_num : "*99***1#",
			apn : "internet.eplus.de",
            username : "",
            password : "eplus"
		},
        isp1 :
		{
			isp_mnc : "03",
			isp_mnc : "05",
			isp_mnc : "77",
			isp_name : "E-plus",
			dial_num : "*99#",
			apn : "internet.eplus.de",
            username : "eplus",
            password : "gprs"
		},
        isp2 :
		{
			isp_mnc : "07",
			isp_mnc : "08",
			isp_mnc : "11",
			isp_name : "O2(Germany)",
			dial_num : "*99#",
			apn : "pinternet.interkom.de",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "01",
			isp_mnc : "06",
			isp_name : "T-Mobile(Germany)",
			dial_num : "*99#",
			apn : "internet.t-mobile",
            username : "t-mobile",
            password : "t-mobile"
		},
		isp4 :
		{
			isp_name : "T-Mobile Business(Germany)",
			dial_num : "*99#",
			apn : "internet.t-mobile",
            username : "tm",
            password : "t-mobile"
		},
		isp5 :
		{
			isp_mnc : "02",
			isp_mnc : "04",
			isp_mnc : "09",
			isp_name : "Vodafone(Germany)",
			dial_num : "*99#",
			apn : "web.vodafone.de",
            username : "",
            password : ""
		},
		isp6 :
		{
			isp_name : "1und1(DE)",
			dial_num : "*99***1#",
			apn : "mail.partner.de",
            username : "",
            password : ""
		},
		isp7 :
		{
			isp_name : "Kabel Deutschland Mobile (KD-Mobile)",
			dial_num : "*99#",
			apn : "surf.kabeld",
            username : "",
            password : ""
		}
	},
	location121 :
	{
		location_mcc : "704",
		location_name : "Guatemala",
		isp0 :
		{
			isp_mnc : "02",
			isp_name : "TIGO",
			dial_num : "*99#",
			apn : "broadband.tigo.gt",
            username : "",
            password : ""
		}
	},
       
    location140:
	{
		location_mcc : "454",
		location_name : "Hong Kong, China",		
        isp0 :
		{
			isp_mnc : "12",
			isp_name : "China Mobile Peoples Telephone",
			dial_num : "*99#",
            apn : "peoples.net",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_name : "Netvigator",
			dial_num : "",
			apn : "",
            username : "",
            password : ""       
		},
        isp2 :
		{
			isp_mnc : "10",
			isp_name : "New World",
			dial_num : "*99***1#",
            apn : "internet",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_name : "One2Free",
			dial_num : "*99***1#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "16",
			isp_name : "PCCW mobile",
			dial_num : "*99***1#",
			apn : "pccw",
            username : "",
            password : ""
		},
        isp5 :
		{
			isp_mnc : "19",
			isp_name : "PCCW Mobile(3G)",
			dial_num : "*99***1#",
            apn : "pccw",
            username : "",
            password : ""
		},
		isp6 :
		{
			isp_mnc : "06",
			isp_name : "Smartone-Vodafone",
			dial_num : "*99***1#",
			apn : "internet",
            username : "",
            password : ""
		},
        isp7 :
		{
			isp_mnc : "00",
			isp_name : "1010(One2Free)",
			dial_num : "*99***1#",
            apn : "hkcsl",
            username : "",
            password : ""
		},
		isp8 :
		{
			isp_mnc : "00",
			isp_name : "1010(4G)",
			dial_num : "*99#",
            apn : "lte.internet",
            username : "",
            password : ""
		},
		isp9 :
		{
			isp_mnc : "03",
			isp_name : "3 Hong Kong",
			dial_num : "*99***1#",
            apn : "ipc.three.com.hk",
            username : "",
            password : ""
		},
		isp10 :
		{
			isp_name : "3 Hong Kong",
			dial_num : "*99***1#",
            apn : "yahoo.three.com.hk",
            username : "",
            password : ""
		},
		isp11 :
		{
			isp_mnc : "04",
			isp_name : "3 2G",
			dial_num : "*99#",
            apn : "web-g.three.com.hk",
            username : "",
            password : ""
		}
	},
	
 	location141 :
	{
		location_mcc : "216",
		location_name : "Hungary",
		isp0 :
		{
			isp_name : "Digi (prepaid and postpaid)",
			dial_num : "*99#",
			apn : "digi",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_name : "Invitel (prepaid and postpaid)",
			dial_num : "*99#",
			apn : "invitel.mobilnet",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "01",
			isp_name : "Telenor (prepaid and postpaid)",
			dial_num : "*99#",
			apn : "net",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "30",
			isp_name : "T-Mobile (prepaid and postpaid)",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "70",
			isp_name : "Vodafone (postpaid)",
			dial_num : "*99#",
			apn : "internet.vodafone.net",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_name : "Vodafone (prepaid)",
			dial_num : "*99#",
			apn : "vitamax.internet.vodafone.net",
            username : "",
            password : ""
		}
	},
   
	location160 :
	{
		location_mcc : "404",
		location_mcc : "405",
		location_name : "India",
        isp0 :
		{
			isp_mnc : "02",
			isp_mnc : "03",
			isp_mnc : "10",
			isp_mnc : "31",
			isp_mnc : "45",
			isp_mnc : "49",
			isp_mnc : "70",
			isp_mnc : "90",
			isp_mnc : "92",
			isp_mnc : "93",
			isp_mnc : "96",
			isp_name : "AirTel",
			dial_num : "*99#",
			apn : "airtelgprs.com",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_name : "AirTel",
			dial_num : "*99***1#",
			apn : "airtelgprs.com",
            username : "",
            password : ""
		},
        isp2 :
		{
			isp_mnc : "21",
			isp_mnc : "27",
			isp_name : "BPL Mobile Mumbai",
			dial_num : "*99***1#",
			apn : "bplgprs.com",
            username : "bplmobile",
            password : ""
		},
		isp3 :
		{
			isp_name : "BPL Mobile Mumbai",
			dial_num : "*99#",
			apn : "mizone",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_name : "BSNL",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_name : "BSNL(2)",
			dial_num : "*99#",
			apn : "bsnlnet",
            username : "",
            password : ""
		},
		isp6 :
		{
			isp_mnc : "80",
			isp_name : "BSNL",
			dial_num : "*99***1#",
			apn : "celloneportal",
            username : "",
            password : ""
		},
		isp7 :
		{
			isp_name : "BSNL-CellOne",
			dial_num : "*99***1#",
			apn : "gprsnorth.cellone.in",
            username : "",
            password : ""
		},
		isp8 :
		{
			isp_mnc : "04",
			isp_mnc : "07",
			isp_mnc : "12",
			isp_mnc : "14",
			isp_mnc : "22",
			isp_mnc : "24",
			isp_mnc : "44",
			isp_mnc : "56",
			isp_mnc : "82",
			isp_mnc : "87",
			isp_mnc : "89",
			isp_mnc : "70",
			isp_mnc : "799",
			isp_mnc : "845",
			isp_mnc : "86",
			isp_mnc : "848",
			isp_mnc : "850",
			isp_name : "Idea",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
        isp9 :
		{
			isp_mnc : "78",
			isp_name : "Idea Cellular",
			dial_num : "*99***1#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp10 :
		{
			isp_name : "Idea Cellular",
			dial_num : "*99***1#",
			apn : "imis",
            username : "",
            password : ""
		},
        isp11 :
		{
			isp_name : "MTNL(1)",
			dial_num : "*99***1#",
			apn : "gprsmtnlmum",
            username : "",
            password : ""
		},
		isp12 :
		{
			isp_name : "MTNL Delhi (Connect)",
			dial_num : "*99#",
			apn : "gprsmtnldel",
            username : "mtnl",
            password : "mtnl123"
		},
		isp13 :
		{
			isp_name : "MTNL Delhi post paid",
			dial_num : "*99#",
			apn : "gprsmtnldel",
            username : "mtnl",
            password : "mtnl123"
		},
		isp14 :
		{
			isp_name : "MTNL Delhi pre paid",
			dial_num : "*99#",
			apn : "gprsppsdel",
            username : "mtnl",
            password : "mtnl123"
		},
		isp15 :
		{
			isp_name : "MTNL Mumbai 3G post paid",
			dial_num : "*99#",
			apn : "gprsmtnlmum",
            username : "mtnl",
            password : "mtnl123"
		},
		isp16 :
		{
			isp_name : "MTNL Mumbai 3G pre paid",
			dial_num : "*99#",
			apn : "gprsppsmum",
            username : "mtnl",
            password : "mtnl123"
		},
		isp17 :
		{
			isp_name : "MTS",
			dial_num : "#777",
			apn : "",
            username : "internet@internet.mtsindia.in",
            password : "mts"
		},
        isp18 :
		{
			isp_name : "Orange Hutch (Gujarat)",
			dial_num : "*99***1#",
			apn : "web",
            username : "",
            password : ""
		},
		isp19 :
		{
			isp_name : "Reliance Netconnect",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		},
		isp20 :
		{
			isp_name : "Reliance Netconnect",
			dial_num : "#777",
			apn : "internet",
            username : "",
            password : ""
		},
		isp21 :
		{
			isp_mnc : "09",
			isp_mnc : "36",
			isp_mnc : "52",
			isp_mnc : "67",
			isp_mnc : "83",
			isp_mnc : "01",
			isp_mnc : "03",
			isp_mnc : "04",
			isp_mnc : "05",
			isp_mnc : "09",
			isp_mnc : "10",
			isp_mnc : "13",
			isp_name : "Reliance Netconnect",
			dial_num : "*99#",
			apn : "",
            username : "",
            password : ""
		},
        isp22 :
		{
			isp_mnc : "14",
			isp_mnc : "44",
			isp_name : "Spice Telecom",
			dial_num : "*99#",
			apn : "simplyenjoy",
            username : "[mobile number]",
            password : "spice"
		},
		isp23 :
		{
			isp_mnc : "01",
			isp_mnc : "05",
			isp_mnc : "11",
			isp_mnc : "13",
			isp_mnc : "15",
			isp_mnc : "20",
			isp_mnc : "27",
			isp_mnc : "30",
			isp_mnc : "46",
			isp_mnc : "60",
			isp_mnc : "84",
			isp_mnc : "86",
			isp_mnc : "88",
			isp_mnc : "66",
			isp_mnc : "75",
			isp_name : "Vodafone India (Live)",
			dial_num : "*99***1#",
			apn : "www",
            username : "",
            password : ""
		},
		isp24 :
		{
			isp_mnc : "025",
			isp_mnc : "026",
			isp_mnc : "027",
			isp_mnc : "029",
			isp_mnc : "030",
			isp_mnc : "031",
			isp_mnc : "032",
			isp_mnc : "033",
			isp_mnc : "034",
			isp_mnc : "035",
			isp_mnc : "036",
			isp_mnc : "037",
			isp_mnc : "038",
			isp_mnc : "039",
			isp_mnc : "040",
			isp_mnc : "041",
			isp_mnc : "042",
			isp_mnc : "043",
			isp_mnc : "044",
			isp_mnc : "045",
			isp_mnc : "046",
			isp_mnc : "047",
			isp_name : "TATA DOCOMO",
			dial_num : "*99#",
			apn : "tatadocomo3g",
            username : "",
            password : ""
		},
		isp25 :
		{
			isp_name : "Tata Indicom Photon+",
			dial_num : "#777",
			apn : "",
            username : "internet",
            password : "internet"
		}
	},	
	
    location161 :
	{
		location_mcc : "510",
		location_name : "Indonesia",
		isp0 :
		{
			isp_mnc : "89",
			isp_name : "3",
			dial_num : "*99#",
			apn : "3data",
            username : "3data",
            password : "3data"
		},
		isp1 :
		{
			isp_mnc : "99",
			isp_name : "Aha",
			dial_num : "#777",
			apn : "",
            username : "aha@aha.co.id",
            password : "aha"
		},
		isp2 :
		{
			isp_mnc : "08",
			isp_name : "Axis",
			dial_num : "*99#",
			apn : "Axis",
            username : "Axis",
            password : "Axis"
		},
		isp3 :
		{
			isp_mnc : "07",
			isp_name : "Flexi",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "01",
			isp_name : "Indosat",
			dial_num : "*99#",
			apn : "indosatgprs",
            username : "indosat",
            password : "indosat"
		},
		isp5 :
		{
			isp_name : "Indosat IM2",
			dial_num : "*99#",
			apn : "Indosatm2",
            username : "",
            password : ""
		},		
        isp6 :
		{
			isp_mnc : "09",
			isp_name : "Smart",
			dial_num : "#777",
			apn : "",
            username : "smart",
            password : "smart"
		},
		isp7 :
		{
			isp_mnc : "10",
			isp_name : "Telkomsel Flash",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},		
		isp8 :
		{
			isp_mnc : "11",
			isp_name : "XL",
			dial_num : "*99#",
			apn : "www.xlgprs.net",
            username : "",
            password : ""
		}
	},
    
	location162 :
	{
		location_mcc : "272",
		location_name : "Ireland",
        isp0 :
		{
			isp_mnc : "03",
			isp_name : "Meteor",
			dial_num : "*99#",
			apn : "isp.mymeteor.ie",
            username : "my",
            password : "meteor"
		},
        isp1 :
		{
			isp_mnc : "02",
			isp_name : "O2(Ireland)",
			dial_num : "*99#",
			apn : "open.internet",
            username : "gprs",
            password : "gprs"
		},
        isp2 :
		{
			isp_mnc : "01",
			isp_name : "Vodafone(Ireland)",
			dial_num : "*99#",
			apn : "live.vodafone.com",
            username : "orange",
            password : "orange"
		},
        isp3 :
		{
			isp_mnc : "05",
			isp_name : "3 Ireland",
			dial_num : "*99***1#",
			apn : "3internet",
            username : "",
            password : ""
		},
        isp4 :
		{
			isp_mnc : "03",
			isp_name : "eMobile",
			dial_num : "",
			apn : "broadband.eircommbb.ie",
            username : "",
            password : ""
		}		
	},	
	
	location163 :
	{
		location_mcc : "425",
		location_name : "Israel",
		isp0 :
		{
			isp_mnc : "03",
			isp_name : "Pelephone",
			dial_num : "*99#",
			apn : "internet.pelephone.net.il",
            username : "pcl@3g",
            password : "pcl"
		}
	},	
	
	location164 :
	{
		location_mcc : "222",
		location_name : "Italy",
		isp0 :
		{
			isp_mnc : "99",
			isp_name : "3(piani dati)",
			dial_num : "*99#",
			apn : "datacard.tre.it",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_name : "3(piani voce)",
			dial_num : "*99#",
			apn : "tre.it",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_name : "BT Mobile",
			dial_num : "*99#",
			apn : "internet.btitalia.it",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_name : "Coopvoce",
			dial_num : "*99#",
			apn : "web.coopvoce.it",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_name : "Erg Mobile",
			dial_num : "*99#",
			apn : "mobile.erg.it",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_name : "Fastweb",
			dial_num : "*99#",
			apn : "datacard.fastweb.it",
            username : "",
            password : ""
		},
		isp6 :
		{
			isp_mnc : "07",
			isp_name : "Noverca",
			dial_num : "*99#",
			apn : "web.noverca.it",
            username : "",
            password : ""
		},
		isp7 :
		{
			isp_name : "Poste Mobile",
			dial_num : "*99#",
			apn : "internet.postemobile.it",
            username : "",
            password : ""
		},
		isp8 :
		{
			isp_mnc : "01",
			isp_name : "TIM",
			dial_num : "*99#",
			apn : "ibox.tim.it",
            username : "",
            password : ""
		},
		isp9 :
		{
			isp_name : "Tiscali Mobile",
			dial_num : "*99#",
			apn : "tiscalimobileinternet",
            username : "",
            password : ""
		},
		isp10 :
		{
			isp_mnc : "10",
			isp_name : "Vodafone",
			dial_num : "*99#",
			apn : "web.omnitel.it",
            username : "",
            password : ""
		},
		isp11 :
		{
			isp_mnc : "88",
			isp_name : "Wind",
			dial_num : "*99#",
			apn : "internet.wind",
            username : "",
            password : ""
		},
		isp12 :
		{
			isp_name : "Wind Biz",
			dial_num : "*99#",
			apn : "internet.wind.biz",
            username : "",
            password : ""
		}		
	},
	
	location180 :
	{
		location_mcc : "440",
		location_mcc : "441",
		location_name : "Japan",
		isp0 :
		{
			isp_mnc : "00",
			isp_name : "E-mobile",
			dial_num : "*99#",
			apn : "emb.ne.jp",
            username : "em",
            password : "em"
		},
		isp1 :
		{
			isp_mnc : "02",
			isp_mnc : "09",
			isp_mnc : "10",
			isp_mnc : "22",
			isp_mnc : "58",
			isp_mnc : "60",
			isp_name : "NTT DoCoMo Kansai",
			dial_num : "*99#",
			apn : "mopera.net",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "04",
			isp_mnc : "06",
			isp_mnc : "20",
			isp_mnc : "40",
			isp_mnc : "41",
			isp_mnc : "42",
			isp_mnc : "43",
			isp_mnc : "44",
			isp_mnc : "45",
			isp_mnc : "46",
			isp_mnc : "47",
			isp_mnc : "48",
			isp_mnc : "90",
			isp_mnc : "91",
			isp_mnc : "92",
			isp_mnc : "93",
			isp_mnc : "94",
			isp_mnc : "95",
			isp_mnc : "96",
			isp_mnc : "97",
			isp_mnc : "98",
			isp_name : "SoftBank",
			dial_num : "*99#",
			apn : "vodafone",
            username : "ai@vodafone",
            password : "vodafone"
		}
	},	
	
	location181 :
	{
		location_mcc : "416",
		location_name : "Jordan",
		isp0 :
		{
			isp_mnc : "77",
			isp_name : "Orange",
			dial_num : "*99***1#",
			apn : "net.orange.jo",
            username : "net",
            password : "net"
		},
		isp1 :
		{
			isp_name : "Orange",
			dial_num : "*99**#",
			apn : "net.orange.jo",
            username : "net",
            password : "net"
		},
		isp2 :
		{
			isp_mnc : "01",
			isp_name : "Zain",
			dial_num : "*99#",
			apn : "zain",
            username : "",
            password : ""
		}
	},	
	
	location200 :
	{
		location_mcc : "401",
		location_name : "Kazakhstan",
		isp0 :
		{
			isp_name : "Pathword",
			dial_num : "#777",
			apn : "",
            username : "Pathword",
            password : "Pathword"
		}
	},
	
	location201 :
	{
		location_mcc : "450",
		location_name : "Korea",
        isp0 :
		{
			isp_name : "KTF",
			dial_num : "*99#",
			apn : "default.ktfwing.com",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "05",
			isp_name : "SK Telecom",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		}
	},	
	
	location220 :
	{
		location_mcc : "247",
		location_name : "Latvia",
		isp0 :
		{
			isp_mnc : "01",
			isp_name : "LMT",
			dial_num : "*99#",
			apn : "open.lmt.lv",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "02",
			isp_name : "Tele2",
			dial_num : "*99#",
			apn : "mobileinternet.tele2.lv",
            username : "wap",
            password : "wap"
		},
		isp2 :
		{
			isp_mnc : "05",
			isp_name : "Bite",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		}
	},
	
	location221 :
	{
		location_mcc : "270",
		location_name : "Luxembourg",
		isp0 :
		{
			isp_mnc : "01",
			isp_name : "P&T Luxembourg",
			dial_num : "*99#",
			apn : "web.pt.lu",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "99",
			isp_name : "Voxmobile",
			dial_num : "*99#",
			apn : "vox.lu",
            username : "",
            password : ""
		}
	},	
    
	location240 :
	{
		location_mcc : "455",
		location_name : "Macau",
        isp0 :
		{
			isp_mnc : "01",
			isp_mnc : "04",
			isp_name : "CTM",
			dial_num : "*99#",
			apn : "ctm-mobile",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_name : "CTM",
			dial_num : "*99#",
			apn : "ctm-mobile.t",
            username : "",
            password : ""
		},
        isp2 :
		{
			isp_mnc : "03",
			isp_mnc : "05",		
			isp_name : "Hutchison",
			dial_num : "*99#",
			apn : "web.hutchisonmacau.com",
            username : "hutchison",
            password : "1234"
		},
		isp3 :
		{
			isp_mnc : "00",
			isp_name : "SmarTone",
			dial_num : "*99#",
			apn : "smartgprs",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_name : "CTM",
			dial_num : "*99**#",
			apn : "ctm-mobile-t",
            username : "",
            password : ""
		}
	},	
	
    location241 :
	{
		location_mcc : "502",
		location_name : "Malaysia",
		isp0 :
		{
			isp_mnc : "13",
			isp_mnc : "19",				
			isp_name : "Celcom",
			dial_num : "*99#",
			apn : "celcom3g",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_name : "Celcom TM(2G Postpaid)",
			dial_num : "*99#",
			apn : "celcom.net.my",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_name : "DiGi_1",
			dial_num : "*99#",
			apn : "diginet",
            username : "",
            password : ""
		},
        isp3 :
		{
			isp_mnc : "16",
			isp_name : "DiGi_2",
			dial_num : "*99#",
			apn : "3gdgnet",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "12",
			isp_name : "Maxis_unet",
			dial_num : "*99#",
			apn : "unet",
            username : "",
            password : ""
		},
        isp5 :
        {
            isp_name : "Maxis_bb",
			dial_num : "*99#",
			apn : "maxisbb",
            username : "maxis",
            password : "wap"
        },
        isp6 :
        {
            isp_name : "RedTone",
			dial_num : "*99#",
			apn : "redtone",
            username : "",
            password : ""
        },
        isp7 :
        {
			isp_mnc : "18",
            isp_name : "U-Mobile",
			dial_num : "*99***1#",
			apn : "my3g",
            username : "",
            password : ""
		}
	},	
    
    location242 :
    {
		location_mcc : "334",
        location_name : "Mexico",
		isp0 :
		{
			isp_mnc : "020",
			isp_name : "Telcel",
			dial_num : "*99#",
			apn : "internet.itelcel.com",
            username : "webgprs",
            password : "webgprs2002"
		},
		isp1 :
		{
			isp_name : "Iusacell and UNEFON",
			dial_num : "*99#",
			apn : "web.iusacellgsm.mx",
            username : "iusacellgsm",
            password : "iusacellgsm"
		},
		isp2 :
		{
			isp_name : "Movistar",
			dial_num : "*99#",
			apn : "internet.movistar.mx",
            username : "movistar",
            password : "movistar"
		}
    },
  
	location243 :
    {
		location_mcc : "259",
        location_name : "Moldova",
		isp0 :
		{
			isp_mnc : "01",
			isp_name : "orange",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "02",
			isp_name : "Moldcell",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "03",
			isp_mnc : "05",
			isp_mnc : "99",
			isp_name : "Unite",
			dial_num : "*99#",
			apn : "unie.internet.md",
            username : "",
            password : ""
		}
    },
	
	location244 :
    {
		location_mcc : "604",
        location_name : "Morocco",
		isp0 :
		{
			isp_mnc : "02",
			isp_name : "INWI",
			dial_num : "#777",
			apn : "",
            username : "wana",
            password : "wana"
		},
		isp1 :
		{
			isp_mnc : "01",
			isp_name : "MAROC TELECOM",
			dial_num : "*99#",
			apn : "www.iamgprs2.ma",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "00",
			isp_name : "MEDITEL",
			dial_num : "*99#",
			apn : "internet1.meditel.ma",
            username : "MEDINET",
            password : "MEDINET"
		}
    },
    
	location260 :
    {
		location_mcc : "204",
        location_name : "Netherlands",
        isp0 :
        {
			isp_mnc : "08",
			isp_mnc : "10",
            isp_name : "KPN_in",
            dial_num : "*99#",
            apn : "internet",
            username : "",
            password : ""
        },       
        isp1 :
        {
            isp_name : "KPN_por",
            dial_num : "*99***1#",
            apn : "portalmmm.nl",
            username : "",
            password : ""
        },
        isp2 :
        {
            isp_name : "Orange(Netherlands)",
            dial_num : "*99***1#",
            apn : "internet",
            username : "",
            password : ""
        },
		isp3 :
        {
			isp_mnc : "12",
            isp_name : "Telfort",
            dial_num : "*99***1#",
            apn : "internet",
            username : "telfortnl",
            password : "password"
        },
		isp4 :
        {
			isp_mnc : "16",
			isp_mnc : "20",
            isp_name : "T-Mobile(Netherlands)",
            dial_num : "*99#",
            apn : "internet-act",
            username : "",
            password : ""
        },
        isp5 :
        {
			isp_mnc : "04",
            isp_name : "Vodafone(Netherlands)",
            dial_num : "*99***1#",
            apn : "live.vodafone.com",
            username : "vodafone",
            password : "vodafone"
        }		
    },
	
	location261 :
    {
		location_mcc : "530",
        location_name : "New Zealand",
        isp0 :
        {
			isp_mnc : "01",
            isp_name : "Vodafone",
            dial_num : "*99#",
            apn : "www.vodafone.net.nz",
            username : "",
            password : ""
        },
		isp1 :
        {
			isp_mnc : "00",
			isp_mnc : "02",
            isp_name : "Telecom",
            dial_num : "*99#",
            apn : "internet.telecom.co.nz",
            username : "",
            password : ""
        },
		isp2 :
        {
			isp_mnc : "24",
            isp_name : "2 degree",
            dial_num : "*99#",
            apn : "internet",
            username : "",
            password : ""
        }
    },
	
	location262 :
    {
		location_mcc : "242",
        location_name : "Norway",
        isp0 :
        {
			isp_mnc : "02",
            isp_name : "Netcom Norway",
            dial_num : "*99#",
            apn : "internet.netcom.no",
            username : "",
            password : ""
        },
        isp1 :
        {
			isp_mnc : "01",
            isp_name : "Telenor Mobil Norway",
            dial_num : "*99#",
            apn : "telenor",
            username : "",
            password : ""
        },       
        isp2 :
        {
            isp_name : "Talkmore Norway",
            dial_num : "*99#",
            apn : "internet.netcom.no",
            username : "",
            password : ""
        }
    },
	
	location280 :
	{
		location_name : "Pakistan",
		isp0 :
		{
			isp_name : "PTCL",
            dial_num : "#777",
            apn : "",
            username : "vwireless@ptcl.com",
            password : "ptcl"
		}
	},
	
	location300 :
	{
		location_mcc : "714",
		location_name : "Panama",
		isp0 :
		{
			isp_mnc : "03",
			isp_name : "Claro Panama",
			dial_num : "*99#",
			apn : "web.claro.com.pa",
            username : "",
            password : ""
		}
	}, 	
	
	location301 :
	{
		location_mcc : "744",
		location_name : "Paraguay",
		isp0 :
		{
			isp_mnc : "02",
			isp_name : "Claro",
			dial_num : "*99#",
			apn : "internet.ctimovil.com.py",
            username : "ctigprs",
            password : "ctigprs999"
		},
        isp1 :
		{
			isp_mnc : "04",
			isp_name : "Telecel",
			dial_num : "*99#",
			apn : "broadband.tigo.py",
            username : "tigo",
            password : "tigo"
		}
	}, 
	
	location302 :
	{
		location_mcc : "716",
		location_name : "Peru",
        isp0 :
		{
			isp_mnc : "10",
			isp_name : "Claro(Peru)",
			dial_num : "*99#",
			apn : "ba.amx",
            username : "amx",
            password : "amx"
		},
		isp1 :
		{
			isp_mnc : "06",
			isp_name : "Movistar(Telefonica_1)",
			dial_num : "*99#",
			apn : "movistar.pe",
            username : "movistar@datos",
            password : "movistar"
		},       
        isp2 :
		{
			isp_name : "Movistar(Telefonica_2)",
			dial_num : "#99* o *99#",
			apn : "movisar.pe",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "07",
			isp_name : "Nextel",
			dial_num : "*99#",
			apn : "datacard.nextel.com.pe",
            username : "",
            password : ""
		}
	},          
    
    location303 :
	{
		location_mcc : "515",
		location_name : "Philippines",
		isp0 :
		{
			isp_name : "Globe Tattoo Sonic / 4G Flash (prepaid)",
			dial_num : "*99***1#",
			apn : "http.globe.com.ph",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_mnc : "02",
			isp_name : "Globe Tattoo Consumable Plans / Visibility (postpaid)",
			dial_num : "*99***1#",
			apn : "internet.globe.com.ph",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_name : "PLDT WeRoam Plan",
			dial_num : "*99#",
			apn : "weroamplan",
            username : "",
            password : ""
		},
        isp3 :
		{
			isp_name : "PLDT WeRoam Plus",
			dial_num : "*99#",
			apn : "weroam",
            username : "pldt@weroam",
            password : "pldt"
		},
        isp4 :
		{
			isp_mnc : "18",
			isp_name : "PLDT WeRoam Unlimited",
			dial_num : "*99#",
			apn : "weroamunli",
            username : "pldt@weroamunli",
            password : "pldt"
		},
        isp5 :
		{
			isp_mnc : "03",
			isp_name : "SmartBro Prepaid",
			dial_num : "*99#",
			apn : "smartbro",
            username : "",
            password : ""
		},
        isp6 :
		{
			isp_mnc : "03",
			isp_name : "SmartBro Postpaid",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},		
        isp7 :
		{
			isp_mnc : "05",
			isp_name : "SUN Broadband Wireless Prepaid / Plan 350 Lite",
			dial_num : "*99#",
			apn : "minternet",
            username : "",
            password : ""
		},
		isp8 :
		{
			isp_name : "SUN Easy Broadband, Wireless Plan 799/899",
			dial_num : "*99#",
			apn : "fbband",
            username : "",
            password : ""
		},
        isp9 :
		{
			isp_name : "SUN Broadband (Plan 1399)",
			dial_num : "*99#",
			apn : "mbband",
            username : "",
            password : ""
		}     
	},

	location304 :
	{
		location_mcc : "260",
		location_name : "Poland",
		isp0 :
		{
			isp_mnc : "17",
			isp_name : "Aero2",
			dial_num : "*99#",
			apn : "darmowy",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_mnc : "03",
			isp_name : "Orange(Poland)",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "06",
			isp_name : "PLAY",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
        isp3 :
		{
			isp_mnc : "01",
			isp_name : "Plus",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "12",
			isp_name : "POLSAT",
			dial_num : "*99#",
			apn : "internet.cp",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_mnc : "02",
			isp_name : "T-Mobile",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		}
	},	
	
    location305 :
	{
		location_mcc : "268",	
		location_name : "Portugal",
		isp0 :
		{
			isp_mnc : "01",
			isp_name : "Vodafone(Portugal)",
			dial_num : "*99#",
			apn : "internet.vodafone.pt",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "06",
			isp_name : "TMN",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		}
	},	
	
    location306 :
	{
		location_name : "ProXL",
        isp0 :
		{
			isp_name : "Optimus",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_name : "TMN",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_name : "Indonesia",
			dial_num : "*99#",
			apn : "www.xlgprs.net",
            username : "xlgprs",
            password : "prox"
		}
	},	
	
    location307 :
	{
		location_name : "PT Satelindo",
		isp0 :
		{
			isp_name : "Indonesia",
			dial_num : "*99#",
			apn : "Satelindogprs.com",
            username : "",
            password : ""
		}
	},	
	
	location308 :
	{
		location_mcc : "410",
		location_name : "Pakistan",
		isp0 :
		{
			isp_mnc : "03",
			isp_name : "ptcl",
			dial_num : "#777",
			apn : "",
            username : "vwireless@ptcl.com",
            password : "ptcl"
		},
		isp1 :
		{
			isp_mnc : "07",
			isp_name : "WCALL",
			dial_num : "#777",
			apn : "",
            username : "wcall",
            password : "wcall"
		}		
	}, 	
	
	location340 :
	{
		location_mcc : "226",
		location_name : "Romania",
		isp0 :
		{
			isp_mnc : "05",
			isp_name : "RCS-RDS",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		}
	},
    location341 :
	{
		location_mcc : "250",
		location_name : "Russia",
		isp0 :
		{
			isp_mnc : "28",
			isp_mnc : "99",
			isp_name : "Beeline",
			dial_num : "*99#",
			apn : "internet.beeline.ru",
            username : "beeline",
            password : "beeline"
		},
		isp1 :
		{
			isp_mnc : "02",
			isp_name : "MegaFon",
			dial_num : "*99#",
			apn : "internet",
            username : "gdata",
            password : "gdata"
		},
		isp2 :
		{
			isp_mnc : "01",
			isp_name : "MTS",
			dial_num : "*99#",
			apn : "internet.mts.ru",
            username : "mts",
            password : "mts"
		},
		isp3 :
		{
			isp_mnc : "06",
			isp_name : "SKYLINK",
			dial_num : "#777",
			apn : "",
            username : "mobile",
            password : "internet"
		},
		isp4 :
		{
			isp_name : "TELE2",
			dial_num : "*99#",
			apn : "internet.tele2.ru",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_mnc : "11",
			isp_name : "YOTA (4G LTE)",
			dial_num : "",
			apn : "",
            username : "",
            password : ""
		}
	},
	
	location360 :
	{
		location_mcc : "420",
		location_name : "Saudi Arabia",
        isp0 :
		{
			isp_mnc : "03",
			isp_name : "Mobily Prepaid",
			dial_num : "*99#",
			apn : "web2",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_name : "Mobily Postpaid",
			dial_num : "*99#",
			apn : "web1",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "01",
			isp_name : "Saudi Telecom Company",
			dial_num : "*99#",
			apn : "jawalnet.com.sa",
            username : "",
            password : ""
		}		
	},
        
    location361 :
	{
		location_mcc : "525",
		location_name : "Singapore",
		isp0 :
		{
			isp_mnc : "03",
			isp_name : "M1",
			dial_num : "*99***1#",
			apn : "sunsurf",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_name : "Power Grid",
			dial_num : "*99***1#",
			apn : "",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "01",
			isp_mnc : "02",
			isp_name : "SingTel",
			dial_num : "*99***1#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "05",
			isp_name : "StarHub(Prepaid)",
			dial_num : "*99***1#",
			apn : "shppd",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_name : "StarHub(Default)",
			dial_num : "*99#",
			apn : "shinternet",
            username : "",
            password : ""
		}
	},	
        
    location362 :
	{
		location_mcc : "231",
		location_name : "Slovakia",
		isp0 :
		{
			isp_name : "Slovak Telekom",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_name : "Orange Slovensko",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		}
	},	
        
   location363 :
	{
		location_mcc : "655",
		location_name : "South Africa",
		isp0 :
		{
			isp_mnc : "02",
			isp_name : "8ta",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "07",
			isp_name : "Cell C (Pty) Ltd",
			dial_num : "*99#",
			apn : "internet",
            username : "Cellcis",
            password : "Cellcis"
		},
        isp2 :
		{
			isp_mnc : "10",
			isp_name : "MTN",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_name : "Virgin mobile",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "01",
			isp_name : "Vodacom",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		}
	},	
	
	location364 :
	{
		location_mcc : "214",
		location_name : "Spain",
        isp0 :
		{
			isp_mnc : "15",
			isp_name : "BT(Spain)",
			dial_num : "*99***1#",
			apn : "internet.bt.es",
            username : "bt@internet",
            password : "internet"
		},
		isp1 :
		{
			isp_name : "Carrefour Internet",
			dial_num : "*99#",
			apn : "CARREFOURINTERNET",
            username : "",
            password : ""
		},
        isp2 :
		{
			isp_mnc : "08",
			isp_name : "Euskaltel(Spain)",
			dial_num : "*99#",
			apn : "internet.euskaltel.mobi",
            username : "CLIENTE",
            password : "EUSKALTEL"
		},
        isp3 :
		{
			isp_mnc : "07",
			isp_name : "MOVISTAR",
			dial_num : "*99***1#",
			apn : "movistar.es",
            username : "MOVISTAR",
            password : "MOVISTAR"
		},
        isp4 :
		{
			isp_mnc : "03",
			isp_mnc : "09",
			isp_name : "Orange(Spain)",
			dial_num : "*99#",
			apn : "internet",
            username : "CLIENTE",
            password : "AMENA"
		},
        isp5 :
		{
			isp_mnc : "19",
			isp_name : "Simyo(Spain)",
			dial_num : "*99***1#",
			apn : "gprs-service.com",
            username : "",
            password : ""
		},
        isp6 :
		{
			isp_mnc : "16",
			isp_name : "Telecable(Spain)",
			dial_num : "*99***1#",
			apn : "internet.telecable.es",
            username : "telecable",
            password : "telecable"
		},
		isp7 :
		{
			isp_mnc : "01",
			isp_mnc : "06",
			isp_name : "Vodafone(Spain)",
			dial_num : "*99***1#",
			apn : "ac.vodafone.es",
            username : "vodafone",
            password : "vodafone"
		},
		isp8 :
		{
			isp_mnc : "04",
			isp_name : "Yoigo",
			dial_num : "*99***1#",
			apn : "internet",
            username : "",
            password : ""
		}	
	},	
	
    location365 :
	{
		location_mcc : "413",
		location_name : "Sri Lanka",
        isp0 :
		{
			isp_mnc : "02",
			isp_name : "Dialog Telekom",
			dial_num : "*99#",
			apn :      "dialogbb",
            username : "",
            password : ""
		},
        
		isp1 :
		{
			isp_name : "Dialog Telekom",
			dial_num : "*99#",
			apn : "www.dialogsl.com",
            username : "",
            password : ""
		},
		
		isp2 :
		{
			isp_name : "Dialog Telekom",
			dial_num : "*99#",
			apn : "ppwap",
            username : "",
            password : ""
		},
        isp3 :
		{
			isp_mnc : "03",
			isp_name : "Etisalat",
			dial_num : "*99#",
			apn : "EBB",
            username : "",
            password : ""
		},		
        isp4 :
		{
			isp_mnc : "01",
			isp_name : "Mobitel",
			dial_num : "*99#",
			apn : "mobitel3g",
            username : "",
            password : ""
		}
	},
        
	location366 :
	{
		location_mcc : "240",
		location_name : "Sweden",
		isp0 :
		{
			isp_mnc : "01",
			isp_name : "Telia (privat)",
			dial_num : "*99#",
			apn : "online.telia.se",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "06",
			isp_mnc : "08",
			isp_name : "Telenor (privat)",
			dial_num : "*99#",
			apn : "internet.telenor.se",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_name : "Telenor (publik)",
			dial_num : "*99#",
			apn : "public.telenor.se",
            username : "",
            password : ""
		},
        isp3 :
		{
			isp_mnc : "07",
			isp_name : "Tele2",
			dial_num : "*99#",
			apn : "internet.tele2.se",
            username : "65",
            password : "User123"
		},
		isp4 :
		{
			isp_name : "Tele2 (7,2 Mbit)",
			dial_num : "*99#",
			apn : "mobileinternet.tele2.se",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_mnc : "02",
			isp_name : "3 (publik)",
			dial_num : "*99#",
			apn : "bredband.tre.se",
            username : "",
            password : ""
		},
		isp6 :
		{
			isp_name : "3 (privat)",
			dial_num : "*99#",
			apn : "data.tre.se",
            username : "",
            password : ""
		},
		isp7 :
		{
			isp_name : "Halebop",
			dial_num : "*99#",
			apn : "halebop.telia.se",
            username : "",
            password : ""
		},
		isp8 :
		{
			isp_mnc : "09",
			isp_name : "Djuice",
			dial_num : "*99#",
			apn : "internet.djuice.se",
            username : "",
            password : ""
		},
		isp9 :
		{
			isp_name : "Glocalnet",
			dial_num : "*91#",
			apn : "internet.glocalnet.se",
            username : "",
            password : ""
		},
		isp10 :
		{
			isp_name : "Bredbandsbolaget",
			dial_num : "*99#",
			apn : "internet.telenor.se",
            username : "",
            password : ""
		}
	},
    
	location367 :
	{
		location_mcc : "228",
		location_name : "Switzerland",
		isp0 :
		{
			isp_mnc : "03",
			isp_name : "Orange",
			dial_num : "*99#",
			apn : "mobileoffice3g",
            username : "",
            password : ""
		},
        isp1 :
		{
			isp_name : "Orange(Switzerland)",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "01",
			isp_name : "Swisscom",
			dial_num : "*99#",
			apn : "gprs.swisscom.ch",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "02",
			isp_name : "Sunrise",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "08",
			isp_name : "Tele2",
			dial_num : "*99#",
			apn : "internet.tele2.ch",
            username : "",
            password : ""
		}
	},	
	
    location380 :
	{
		location_mcc : "466",
		location_name : "Taiwan, China",
		isp0 :
		{
			isp_mnc : "92",
			isp_name : "Chunghua Telecom",
			dial_num : "*99***1#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "01",
			isp_name : "FarEasTone",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
        isp2 :
		{
			isp_mnc : "88",
			isp_name : "KG Telecom",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "93",
			isp_name : "MobiTai",
			dial_num : "*99#",
			apn : "gprs1",
            username : "gprs",
            password : "gprs"
		},
		isp4 :
		{
			isp_mnc : "89",
			isp_name : "Vibo",
			dial_num : "*99#",
			apn : "vibo",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_mnc : "97",
			isp_name : "Taiwan Mobile",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp6 :
		{
			isp_mnc : "93",
			isp_name : "TransAsia",
			dial_num : "*99#",
			apn : "hank",
            username : "",
            password : ""
		}
	},
    
	location381 :
	{
		location_name : "Tango",
		isp0 :
		{
			isp_name : "Luxembourg",
			dial_num : "*99#",
			apn : "internet",
            username : "tango",
            password : "tango"
		}
	},
	
	location382 :
	{
		location_mcc : "520",
		location_name : "Thailand",
		isp0 :
		{
			isp_mnc : "01",
			isp_mnc : "23",
			isp_name : "AIS",
			dial_num : "*99***1#",
			apn : "internet",
            username : "",
            password : ""
		},		
		isp1 :
		{
			isp_mnc : "18",
			isp_name : "DTAC",
			dial_num : "*99#",
			apn : "www.dtac.co.th",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_name : "i-mobile",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "15",
			isp_name : "TOT",
			dial_num : "*99***1#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_mnc : "99",
			isp_name : "TRUE",
			dial_num : "*99***1#",
			apn : "internet",
            username : "true",
            password : "true"
		}
	},
	location383 :
	{
		location_mcc : "286",
		location_name : "Turkey",
        isp0 :
		{
			isp_mnc : "03",
			isp_name : "Avea Internet",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_name : "Avea Iletisim Hizmetleri A.S. (Aycell)",
			dial_num : "*99#",
			apn : "anycell",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_name : "Turkcell",
			dial_num : "*99#",
			apn : "internet",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "01",
			isp_name : "Turkcell 3G",
			dial_num : "*99#",
			apn : "mgb",
            username : "",
            password : ""
		},
		isp4 :
		{
			isp_name : "Turkcell 3G Static IP",
			dial_num : "*99#",
			apn : "mgbs",
            username : "",
            password : ""
		},		
		isp5 :
		{
			isp_mnc : "02",
			isp_name : "Vodafone TR",
			dial_num : "*99#",
			apn : "internet",
            username : "vodafone",
            password : "vodafone"
		}
	},
	
	location400 :
	{
		location_mcc : "255",
		location_name : "Ukraine",
		isp0 :
		{
			isp_mnc : "04",
			isp_name : "Intertelecom",
			dial_num : "#777",
			apn : "",
            username : "IT",
            password : "IT"
		},
		isp1 :
		{
			isp_mnc : "03",
			isp_name : "Kyivstar",
			dial_num : "*99#",
			apn : "3g.kyivstar.net",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "06",
			isp_name : "Life",
			dial_num : "*99#",
			apn : "lifeinternet",
            username : "",
            password : ""
		},
		isp3 :
		{
			isp_mnc : "01",
			isp_name : "MTS",
			dial_num : "#777",
			apn : "",
            username : "mts",
            password : "mobile"
		},
		isp4 :
		{
			isp_mnc : "07",
			isp_name : "Utel",
			dial_num : "*99#",
			apn : "3g.utel.ua",
            username : "",
            password : ""
		}
	},

	location401 :
	{
		location_mcc : "424",
		location_name : "United Arab Emirates",
		isp0 :
		{
			isp_mnc : "03",
			isp_name : "Du",
			dial_num : "*99#",
			apn : "du",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "02",
			isp_name : "Etisalat",
			dial_num : "*99#",
			apn : "etisalat.ae",
            username : "",
            password : ""
		}
	},
	
    location402 :
	{
		location_mcc : "234",
		location_mcc : "235",
		location_name : "United Kingdom",
        isp0 :
		{
			isp_mnc : "20",
			isp_name : "3",
			dial_num : "*99***1#",
			apn : "3internet",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "03",
			isp_name : "AirTel Vodafone",
			dial_num : "*99***1#",
			apn : "airtel-ci-gprs.com",
            username : "",
            password : ""
		},
        isp2 :
		{
			isp_name : "Asda Mobile",
			dial_num : "*99***1#",
			apn : "asdamobiles.co.uk",
            username : "web",
            password : "web"
		},	
        isp3 :
		{
			isp_mnc : "O0",
			isp_mnc : "76",
			isp_mnc : "77",
			isp_name : "BT Mobile",
			dial_num : "*99***1#",
			apn : "btmobile.bt.com",
            username : "bt",
            password : "bt"
		},	
        isp4 :
		{
			isp_name : "GiffGaff",
			dial_num : "*99#",
			apn : "giffgaff.com",
            username : "giffgaff",
            password : "password"
		},			
        isp5 :
		{
			isp_mnc : "50",
			isp_name : "Jersey Telecom",
			dial_num : "*99***1#",
			apn : "pepper",
            username : "",
            password : ""
		},		
        isp6 :
		{
			isp_name : "O2 (Contract)",
			dial_num : "*99#",
			apn : "mobile.o2.co.uk",
            username : "o2web",
            password : "password"
		},
		isp7 :
		{
			isp_mnc : "10",
			isp_name : "O2 (PAYG)",
			dial_num : "*99#",
			apn : "m-bb.o2.co.uk",
            username : "o2bb",
            password : "password"
		},
		isp8 :
		{
			isp_mnc : "33",
			isp_mnc : "34",
			isp_name : "Orange",
			dial_num : "*99***1#",
			apn : "orangeinternet",
            username : "",
            password : ""
		},
		isp9 :
		{
			isp_mnc : "30",
			isp_name : "T-Mobile",
			dial_num : "*99***1#",
			apn : "general.t-mobile.uk",
            username : "",
            password : ""
		},
		isp10 :
		{
			isp_name : "Tesco Mobile",
			dial_num : "*99***1#",
			apn : "prepay.tesco-mobile.com",
            username : "tescowap",
            password : "password"
		},
		isp11 :
		{
			isp_mnc : "31",
			isp_mnc : "32",
			isp_name : "Virgin Mobile",
			dial_num : "*99***1#",
			apn : "goto.virginmobile.uk",
            username : "user",
            password : ""
		},
		isp12 :
		{
			isp_name : "Vodafone (contract)",
			dial_num : "*99***1#",
			apn : "internet",
            username : "web",
            password : "web"
		},
		isp13 :
		{
			isp_mnc : "15",
			isp_name : "Vodafone (PAYG)",
			dial_num : "*99***1#",
			apn : "ppbundle.internet",
            username : "web",
            password : "web"
		},
		isp14 :
		{
			isp_name : "EE",
			dial_num : "*99#",
			apn : "everywhere",
            username : "eesecure",
            password : "secure"
		}
	},    
    
	location403 :
	{
		location_mcc : "748",
		location_name : "Uruguay",
		isp0 :
		{
			isp_mnc : "07",
			isp_name : "movistar",
			dial_num : "*99#",
			apn : "apnumt.movistar.com.uy",
            username : "movistar",
            password : "movistar"
		}
	},
	
    location404 :
	{
		location_mcc : "310",
		location_mcc : "311",
		location_name : "USA",
		isp0 :
		{
			isp_mnc : "090",
			isp_mnc : "150",
			isp_mnc : "380",
			isp_mnc : "410",
			isp_mnc : "560",
			isp_mnc : "680",
			isp_name : "AT&T",
			dial_num : "*99#",
			apn : "broadband",
            username : "WAP@CINGULAR.COM",
            password : "CINGULAR1"
		},
		isp1 :
		{
			isp_mnc : "590",
			isp_name : "Alltel",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		},
        isp2 :
		{
			isp_mnc : "120",
			isp_name : "Sprint",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		},        
        isp3 :
		{
			isp_mnc : "026",
			isp_mnc : "330",
			isp_mnc : "490",
			isp_mnc : "580",
			isp_mnc : "660",
			isp_name : "T-Mobile",
			dial_num : "*99#",
			apn : "epc.tmobile.com",
            username : "none",
            password : "none"
		},
        isp4 :
		{
			isp_mnc : "004",
			isp_mnc : "005",
			isp_mnc : "012",
			isp_mnc : "480",
			isp_mnc : "481",
			isp_name : "Verizon",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		},
		isp5 :
		{
			isp_name : "Verizon(4G)",
			dial_num : "*99***3#",
			apn : "vzwinternet",
            username : "",
            password : ""
		},
		isp6 :
		{
			isp_mnc : "053",
			isp_mnc : "530",
			isp_name : "Virgin",
			dial_num : "#777",
			apn : "",
            username : "",
            password : ""
		}
	},
	
	location420 :
	{
		location_mcc : "734",
		location_name : "venezuela",
		isp0 :
		{
			isp_mnc : "01",
			isp_mnc : "02",
			isp_mnc : "03",
			isp_name : "DIGITEL",
			dial_num : "*99#",
			apn : "gprsweb.digitel.ve",
            username : "",
            password : ""
		},
		isp1 :
		{
			isp_mnc : "06",
			isp_name : "MOVILNET",
			dial_num : "*99#",
			apn : "int.movilnet.ve",
            username : "",
            password : ""
		},
		isp2 :
		{
			isp_mnc : "04",
			isp_name : "MOVISTAR",
			dial_num : "*99#",
			apn : "internet.movistar.ve",
            username : "",
            password : ""
		}
	},
	
	location421 :
	{
		location_mcc : "452",
		location_name : "Viet Nam",
		isp0 :
		{
			isp_mnc : "01",
			isp_name : "Mobifone",
			dial_num : "*99***1#",
			apn : "m-wap",
            username : "mms",
            password : "mms"
		},
		isp1 :
		{
			isp_mnc : "02",
			isp_name : "Vinaphone",
			dial_num : "*99***1#",
			apn : "m3-world",
            username : "mms",
            password : "mms"
		},
		isp2 :
		{
			isp_mnc : "04",
			isp_name : "Viettel",
			dial_num : "*99***1#",
			apn : "v-internet",
            username : "",
            password : ""
		}
	}
};
