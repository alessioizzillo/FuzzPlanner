print_pppoe_options(){
cat <<EOF
noipdefault
defaultroute
hide-password
$2
noauth
noaccomp
default-asyncmap
connect /bin/true
mtu $3
mru $3
$4
$5
lcp-echo-interval 10
lcp-echo-failure 3
user $1
plugin rp-pppoe.so $8
$6
$7
EOF
}

print_pptp_options(){
    cat <<EOF
noauth
noipdefault
defaultroute
ipparam pptp
refuse-eap
mtu $2
mru $2
$3
$4
$6
lcp-echo-interval 10
lcp-echo-failure 4
user $1
plugin dni-pptp.so $5
$7
pptp_iface $8
EOF
}

insert_modules(){
    if [ "$1" = "pptp" ]; then
	load_modules /etc/modules.d/60-pptp-mod
    else
	load_modules /etc/modules.d/60-pppoe-mod
    fi
}

print_ip_up() 
{
    cat <<EOF
#!/bin/sh
/www/cgi-bin/firewall.sh start
/sbin/cmdroute stop
/usr/bin/killall -SIGINT ripd
/sbin/cmdroute start
/usr/sbin/ripd
echo -n 1 > /etc/ppp/ppp0-status
cat /proc/uptime | awk '{print\$1}' > /tmp/ppp/ppp_last_conn_time
#/sbin/cmd_traffic_meter config_update
/sbin/ledcontrol -n wan -c green -s on
local qos_enable=\$(/bin/config get qos_endis_on)
local qos_bandwidth_enable=\$(/bin/config get qos_threshold)
local qos_bandwidth_type=\$(/bin/config get qos_bandwidth_type)
if [ "x\$qos_enable" = "x1" -a "x\$qos_bandwidth_enable" = "x1" ]; then
	if [ "x\$qos_bandwidth_type" = "x1" ]; then
		/etc/bandcheck/band-check &
	fi
fi
local ipv6_wantype=\$(/bin/config get ipv6_type)
if [ "x\$ipv6_wantype" = "x6to4" ]; then
	/etc/net6conf/net6conf restart
fi
EOF
}

print_ip_down()
{
    cat <<EOF
#!/bin/sh
/usr/bin/killall -SIGINT ripd
echo -n 0 > /etc/ppp/ppp0-status
cat /proc/uptime | awk '{print$1}' > /tmp/ppp/ppp_last_stop_time
#/usr/bin/killall -SIGINT traffic_meter
# wait 1 second to execute SIGINT signal handler
sleep 1
#/sbin/cmd_traffic_meter config_update
/sbin/ledcontrol -n wan -c amber -s on
local ipv6_wantype=\$(/bin/config get ipv6_type)
if [ "x\$ipv6_wantype" = "x6to4" ]; then
	/etc/net6conf/net6conf stop
fi
EOF
}

setup_interface_ppp() {
    local user passwd dns mtu mru idle demand service ip proto gw

    mknod /dev/ppp c 108 0
    mkdir -p /tmp/ppp
    mkdir -p /etc/ppp/peers

    #[ ! -f /etc/ppp/ip-up ] && echo "#!/bin/sh" /etc/ppp/ip-up
    #[ ! -f /etc/ppp/ip-down ] && echo "#!/bin/sh" /etc/ppp/ip-down
    print_ip_up > /etc/ppp/ip-up
    chmod 0777 /etc/ppp/ip-up
    print_ip_down > /etc/ppp/ip-down
    chmod 0777 /etc/ppp/ip-down

    proto=$($CONFIG get wan_proto)
    if [ "$proto" = "pptp" ]; then
	insert_modules "pptp"
	user=$($CONFIG get wan_pptp_username)
	passwd=$($CONFIG get wan_pptp_password)
	mtu=$($CONFIG get wan_pptp_mtu)
	if [ "$($CONFIG get wan_endis_dod)" = "1" ]; then
	    idle="idle $($CONFIG get wan_pptp_idle_time)"
	    demand="demand"
	elif [ "$($CONFIG get wan_endis_dod)" = "2" ]; then
#To fix bug 21986
	    [ "x$1" != "xmanually" -a "x$($CONFIG get run_test)" != "xtest" ] && exit 0
	    idle="runone"
	else
	    idle="persist"
	fi
	if [ "$($CONFIG get wan_pptp_wan_assign)" != "0" ]; then
	    route=$($CONFIG get pptp_gw_static_route)
	    [ "x$route" != "x" ] && gw="pptp_gateway $route"
	fi
	[ "$($CONFIG get wan_pptp_dns_assign)" != "1" ] && dns="usepeerdns"
	ip=$($CONFIG get wan_pptp_server_ip)
	print_pptp_options "$user" "${mtu:-1492}" "$idle" "$demand" "$ip" "$dns" "$gw" "$WAN_IF" > /etc/ppp/peers/dial-provider
        sed -i '/user/ s/\\/\\\\/g' /etc/ppp/peers/dial-provider
        sed -i '/user/ s/\#/\\#/g' /etc/ppp/peers/dial-provider
    else
	insert_modules "pppoe"
	user=$($CONFIG get wan_pppoe_username)
	passwd=$($CONFIG get wan_pppoe_passwd)
	mtu=$($CONFIG get wan_pppoe_mtu)
	[ "$($CONFIG get wan_pppoe_dns_assign)" != "1" ] && dns="usepeerdns"
	if [ "$($CONFIG get wan_endis_dod)" = "1" ]; then
	    idle="idle $($CONFIG get wan_pppoe_idletime)"
	    demand="demand"
	elif [ "$($CONFIG get wan_endis_dod)" = "2" ]; then
#To fix bug 21986
	    [ "x$1" != "xmanually" -a "x$($CONFIG get run_test)" != "xtest" ] && exit 0
	    idle="runone"
	else
	    idle="persist"
	fi
	[ "x$($CONFIG get wan_pppoe_service)" != "x" ] && service="rp_pppoe_service $($CONFIG get wan_pppoe_service)"
	[ "$($CONFIG get wan_pppoe_wan_assign)" = "1" ] && ip="$($CONFIG get wan_pppoe_ip):" 
	print_pppoe_options "$user" "$dns" "${mtu:-1492}" "$idle" "$demand" "$service" "$ip" "$WAN_IF" > /etc/ppp/peers/dial-provider
        sed -i '/user/ s/\\/\\\\/g' /etc/ppp/peers/dial-provider
        sed -i '/user/ s/\#/\\#/g' /etc/ppp/peers/dial-provider
	
	sed -i '/rp_pppoe_service/ s/\\/\\\\/g' /etc/ppp/peers/dial-provider
	sed -i '/rp_pppoe_service/ s/\#/\\#/g' /etc/ppp/peers/dial-provider
	
	
    fi

    local PPP_CHAPS="/etc/ppp/chap-secrets"
    local PPP_PAPS="/etc/ppp/pap-secrets"
    local IPV6_PPPS="/etc/ppp/ipv6-secrets"
    local IPV4_PPPS="/etc/ppp/ipv4-secrets"

    echo "${user} * \"${passwd}\"" > $IPV4_PPPS
    sed -i 's/\\/\\\\/g' $IPV4_PPPS
    sed -i 's/\#/\\#/g' $IPV4_PPPS

    #combination ipv4 and ipv6 ppp secrets file
    cat $IPV4_PPPS > $PPP_CHAPS
    cat $IPV4_PPPS > $PPP_PAPS
    if [ -f $IPV6_PPPS ]; then
        cat $IPV6_PPPS >> $PPP_CHAPS
        cat $IPV6_PPPS >> $PPP_PAPS
    fi

    if [ "$proto" = "pptp" -a "$($CONFIG get wan_pptp_wan_assign)" = "0" ]; then
    	echo "Start PPTP by DHCP module"
    else
        pppd call dial-provider updetach
    fi
}

