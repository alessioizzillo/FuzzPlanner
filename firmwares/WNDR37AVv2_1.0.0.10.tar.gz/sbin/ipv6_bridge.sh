#!/bin/sh

. /etc/net6conf/6data.conf

WLAN="ath0"
EBTABLES="/usr/sbin/ebtables"
CONFIG="/bin/config"
IPV6_TYPE=`$CONFIG get ipv6_type`

start_ebtables()
{
	local lanhw=$(ifconfig $bridge | grep "HWaddr" | awk '{print $5}')

        $EBTABLES -t broute -P BROUTING DROP

        $EBTABLES -t broute -A BROUTING -p IPv6 -j ACCEPT

        $EBTABLES -t broute -A BROUTING -i $LAN   -j ACCEPT
        $EBTABLES -t broute -A BROUTING -i $WLAN -j ACCEPT

        $EBTABLES -A FORWARD -p ! IPv6 -o $WAN -j DROP
        $EBTABLES -A OUTPUT -s $lanhw -p ! IPv6 -o $WAN -j DROP
}

stop_ebtables()
{
        $EBTABLES -t broute -P BROUTING ACCEPT
        $EBTABLES -t broute -F
        $EBTABLES -t broute -X
        $EBTABLES -F
        $EBTABLES -X
}

case "$1" in
        start)
        start_ebtables
        ;;
        stop)
        stop_ebtables
        ;;
        restart)
        [ "$IPV6_TYPE" = "bridge" ] && stop_ebtables && start_ebtables
        ;;
        *)
        echo "Usage: /sbin/ipv6_bridge.sh  [stop | start | restart]"
        ;;
esac
