function check_media(form)
{
	if(form.media_server.checked)
		form.media_server_onoff.value="1";
	else
		form.media_server_onoff.value="0";

	check_name();

	form.submit();
}
function check_media_scan(form)
{
	form.submit_flag.value="upnp_media_scan";
	form.submit();
}
