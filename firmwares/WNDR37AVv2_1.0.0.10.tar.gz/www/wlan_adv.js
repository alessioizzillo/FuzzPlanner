function checkadv(form)
{
        if( wps_progress_status == "2" || wps_progress_status == "3" || wps_progress_status == "start" )
        {
                alert("$wps_in_progress");
                return false;
        }

	if(form.rts[0].value == "" || form.rts[1].value == "")
	{	
		alert("$rts_range");
		return false;
	}
        if(!(form.rts[0].value > 0 && form.rts[0].value <= 2347) || !(form.rts[1].value > 0 && form.rts[1].value <= 2347))
        {
                alert("$rts_range");
                return false;
        }
	//form.wl_rts.value = form.rts[0].value;
	//form.wla_rts.value = form.rts[1].value;

	if(form.frag[0].value == "" || form.frag[1].value == "")
	{
		alert("$fragmentation_range");
		return false;
	}
	if(!(form.frag[0].value > 255 && form.frag[0].value < 2347) || !(form.frag[1].value > 255 && form.frag[1].value < 2347))
	{
		alert("$fragmentation_range");
		return false;
	}
	//form.wl_frag.value = form.frag[0].value;
	//form.wla_frag.value = form.frag[1].value;

	if(form.ssid_bc.checked == true)
		form.wl_enable_ssid_broadcast.value="1";
	else
		form.wl_enable_ssid_broadcast.value="0";
	if(form.guest_iso.checked == true)
		form.wlg_endis_wireless_isolation.value="1";
	else
		form.wlg_endis_wireless_isolation.value="0";
	if(form.ssid_bc_an.checked == true)
		form.wla_enable_ssid_broadcast.value="1";
	else
        form.wla_enable_ssid_broadcast.value="0";
	if(form.guest_iso_an.checked == true)
	    form.wla_endis_wireless_isolation.value="1";
	 else
        form.wla_endis_wireless_isolation.value="0";
        if(form.wmm_enable.checked == true)
               	form.wladv_endis_wmm.value = "1";
        else
               	form.wladv_endis_wmm.value = "0";
        if(form.wmm_enable_a.checked == true)
                form.wladv_endis_wmm_a.value = "1";
        else
                form.wladv_endis_wmm_a.value = "0";

	if(form.enable_shortpreamble[0].selectedIndex == "2")
		form.wl_enable_shortpreamble.value = "2";
	else if(form.enable_shortpreamble[0].selectedIndex == "1")
                form.wl_enable_shortpreamble.value = "1";
	else if(form.enable_shortpreamble[0].selectedIndex == "0")
		form.wl_enable_shortpreamble.value = "0";
        if(form.enable_shortpreamble[1].selectedIndex == "2")
                form.wla_enable_shortpreamble.value = "2";
        else if(form.enable_shortpreamble[1].selectedIndex == "1")
                form.wla_enable_shortpreamble.value = "1";
        else if(form.enable_shortpreamble[1].selectedIndex == "0")
                form.wla_enable_shortpreamble.value = "0";
	//transmit power control
	wlan_txctrl(form, form.tx_power_ctrl.value, form.tx_power_ctrl_a.value, wla_channel, country);

	if(form.enable_ap.checked == true)
		form.wl_enable_router.value="1";
	else
		form.wl_enable_router.value="0";
	if(form.enable_ap_an.checked == true)
                form.wla_enable_router.value="1";
        else
                form.wla_enable_router.value="0";
/*
	if( an_router_flag == 1){

		if( old_endis_wl_radio == "1" && form.wl_enable_router.value == "0" && old_endis_wla_radio == "1" && form.wla_enable_router.value == "0" ){
			if(!confirm("$radio_wps"))
				return false;
		}
		else if( old_endis_wl_radio == "1" && form.wl_enable_router.value == "0" )
		{
			if(!confirm("$radio_bgn_wps"))
				return false;
		}
		else if( old_endis_wla_radio == "1" && form.wla_enable_router.value == "0" )
		{
			if(!confirm("$radio_an_wps"))
				return false;
		}
	}
	else{
		if( old_endis_wl_radio == "1" && form.wl_enable_router.value == "0")
		{
			 if(!confirm("$radio_wps"))
				return false;
		}
	}
*/
	if(form.pin_disable.checked == true )
		form.endis_pin.value="1";
	else
		form.endis_pin.value="0";
	if(form.wsc_config.checked == true)
		form.endis_wsc_config.value="5";
	else
		form.endis_wsc_config.value="1";
	if(form.wsc_config_a.checked == true)
		form.endis_wsc_config_a.value="5";
	else
		form.endis_wsc_config_a.value="1";
	if ( old_endis_wl_radio =="0" && form.wl_enable_router.value == "0")
		form.wds_change_ip.value="still_lanip"
	else if( old_endis_wl_radio =="0" && form.wl_enable_router.value == "1" )
	{
		if ( old_wds_endis_fun == "1" &&  old_wds_repeater_basic == "0" )
		{
			if(security_mode=="3" ||  security_mode=="4" || security_mode == "5")
			{
				if(!confirm("$wds_not_wpa"))
					return false;
				else
				{
					location.href="WLG_wireless.htm";
					return false;
				}
			}
			else
			{
				if ( old_wds_endis_fun == '1' && old_wds_repeater_basic == '0' && old_endis_wl_radio == '1' )
					top.contents.location.href="MNU_menu_wds_nolink.htm";
				else
					top.contents.location.href="MNU_menu_nolink.htm";
				form.wds_change_ip.value="to_repeatip";
			}
		}
		else
			form.wds_change_ip.value="still_lanip"	
	}
	else if ( old_endis_wl_radio =="1" && form.wl_enable_router.value == "0")
	{
		if ( old_wds_endis_fun == "1" &&  old_wds_repeater_basic == "0" )
		{
			if ( old_wds_endis_fun == '1' && old_wds_repeater_basic == '0' && old_endis_wl_radio == '1' )
				top.contents.location.href="MNU_menu_wds_nolink.htm";
			else
				top.contents.location.href="MNU_menu_nolink.htm";
			form.wds_change_ip.value="to_lanip";
		}
		else
			form.wds_change_ip.value="still_lanip";
	}
	else
	{
		if ( old_wds_endis_fun == "1" &&  old_wds_repeater_basic == "0" )
			form.wds_change_ip.value="still_repeatip"
		else
			form.wds_change_ip.value="still_lanip"	
	}
	form.rts[0].value=port_range_interception(form.rts[0].value);
	form.rts[1].value=port_range_interception(form.rts[1].value);
	form.frag[0].value=port_range_interception(form.frag[0].value);
	form.frag[1].value=port_range_interception(form.frag[1].value);
	form.wl_rts.value = form.rts[0].value;
	form.wla_rts.value = form.rts[1].value;
	form.wl_frag.value = form.frag[0].value;
	form.wla_frag.value = form.frag[1].value;
	
	form.submit();
	//return true;
}
