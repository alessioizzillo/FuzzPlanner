#!/bin/sh

. /etc/net6conf/6data.conf

WLAN="ath0"
EBTABLES="/usr/sbin/ebtables"
CONFIG="/bin/config"
IPV6_TYPE=`$CONFIG get ipv6_type`
IPV6_PSS_PROC="/proc/sys/stb/wan_enable"

start_ebtables()
{
#fix the bug [Netgear-IPv6 Passthrough] When enabled the IPv6 Pass Though, the wireless 5G client can't get IPv4 address by DHCP.
#we only add a rule  allow 2.4G to pass packets, and the packets from 5G will be dropped, so we don't modify the rules in BROUTING
	$EBTABLES -A INPUT -p IPv6 -j DROP
	$EBTABLES -A OUTPUT -p IPv6 -j DROP
# Fixed bug26637: [ipv6]When turn on ipv6 "Pass Through" mode, the lan pc will
# get ip address/dns from the wan server.
	if [ ! -e $IPV6_PSS_PROC ]; then
		$EBTABLES -t broute -A BROUTING -i $WAN -p ! ipv6 -j DROP
	fi

}

stop_ebtables()
{
        $EBTABLES -t broute -P BROUTING ACCEPT
        $EBTABLES -t broute -F
        $EBTABLES -t broute -X
        $EBTABLES -F
        $EBTABLES -X
}

case "$1" in
        start)
        start_ebtables
        ;;
        stop)
        stop_ebtables
        ;;
        restart)
        [ "$IPV6_TYPE" = "bridge" ] && stop_ebtables && start_ebtables
        ;;
        *)
        echo "Usage: /sbin/ipv6_bridge.sh  [stop | start | restart]"
        ;;
esac
