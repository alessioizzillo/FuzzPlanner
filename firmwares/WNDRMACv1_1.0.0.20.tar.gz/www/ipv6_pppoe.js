function change_ipv6_pppoe_password(obj)
{
        if( obj.type == "password" )
        {
                if( get_browser() == "Firefox" )
                {
                        obj.value = "";
                        obj.type = "text";
                }
                else
                {
                        obj.outerHTML = '<input type="text" name="ipv6_pppoe_passwd" maxlength="64" size="18" onFocus="this.select();" onKeyPress="return getkey(\'ssid\', event)" value="">';
                        document.forms[0].ipv6_pppoe_passwd.focus();
                        document.forms[0].ipv6_pppoe_passwd.focus();
                }
        }
}

function check_ipv6_pppoe(cf)
{
	ipv6_save_common(cf);

	if(cf.ipv6_pppoe_username.value == "")
	{
		alert("$login_name_null");
		return false;
	}	
	
	if(cf.ipv6_pppoe_passwd.value == "")
	{
		alert("$password_null");
		return false;
	}
	return true;
}
