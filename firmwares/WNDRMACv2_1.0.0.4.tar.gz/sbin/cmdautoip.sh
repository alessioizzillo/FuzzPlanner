#!/bin/sh

CONFIG="/bin/config"

autoip=$($CONFIG get lan_ip_dynam)

autoip_start() {
	killall udhcpd
	killall dnsmasq
	echo "Now start udhcpc_autoip ..."
	ifconfig br0 0.0.0.0
	required_ip=""
	lan_ipaddress=$($CONFIG get lan_ipaddr)
	if [ "${lan_ipaddress%.*.*}" != "169.254" ]; then
		require_ip="-r $lan_ipaddress"
	fi
	udhcpc_autoip -f -i br0 -h WNDRMACv2 $require_ip &
}

autoip_stop() {
	killall udhcpc_autoip
}

case "$1" in
	start)
		autoip_stop
		sleep 1
		[ "$autoip" = "1" ] && autoip_start
		;;
	stop)
		autoip_stop
		;;
	restart)
		autoip_stop
		sleep 1
		[ "$autoip" = "1" ] && autoip_start
		;;
esac
