function change_volumn_time()
{
	var cf=document.forms[0];
	if(cf.ctrl_volumn_time[0].checked == true)
	{
		cf.mon_time_limit.disabled = true;
		cf.limit.disabled = false;
		cf.mon_volumn_limit.disabled = false;
		if(basic_type == 1)
			cf.round_up.disabled = true;
		else
			cf.round_up.disabled = false;
	}
	else
	{
		cf.mon_time_limit.disabled = false;
		cf.limit.disabled = true;
		cf.mon_volumn_limit.disabled = true;
		cf.round_up.disabled = true;	
	}
}

function set_gray()
{
	var cf=document.forms[0];
	var dflag;
	dflag=(!(cf.enable_traffic.checked));
	setDisabled ( dflag, cf.ctrl_volumn_time[0], cf.ctrl_volumn_time[1], cf.limit, cf.mon_volumn_limit, cf.round_up, cf.mon_time_limit, cf.hour, cf.minute,  cf.traffic_restart_day,  cf.left_time_volumn, cf.turn_led, cf.block_all_traffic, cf.ampm,cf.restart, cf.refresh, cf.status);	//cf.restart, cf.refresh, cf.status,
	if( basic_type == 1)
		setDisabled ( true, cf.round_up, cf.ctrl_volumn_time[1], cf.mon_time_limit);

	if(cf.enable_traffic.checked == true)
	{
	document.getElementById("restart").className  = "long_common_bt";
	document.getElementById("refresh").className  = "common_bt";
	document.getElementById("status").className  = "common_bt";	
	change_volumn_time();
	}
	else
	{
	document.getElementById("restart").className  = document.getElementById("restart").className + "_grey";
	document.getElementById("refresh").className  = document.getElementById("refresh").className + "_grey";
	document.getElementById("status").className  = document.getElementById("status").className + "_grey";
	}

}

function check_traffic_apply(cf)
{
	var cf=document.forms[0];
	if(cf.enable_traffic.checked == true)
		cf.endis_traffic.value=1;
	else
		cf.endis_traffic.value=0;
	if(cf.enable_traffic.checked == true)
	{

		if(cf.ctrl_volumn_time[0].checked)
		{
			if(cf.mon_volumn_limit.value=='')
			{
				alert("$monthly_limit_error");
				return false;
			}
			if(!_isNumeric(cf.mon_volumn_limit.value))
        		{
                		alert("$monthly_limit_error");
                		return false;
        		}
			if(parseInt(cf.mon_volumn_limit.value)>999999)
			{
				alert("$monthly_limit_error");
                                return false;				
			}
			if(cf.round_up.value=='')
			{
				alert("$round_up_data_error");
				return false;
			}
			if(!_isNumeric(cf.round_up.value))
                        {
                                alert("$round_up_data_error");
                                return false;
                        }
			if(cf.left_time_volumn.value=='')
			{
				alert("$left_volumn_error");
				return false;
			}
			if(!_isNumeric(cf.left_time_volumn.value))
                        {
                                alert("$left_volumn_error");
                                return false;
                        }
			if(parseInt(cf.left_time_volumn.value) > parseInt(cf.mon_volumn_limit.value))
			{
				alert("$left_volumn_small");
				return false;
			}
			if(parseInt(cf.round_up.value) > parseInt(cf.mon_volumn_limit.value))
			{
				alert("$round_volumn_small");
				return false;
			}
		}
		else
		{
			if(cf.mon_time_limit.value=='')
			{
				alert("$monthly_limit_error");
				return false;
			}
			if(!(cf.mon_time_limit.value <= 744))
			{
				alert("$monthly_limit_744");
				return false;
			}
			var str1 = cf.mon_time_limit.value;
			var arry = str1.split('.');
			if (arry.length>1)
			{
				alert("$month_linmit_int");
				return false;
			}
			if(cf.left_time_volumn.value=='')
                        {
                                alert("$left_volumn_error");
                                return false;
                        }
                        if(!_isNumeric(cf.left_time_volumn.value))
                        {
                                alert("$left_volumn_error");
                                return false;
                        }
			if(parseInt(cf.left_time_volumn.value) > parseInt(cf.mon_time_limit.value)*60)
			{
				alert("$left_volumn_small");
				return false;
			}
		}
		if ((cf.hour.value < 0) || (cf.hour.value > 11) ||
			(cf.minute.value < 0) || (cf.minute.value > 59) )
			{
				alert("$invalid_time");
				return false;
			}
		if ((!_isNumeric(cf.hour.value)) ||
				(!_isNumeric(cf.minute.value)))
			{
				alert("$invalid_time");
				return false;
			}

		if ((cf.hour.value == '') || (cf.minute.value == ''))
			{
				alert("$invalid_time");
				return false;
			}
		var hour=cf.hour.value;
		var minute=cf.minute.value
		if(hour.length<2)
			hour="0"+hour;
		if(minute.length<2)
			minute="0"+minute;
		if(cf.ampm.selectedIndex==1)
		{
			hour=parseInt(hour,10)+12;
			hour=hour.toString();
		}	
		cf.restart_counter_time.value=hour+':'+minute;
		if(cf.turn_led.checked == true)
			cf.traffic_led.value=1;
		else
			cf.traffic_led.value=0;
		if(cf.block_all_traffic.checked == true)
			cf.traffic_block_all.value=1;
		else
			cf.traffic_block_all.value=0;
	}
	
	return true;
}

function click_restart()
{
	var cf=document.forms[0];
	if(cf.enable_traffic.checked == true)
	{
	    if(!confirm("$traffic_restart_counter"))
			return false;
		cf.submit_flag.value="traffic_reset";
		cf.submit();
	}

}

function click_refresh_2()
{
	var cf=document.forms[0];
	if (cf.enable_traffic.checked == true)
	{
		location.href='traffic.htm';
	}
}

function click_status()
{
	var cf=document.forms[0];
	if (cf.enable_traffic.checked == true)
	{
		window.open('show_traffic.htm','show_traffic','width=600,height=400,top=200,left=200,status=yes');
	}
}

function reset_time()
{
	cf=document.forms[0];
	if( cf.timeset.value == "")
	{
		cf.timeset.value = "10";
		return true;
	}
	var timeset=cf.timeset.value;

        for(i=0;i<timeset.length;i++)
        {
                c=timeset.charAt(i);
                if("0123456789".indexOf(c,0)<0)
                {
			alert("$rang_pool");
                        return false;
                }
        }

	timeset=parseInt(timeset);
	if(!(	timeset >=5 && timeset<=  86400))
	{
		alert("$rang_pool");
		return false;
	}

	return true;
}

function click_refresh()
{
	cf=document.forms[0];
	cf.submit_flag.value="refresh_traffic"
	cf.action="/cgi-bin/no_commit.cgi?/cgi-bin/traffic.htm"
	cf.submit();
}

