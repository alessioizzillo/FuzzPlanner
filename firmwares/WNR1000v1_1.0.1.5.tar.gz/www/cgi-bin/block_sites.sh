config_block_sites()
{
	$nvram set block_skeyword=$1
	$nvram set block_endis_Trusted_IP=$2
	$nvram set block_KeyWord_DomainList="$3"
	$nvram set block_trustedip=$4
}
