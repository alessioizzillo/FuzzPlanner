config_ddns()
{
	$nvram set endis_ddns=$1
	$nvram set sysDNSHost=$2
	$nvram set sysDNSUser=$3
	$nvram set sysDNSPassword=$4
	$nvram set endis_wildcards=$5
	$nvram set sysDNSProviderlist=$6
	$nvram set change_wan_type=$7
}
