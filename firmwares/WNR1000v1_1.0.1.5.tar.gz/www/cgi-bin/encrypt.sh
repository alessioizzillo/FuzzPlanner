#!/bin/sh

ENCRYPT="/sbin/encrypt -i"
CONFIG_DIR="/tmp/configs"

[ "x`nvram get http_passwd`" != "x" ] && $ENCRYPT $CONFIG_DIR/http_passwd
[ "x`nvram get wan_pppoe_passwd`" != "x" ] && $ENCRYPT $CONFIG_DIR/wan_pppoe_passwd
[ "x`nvram get wan_bpa_password`" != "x" ] && $ENCRYPT $CONFIG_DIR/wan_bpa_password
[ "x`nvram get wan_pptp_password`" != "x" ] && $ENCRYPT $CONFIG_DIR/wan_pptp_password
[ "x`nvram get email_password`" != "x" ] && $ENCRYPT $CONFIG_DIR/email_password
[ "x`nvram get wan_mulpppoe1_passwd`" != "x" ] && $ENCRYPT $CONFIG_DIR/wan_mulpppoe1_passwd
[ "x`nvram get wan_mulpppoe2_east_password`" != "x" ] && $ENCRYPT $CONFIG_DIR/wan_mulpppoe2_east_password
[ "x`nvram get wan_mulpppoe2_other_password`" != "x" ] && $ENCRYPT $CONFIG_DIR/wan_mulpppoe2_other_password
[ "x`nvram get wan_mulpppoe2_password`" != "x" ] && $ENCRYPT $CONFIG_DIR/wan_mulpppoe2_password
[ "x`nvram get wan_mulpppoe2_west_password`" != "x" ] && $ENCRYPT $CONFIG_DIR/wan_mulpppoe2_west_password
[ "x`nvram get wl_key`" != "x" ] && $ENCRYPT $CONFIG_DIR/wl_key
[ "x`nvram get wl_wpa1_psk`" != "x" ] && $ENCRYPT $CONFIG_DIR/wl_wpa1_psk
[ "x`nvram get wl_wpa2_psk`" != "x" ] && $ENCRYPT $CONFIG_DIR/wl_wpa2_psk
[ "x`nvram get wl_wpas_psk`" != "x" ] && $ENCRYPT $CONFIG_DIR/wl_wpas_psk
num=1
while [ $num -le 4 ]
do
	[ "x`nvram get wl_key$num`" != "x" ] && $ENCRYPT $CONFIG_DIR/wl_key$num
	[ "x`nvram get wep_64_key$num`" != "x" ] && $ENCRYPT $CONFIG_DIR/wep_64_key$num
	[ "x`nvram get wep_128_key$num`" != "x" ] && $ENCRYPT $CONFIG_DIR/wep_128_key$num
	num=$(($num + 1))
done

