rc=/sbin/rc
cmd_wan=/sbin/cmdwan
cmd_lan=/sbin/cmdlan
cmd_plugin=/sbin/cmd_plugin
cmdupnp=/sbin/cmdupnp
cmd_ddns=/sbin/ddns
cmd_firewall=/sbin/firewall
nvram=/usr/sbin/nvram
brctl=/usr/sbin/brctl
ifconfig=/sbin/ifconfig
bing=/usr/sbin/bing
lansh=/www/cgi-bin/lan.sh
wlansh=/www/cgi-bin/wlan.sh
securitysh=/www/cgi-bin/security.sh
access_ctrlsh=/www/cgi-bin/access_control.sh
systemsh=/www/cgi-bin/system.sh
passwdsh=/www/cgi-bin/passwd.sh
upgradesh=/www/cgi-bin/upgrade.sh
wlan_advsh=/www/cgi-bin/wlan_adv.sh
wdssh=/www/cgi-bin/wds.sh

bas_ethersh=/www/cgi-bin/bas_ether.sh
bas_pppoesh=/www/cgi-bin/bas_pppoe.sh
bas_pptpsh=/www/cgi-bin/bas_pptp.sh
bas_bpash=/www/cgi-bin/bas_bpa.sh
emailsh=/www/cgi-bin/email.sh
wlaclsh=/www/cgi-bin/wlacl.sh
block_servicessh=/www/cgi-bin/block_services.sh
forwardingsh=/www/cgi-bin/forwarding.sh
triggeringsh=/www/cgi-bin/triggering.sh
ripsh=/www/cgi-bin/rip.sh

ddnssh=/www/cgi-bin/ddns.sh
upnpsh=/www/cgi-bin/upnp.sh
st_routersh=/www/cgi-bin/st_router.sh
block_sitessh=/www/cgi-bin/block_sites.sh
wansh=/www/cgi-bin/wan.sh
remotesh=/www/cgi-bin/remote.sh

shawk=/www/cgi-bin/shawk.sh
firewallsh=/www/cgi-bin/firewall.sh
firewall_functionsh=/www/cgi-bin/firewall_function.sh
logsh=/www/cgi-bin/log.sh

schedulesh=/www/cgi-bin/schedule.sh
reservationsh=/www/cgi-bin/reservation.sh
mulpppoesh=/www/cgi-bin/mulpppoe.sh
welcomesh=/www/cgi-bin/welcome.sh
wizardsh=/www/cgi-bin/wizard.sh
ntpsh=/www/cgi-bin/ntp.sh
infosh=/www/cgi-bin/info.sh
trafficsh=/www/cgi-bin/traffic.sh
qossh=/www/cgi-bin/qos.sh
scienariosh=/www/cgi-bin/scienario.sh

cahidden=/www/cgi-bin/cahidden.sh
change_languagesh=/www/cgi-bin/change_language.sh
#wps
wsccmd=/usr/sbin/wsccmd
wsc_cfg=/usr/sbin/wsc_cfg

CONSOLE=/dev/console

oc () { "$@" >> $CONSOLE 2>&1 ; } # stdout & stderr to /dev/console

DEV_NULL=/dev/null
qt () { "$@" >> $DEV_NULL 2>&1 ; } # stdout & stderr to /dev/null

Enable_GUIStringTable=$($nvram get Enable_GUIStringTable)
GUI_Region=$($nvram get GUI_Region)

CHARSET="iso-8859-1"
print_charset()
{
    if [ "$Enable_GUIStringTable" = 1 -a "x$GUI_Region" != "x" ];then
        case "$GUI_Region" in
            English)
                CHARSET="iso-8859-1"
                ;;
            German)
                CHARSET="iso-8859-1"
                ;;
            Japanese)
                CHARSET="Shift_JIS"
                ;;
            Chinese)
                CHARSET="GB2312"
                ;;
            *)
                CHARSET="iso-8859-1"
                ;;
            esac
    fi
    echo -n  "$CHARSET"
}
print_js_call() #$1: js name
{
	echo "<script language=javascript type=text/javascript src=$1></script>"
}

print_cgi_header () # $1: content_type
{
        local content_type date

        content_type="$1"
        [ "x$content_type" = "x" ] && content_type="text/html"
        date=`date -u '+%a, %d %b %Y %H:%M:%S %Z'`

cat <<EOF
Content-type: $content_type

EOF
}
lock_cgiwait_center_language()
{
        if [ -f /tmp/lock_web -a -f /tmp/lock_show_refreshpage ];then
                ipaddr=$(cat /tmp/lock_show_refreship)
                page=$(cat /tmp/lock_refreshpage)
                print_http_refresh "$ipaddr/cgi-bin/center_language.html" "2"
            exec >&-
            exit 0
        fi
}

lock_cgiwait_top ()
{
        if [ -f /tmp/lock_web -a -f /tmp/lock_show_refreshpage ];then
                ipaddr=$(cat /tmp/lock_show_refreship)
                page=$(cat /tmp/lock_refreshpage)
                print_top_refresh "$ipaddr/cgi-bin/top.html" "5"
            exec >&-
            exit 0
        fi
}

lock_cgiwait ()
{
	#if [ -f /tmp/lock_web -a -f /tmp/lock_refreshpage ];then
	if [ -f /tmp/lock_web ];then
		ipaddr=$(cat /tmp/lock_refreship)
		page=$(cat /tmp/lock_refreshpage)
		print_http_refresh "$ipaddr/cgi-bin/pls_wait.html" "1"
	    exec >&-
	    exit 0
	fi	
}

lock_cgiwait_show ()
{	
        if [ -f /tmp/lock_web -a -f /tmp/lock_show_refreshpage ];then
                ipaddr=$(cat /tmp/lock_refreship)
                page=$(cat /tmp/lock_show_refreshpage)
                print_http_refresh "$ipaddr/cgi-bin/pls_wait_show.html"
            exec >&-
            exit 0
        fi
}
print_language_js()
{
    local language_region
    if [ "$Enable_GUIStringTable" = 1 -a "x$GUI_Region" != "x" ];then
            if [ "$GUI_Region" != "English" ];then
                if [ -f "/www/html/cherry_test/languages_nonEnglish.js" ];then
			language_region=$(cat /tmp/multi_lang/language_region)
			language_region=$(echo -n $language_region)
			if [  "$GUI_Region" = "$language_region" ];then
				print_js_call "/cherry_test/languages_nonEnglish.js"
			else
				print_js_call "/languages.js"
			fi
		else
			print_js_call "/languages.js"
		fi
	    else
                print_js_call "/languages.js"
            fi
    else
        print_js_call "/languages.js"
    fi
}
print_http_header() #$1:the first js $2:the second js $3:the third js....
{
    local tmp 
    echo "<html><head>"
    if [ "$1" = "help" ]; then
    	echo '<link rel="stylesheet" href="/help.css">'
    else
    	echo '<link rel="stylesheet" href="/form.css">'
    fi
	echo '<Meta http-equiv="Pragma" Content="no-cache">'
	echo '<META HTTP-equiv="Cache-Control" content="no-cache">'
	echo '<Meta http-equiv="Expires" Content="0">'
	echo "<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>"
	print_language_js
    for tmp in $@
      do
      if echo $tmp | grep -q 'js$'; then
	  print_js_call $tmp
      fi
    done

cat <<EOF
	<script>window.document.title=device_title</script>
    <title>NETGEAR Router</title>
    </head>
EOF
}
print_menu_header()
{
    echo '<HTML><HEAD><TITLE>WNR1000</TITLE>'
    echo "<META http-equiv=content-type content='text/html;charset=$(print_charset)'>"
    echo '<META content="MSHTML 6.00.2800.1141" name=GENERATOR>'
	print_language_js
}
print_ca_http_header() #$1:the first js $2:the second js $3:the third js....
{
    local tmp
    echo "<html><head>"
    echo '<link rel="stylesheet" href="/style.css">'
	echo '<Meta http-equiv="Pragma" Content="no-cache">'
	echo '<META HTTP-equiv="Cache-Control" content="no-cache">'
    echo '<Meta http-equiv="Expires" Content="0">'
	echo "<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>"
	print_language_js
    for tmp in $@
      do
      if echo $tmp | grep -q 'js$'; then
          print_js_call $tmp
      fi
    done

cat <<EOF
    <title>${device_title}</title>
    </head>
EOF
}

print_body_header() #$1, help function $2, target html
{
	echo "<body onLoad=\"loadhelp('$1');loadvalue();\" bgcolor=#ffffff>"
	echo "<form method=\"post\" action=\"/cgi-bin/setobject.cgi?/cgi-bin/$2\" target=formframe>"
	echo "<input type=hidden name=submit_flag value=\"$3\">"
}

print_nobody_header() #$1, help function $2, target html
{
	echo "<body bgcolor=#ffffff>"
	echo "<form method=\"post\" action=\"/cgi-bin/setobject.cgi?/cgi-bin/$1\" >"
	echo "<input type=hidden name=submit_flag value=\"$2\">"
}

print_nocommit_header() #$1, help function $2, target html
{
	if [ "x$1" = "x" ];then
		echo "<body onLoad=\"loadvalue();\" bgcolor=#ffffff>"
	else	
		echo "<body onLoad=\"loadhelp('$1');loadvalue();\" bgcolor=#ffffff>"
	fi
	echo "<form method=\"post\" action=\"/cgi-bin/no_commit.cgi?/cgi-bin/$2\" >"
	echo "<input type=hidden name=submit_flag value=$3>"
}

print_noload_header()
{
        echo "<body onLoad=\"loadhelp('$1');\" bgcolor=#ffffff>"
        echo "<form method=\"post\" action=\"/cgi-bin/setobject.cgi?/cgi-bin/$2\" >"
        echo "<input type=hidden name=submit_flag value=\"$3\">"
}

print_nocommitload_header()
{
	if [ "x$1" = "x" ];then
		echo "<body bgcolor=#ffffff>"
    else
		echo "<body onLoad=\"loadhelp('$1');\" bgcolor=#ffffff>"
	fi
	echo "<form method=\"post\" action=\"/cgi-bin/no_commit.cgi?/cgi-bin/$2\" >"
    echo "<input type=hidden name=submit_flag value=$3>"
}

print_table_header() #$1 table header
{
	echo "<table width=100% border=0 cellpadding=0 cellspacing=3>"
	echo "<TR><TD colSpan=2><H1>$1</H1></TD></TR>"
	echo "<TR><TD colSpan=2></TD></TR><TR><td colspan=2><img src=/liteblue.gif width=100% height=12></td></TR>"
}

print_http_refresh () # $1: page to be refresh, $2: delay_time
{
        local delay_time

        delay_time="$2"
        [ "x$delay_time" = "x" ] && delay_time="0"

print_cgi_header "text/html"
cat <<EOF
<HTML>
<HEAD>  <meta http-equiv="Refresh" content="$delay_time; url=$1">
<Meta http-equiv="Pragma" Content="no-cache">
<META HTTP-equiv="Cache-Control" content="no-cache">
<Meta http-equiv="Expires" Content="0">
<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>
EOF
print_language_js
cat <<EOF
<link rel="stylesheet" href="/form.css">
</HEAD>
<BODY bgcolor=#ffffff>
<tr><td colspan=2><br><img src=/liteblue.gif width=100% height=12></td></tr>
<script>document.write(wait_message)</script>
</BODY>
</HTML>
EOF
}
print_top_refresh () # $1: page to be refresh, $2: delay_time
{
        local delay_time

        delay_time="$2"
        [ "x$delay_time" = "x" ] && delay_time="0"

print_cgi_header "text/html"
cat <<EOF
<HTML>
<HEAD>  <meta http-equiv="Refresh" content="$delay_time; url=$1">
<link rel="stylesheet" href="/form.css">
EOF
	echo "<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>"
	print_language_js
cat <<EOF
</HEAD>
<STYLE type=text/css>BODY {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; BACKGROUND: #ffffff; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px

}
</STYLE>
<BODY bgcolor=#ffffff marginwidth="0" marginheight="0">
<table width=100% border=0 cellpadding="0" cellspacing="3">
  <tr><td colspan="2"><IMG height=12 src="/darkblue.gif" width="100%" border=1></td></tr>
  <tr>
    <td rowspan="3" width=85%><IMG alt="NETGEAR Access Point Settings" hspace=0 src="/settings.gif" align=top border=0></td>
    <td><script>document.write(select_language)</script></td>
  </tr>
  <tr>
    <td>
        <select name="lang_avi" size=1 disabled>
            <option>$GUI_Region</option>
    </td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<img src="/spacer.gif" width="25" height="18" border="0" alt="" /><script>document.write('<input type="submit"  value="'+apply_mark+'" disabled>&nbsp;&nbsp;')</script></td>
  </tr>
</table>
</BODY>
</HTML>
EOF
}
print_http_footer()
{
	echo "</body>"
	echo "</html>"
	#if [ -f /tmp/lock_refreshpage ];then
	#	sleep 2
	#	rm /tmp/lock_refreshpage
	#	rm /tmp/lock_refreship
	#fi
}
show_charset()
{
    if [ "$Enable_GUIStringTable" = 1 -a "x$GUI_Region" != "x" ];then
        case "$GUI_Region" in
            English)
                echo -n "iso-8859-1"
                ;;
            German)
                echo -n "iso-8859-1"
                ;;
            Japanese)
                echo -n "Shift_JIS"
                ;;
            Chinese)
                echo -n "GB2312"
                ;;
            *)
                echo -n "iso-8859-1"
                ;;
            esac
    else
        echo -n "iso-8859-1"
    fi
}
show_src()
{
	local language_region
	if [ "$Enable_GUIStringTable" = 1 -a "x$GUI_Region" != "x" ];then
        	if [ "$GUI_Region" != "English" ];then
			if [ -f /www/html/cherry_test/languages_nonEnglish.js ];then
                        	language_region=$(cat /tmp/multi_lang/language_region)
                        	language_region=$(echo -n $language_region)
                        	if [  "$GUI_Region" = "$language_region" ];then
					echo -n "/cherry_test/languages_nonEnglish.js"
                        	else
					echo -n "/languages.js"
				fi
			else
				echo -n "/languages.js"
			fi
        	else
            		echo -n "/languages.js"
        	fi
    	else
        	echo -n "/languages.js"
    	fi
}
print_http_footer_wait()
{
	echo "</body>"
	echo "</html>"
}

print_http_footer_show()
{
        echo "</html>"
	if [ -f /tmp/lock_show_refreshpage ];then
		sleep 2
		rm /tmp/lock_show_refreshpage
	fi
}
		

show_en_dis() #$1: 1--enable 0--disable
{
    [ "$1" = "1" ] && echo -n $r_enable || echo -n $r_disable
}

show_yes_no()
{
     [ "$1" = "1" ] && echo -n $r_no || echo -n $r_yes
}
radio_check()
{
    [ "$1" = "$2" ] && echo -n CHECKED
}
enabled_check()
{
    [ "$1" = "$2" ] || echo -n DISABLED
}

select_check()
{
    [ "$1" = "$2" ] && echo -n SELECTED
}

get_wanif() #$1: wan proto
{
	local wan_if=$($nvram get wan_ifname)
	if [ "$1" = "pppoe" -o "$1" = "pptp" -o "$1" = "l2tp" ]; then
		wan_if=ppp0
	fi
	echo -n $wan_if
}

get_dns() #$1: 1 or 2
{
	local dns_file=/tmp/resolv.conf
	local local_tmp_file=/tmp/ABCDEFXXXX
	local dns_addr
	
	[ -f $dns_file ] && cat $dns_file | grep ^nameserver | sed 's/nameserver//g' > $local_tmp_file
	dns_addr=$(sed ''"$1"'p' -n $local_tmp_file)
	echo -n $dns_addr
}
