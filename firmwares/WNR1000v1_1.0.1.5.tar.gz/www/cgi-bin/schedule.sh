config_schedule()
{
	$nvram set schedule_days_to_block=$1
	$nvram set schedule_start_block_time=$2
	$nvram set hidden_schedule_end_block_time=$3
	$nvram set schedule_all_day=$4
	if [ $4 -eq 1 ];then
		$nvram set schedule_end_block_time="23:59"
	else
		$nvram set schedule_end_block_time=$3
	fi
}
