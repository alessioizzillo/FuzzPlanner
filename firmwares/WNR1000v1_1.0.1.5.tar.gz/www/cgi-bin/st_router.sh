config_router_add()
{
	add_num=$(ls /tmp/configs | grep static_router | grep -v ^size | wc -l)
	add_num=$(($add_num+1))
	$nvram set static_router$add_num="$2 $3 $4 $5 $6 $7 $8 $9"
}
config_router_eidtnum()
{
        $nvram set router_eidtnum=$1
}
config_router_edit()
{
	$nvram set static_router$1="$2 $3 $4 $5 $6 $7 $8 $9"
	rm -f /tmp/configs/router_eidtnum
}
config_router_del()
{
	rm -f /tmp/configs/static_router$1
	$nvram show | grep static_router | grep -v ^size | sort -n > /tmp/aa
	cat /tmp/aa | /bin/grep 'static_router[0-9]=' > /tmp/cc
	cat /tmp/aa | /bin/grep 'static_router[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/aa
	line=`grep "static_router" -c /tmp/aa`
	num=1
	while (test $num -le $line)
	do
		name=`sed ''"$num"'p' -n /tmp/aa | sed 's/static_router.*=//'`
		static_name=static_router$num
		$nvram set $static_name="$name"
		num=$(($num+1))
	done
	if [ $1 != $num ];then
		rm -f /tmp/configs/static_router$num
	fi
	rm -f /tmp/aa
}
