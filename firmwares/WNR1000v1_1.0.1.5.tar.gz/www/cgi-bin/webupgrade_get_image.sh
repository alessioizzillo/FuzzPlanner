#!/bin/sh
. /www/cgi-bin/functions.sh
. /www/cgi-bin/webupgrade.sh

write_webupgrade_status_of_download_image_file $STATUS_INITIALIZING
get_ctl_file_image_parameters $CTL_FILE_CLN 

write_webupgrade_status_of_download_image_file $STATUS_0_PERCENT
/www/cgi-bin/dl_ratio.cgi "$g_image_file_size" "$IMAGE_FILE" &
check_webupgrade_cancelled_in_download_image_file
if ! oc /bin/snarf "$NETGEAR_SITE_1$g_image_file_path" "$IMAGE_FILE"; then
	check_webupgrade_cancelled_in_download_image_file
	if ! oc /bin/snarf "$NETGEAR_SITE_2$g_image_file_path" "$IMAGE_FILE"; then
		check_webupgrade_cancelled_in_download_image_file
		if ! oc /bin/snarf "$NETGEAR_SITE_3$g_image_file_path" "$IMAGE_FILE"; then
			giveup_webupgrade_in_download_image_file $STATUS_DOWNLOAD_ERROR
		fi
	fi
fi
write_webupgrade_status_of_download_image_file $STATUS_100_PERCENT
/usr/bin/killall dl_ratio.cgi

check_webupgrade_cancelled_in_download_image_file
write_webupgrade_status_of_download_image_file $STATUS_FINISH
oc /usr/sbin/nvram set auto_upgrade_flag=1
