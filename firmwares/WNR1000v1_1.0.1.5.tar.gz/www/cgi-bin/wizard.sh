config_wizard_dhcp()
{
	$nvram set internet_type="1"
	$nvram set internet_ppp_type="0"
	$nvram set wan_ether_wan_assign="0"
	$nvram set wan_ether_dns_assign="0"
	$nvram set wan_hostname="$1"
	$nvram set wan_domain="$2"
	$nvram set wan_proto="dhcp"
	$nvram set run_test="$3"
}

config_wizard_pppoe()
{
	$nvram set internet_type="0"
	$nvram set internet_ppp_type="0"
	$nvram set wan_pppoe_username="$1"
	$nvram set wan_pppoe_passwd="$2"
	$nvram set wan_pppoe_service="$3"
	$nvram set wan_pppoe_idletime=$(($4*60))
	$nvram set wan_pppoe_wan_assign="$6"
        $nvram set wan_pppoe_ip="$7"
	    $nvram set wan_pppoe_dns_assign="$8"
    $nvram set wan_ether_dns1="$9"
    $nvram set wan_ether_dns2="${10}"
	$nvram set wan_proto="pppoe"	
	$nvram set run_test="$5"
}

config_wizard_static()
{
	$nvram set internet_type="1"
	$nvram set internet_ppp_type="0"
	$nvram set wan_ether_wan_assign="1"	
	$nvram set wan_ipaddr="$1"
	$nvram set wan_netmask="$2"
	$nvram set wan_gateway="$3"	
	$nvram set wan_ether_dns1="$4"
	$nvram set wan_ether_dns2="$5"	
	$nvram set wan_proto="static"	
	$nvram set run_test="$6"
}

config_wizard_bpa()
{
	$nvram set internet_type="0"
	$nvram set internet_ppp_type="2"
	$nvram set wan_bpa_username=$1
	$nvram set wan_bpa_password=$2
	$nvram set wan_bpa_servicename=$4	
	$nvram set wan_bpa_idle_time=$(($3*60))
	$nvram set wan_proto="bigpond"
	$nvram set run_test="$5"
}

config_wizard_pptp()
{
	$nvram set internet_type="0"
	$nvram set internet_ppp_type="1"
	$nvram set wan_pptp_username="$1"
	$nvram set wan_pptp_password="$2"
	$nvram set wan_pptp_idle_time=$(($3*60))
	$nvram set wan_pptp_local_ip="$4"
	$nvram set wan_pptp_server_ip="$5"
	$nvram set wan_pptp_connection_id="$6"
	$nvram set wan_pptp_wan_assign="$7"
	$nvram set wan_proto="pptp"
	$nvram set run_test="$8"
	$nvram set pptp_gw_static_route="$9"
}

config_thank_login()
{
	$nvram set thank_login="$1"
}

config_auto_check()
{
	$nvram set auto_check_for_upgrade="$1"
}
