config_wlan() #$1:ssid $2:broadcast 1--enable 0--disable
              #$3:country 0~11 
              #$4:channel $5:mode 0--b 1--auto 2--g $6:rate 0~12
{
    $nvram set wl_ssid="$1"
    $nvram set wl_country="$2"
    $nvram set wl_country_code="$2"
	$nvram set wl_hidden_channel=$3
    #if [ $3 -eq 0 ];then
    #	$nvram set wl_channel="11"
    #else
	$nvram set wl_channel="$3"		
    #fi
    $nvram set wl_simple_mode=$4
    if [ $4 -eq 4 ];then
    	$nvram set endis_xr=0
    fi
	
	#Up to 300Mbps, Europe, channel is larger than 7, set wl_simple_mode to 5
	#if [ $2 -eq 4 -a $4 -eq 3 ];then
	#	if [ $3 -gt 7 ];then
	#		$nvram set wl_simple_mode="5"
	#	fi
	#fi

	#UP to 300Mbps, channel is larger than 6, set wl_simple_mode to 5; channel is Auto, set wl_simple_mode to 6
	if [ $4 -eq 3 ]; then
		if [ $3 -gt 6 ]; then
			$nvram set wl_simple_mode="5"
		elif [ $3 -eq 0 ]; then
			$nvram set wl_simple_mode="6"
		fi
	fi

	# Always make 'keep existing wireless setting' checked
	$nvram set wps_status="5"
}
