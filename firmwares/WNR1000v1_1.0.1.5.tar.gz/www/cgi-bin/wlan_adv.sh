config_wladv() 
{
    $nvram set wl_rts=$1
    $nvram set wl_frag=$2
    $nvram set endis_wl_radio=$3
	if [ "$3" = "0" ];then
		$nvram set wds_endis_fun=0
	fi
    $nvram set endis_ssid_broadcast=$4
    $nvram set wl_plcphdr=$5
    $nvram set endis_pin=$6
    $nvram set wps_status=$7
    $nvram set endis_wl_wmm=$8	
    $nvram set antenna_mode=$9
}
