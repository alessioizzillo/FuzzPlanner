function getObj(name)
{
    if (document.getElementById)
    {
        return document.getElementById(name);
    }
    else if (document.all)
    {
        return document.all[name];
    }
    else if (document.layers)
    {
        return document.layers[name];
    }
}
function setIP(cf)
{
	var dflag = cf.WANAssign[0].checked;
	setDisabled(dflag,cf.pppoe_ip1,cf.pppoe_ip2,cf.pppoe_ip3,cf.pppoe_ip4);
	if (cf.WANAssign[1].checked)
	{
		cf.DNSAssign[1].checked = true;
		setDNS(cf);
	}
	DisableFixedIP = dflag;
}
function setDNS(cf)
{
	var dflag = cf.DNSAssign[0].checked;
	if (cf.WANAssign[1].checked)
	{
		cf.DNSAssign[1].checked=true;
		dflag = false;
	}
	setDisabled(dflag,cf.pppoe_dnsp1,cf.pppoe_dnsp2,cf.pppoe_dnsp3,cf.pppoe_dnsp4,cf.pppoe_dnss1,cf.pppoe_dnss2,cf.pppoe_dnss3,cf.pppoe_dnss4);
	DisableFixedDNS = dflag;
}

function setPolicy()
{
	var cf = document.forms[0];
	var select_index=cf.pppoe2_policy.selectedIndex;
	if(select_index== 0)
	{
		getObj("mul_doname").innerHTML=str3_div;
		cf.userdefined.disabled =false;
	}
	else if(select_index == 2)
	{
	
		getObj("mul_protocol").innerHTML=str1_div;
		getObj("mul_port").innerHTML=str2_div;
		cf.protocol.disabled=false;
		cf.portstart.disabled=false;
		cf.portend.disabled=false;
		
	}
	else if(select_index == 1)
	{
		getObj("mul_protocol").innerHTML=str1_div;
		getObj("mul_ip").innerHTML=str4_div;
		cf.protocol.disabled=false;
		cf.start_ip1.disabled =false;
                cf.start_ip2.disabled =false;
                cf.start_ip3.disabled =false;
                cf.start_ip4.disabled =false;
                cf.end_ip1.disabled =false;
                cf.end_ip2.disabled =false;
                cf.end_ip3.disabled =false;
                cf.end_ip4.disabled =false;

	}
	else if (select_index == 3)
	{
		cf.protocol.disabled=false;
        	cf.portstart.disabled=false;
        	cf.portend.disabled=false;
        	cf.userdefined.disabled =true;
		cf.start_ip1.disabled =false;
                cf.start_ip2.disabled =false;
                cf.start_ip3.disabled =false;
                cf.start_ip4.disabled =false;
                cf.end_ip1.disabled =false;
                cf.end_ip2.disabled =false;
                cf.end_ip3.disabled =false;
                cf.end_ip4.disabled =false;

	}
}

function check_mulpppoe_add(cf,flag)
{
	var txt,c;
	cf.hidden_portstart.value="--";
	cf.hidden_portend.value="--";
	cf.hidden_protocol_value.value="--";
	cf.hidden_userdefined.value="--";
	cf.hidden_ip_start.value="--";
	cf.hidden_ip_end.value="--";
	if(cf.pppoe2_policy.selectedIndex == 2 || cf.pppoe2_policy.selectedIndex == 3)
	{	
		if(cf.portstart.value==""||cf.portend.value=="")
		{
			alert(invalid_port);
			return false;
		}
		txt=cf.portstart.value;
		for(i=0;i<txt.length;i++)
		{
			c=txt.charAt(i);
			if("0123456789".indexOf(c,0)<0)
			{
				alert(invalid_start_port);
				return false;
			}
		}
		txt=cf.portend.value;
		for(i=0;i<txt.length;i++)
		{
			c=txt.charAt(i);
			if("0123456789".indexOf(c,0)<0)
			{
				alert(invalid_end_port);
				return false;
			}
		}
		if(parseInt(cf.portstart.value)<1||parseInt(cf.portstart.value)>65535)
		{
			alert(invalid_start_port);
			return false;
		}
		if(parseInt(cf.portend.value)<1||parseInt(cf.portend.value)>65535)
			{
				alert(invalid_end_port);
				return false;
			}
		if(parseInt(cf.portend.value)<parseInt(cf.portstart.value))
		{
			alert(end_port_greater);
			return false;
		}
		cf.hidden_portstart.value=cf.portstart.value;
		cf.hidden_portend.value=cf.portend.value;
	}
	if(cf.pppoe2_policy.selectedIndex == 0 )
	{
		txt=cf.userdefined.value;
		if(txt=="")
		{
			alert(invalid_user_type);
			return false;
		}
		for(i=0;i<cf.userdefined.value.length;i++)
	        {
        	        if(isValidChar_space(cf.userdefined.value.charCodeAt(i))==false)
               		{
                        	alert(invalid_user_type);
                        	return false;
                	}
        	}

		for(i=1;i<=array_num;i++)
        	{
				var str = eval ( 'mulpppoeArray' + i );
				var each_info=str.split(' ');
				if(flag == 'edit')
				{
	                if(each_info[1]==txt && i!=select_edit)
	                {
	                        alert(dup_doname);
	                        return false;
	                }
				}
				else
				{
					if(each_info[1]==txt)
	                {
	                        alert(dup_doname);
	                        return false;
	                }
				}
        }
		cf.hidden_userdefined.value=cf.userdefined.value;
	}
	else
		cf.hidden_protocol_value.value=cf.protocol.value;
	if(cf.pppoe2_policy.selectedIndex == 1 || cf.pppoe2_policy.selectedIndex == 3)	
	{
		cf.ip_start.value=cf.start_ip1.value+'.'+cf.start_ip2.value+'.'+cf.start_ip3.value+'.'+cf.start_ip4.value;
        	cf.ip_end.value=cf.end_ip1.value+'.'+cf.end_ip2.value+'.'+cf.end_ip3.value+'.'+cf.end_ip4.value;
		if(checkipaddr(cf.ip_start.value)==false)
		{
			alert(invalid_ip);
			return false;
		}
		if(checkipaddr(cf.ip_end.value)==false)
		{
			alert(invalid_ip);
			return false;
		}
		if(cp_ip2(cf.ip_start.value,cf.ip_end.value)==false)
		{
			alert(invalid_ip_rang);
			return false;
		}

		cf.hidden_ip_start.value=cf.ip_start.value;
		cf.hidden_ip_end.value=cf.ip_end.value

	}
	return true;
}


function check_mulpppoe_addnum(cf)
{
	cf.submit_flag.value="mulpppoe_addnum";
	cf.action="/cgi-bin/setobject.cgi?/cgi-bin/bas_mulpppoe_add.html";
	return true;
}

function check_mulpppoe_editnum(cf)
{
	if( array_num == "" )
	{
		alert(no_serv_edit);
		return false;
	}
	var count_select=0;
	var select_num;
	if( array_num == 1)
	{
		if(cf.select_mulpppoe.checked == true)
		{
			count_select++;
			select_num=1;
		}
	}
	else for(i=0;i<array_num;i++)
		if(cf.select_mulpppoe[i].checked == true)
		{
			count_select++;
			select_num=i+1;
		}
	if(count_select==0)
	{
		alert(select_serv_edit);
		return false;
	}
	else
	{
		cf.select_edit.value=select_num;
		cf.submit_flag.value="mulpppoe_editnum";
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/bas_mulpppoe_edit.html";
		return true;
	}
}

function check_mulpppoe(cf,check)
{	
	if(cf.pppoe_username.value=="")
	{
		alert(login_name_null);
		return false;
	}
	for(i=0;i<cf.pppoe_username.value.length;i++)
        {
                if(isValidChar(cf.pppoe_username.value.charCodeAt(i))==false)
                {
                        alert(loginname_not_allowed);
                        return false;
                }
        }
	for(i=0;i<cf.pppoe_password.value.length;i++)
        {
                if(isValidChar(cf.pppoe_password.value.charCodeAt(i))==false)
                {
                        alert(password_not_allowed);
                        return false;
                }
        }
        for(i=0;i<cf.pppoe_servicename.value.length;i++)
        {
                if(isValidChar(cf.pppoe_servicename.value.charCodeAt(i))==false)
                {
                        alert(servname_not_allowed);
                        return false;
                }
        }
	if(cf.pppoe_idle_time.value.length<=0)
	{
		alert(idle_time_null);
		return false;
	}
	else if(!_isNumeric(cf.pppoe_idle_time.value))
	{
		alert(invalid_idle_time);
		return false;
	}
	cf.conflict_wanlan.value=0;	 
	if(cf.WANAssign[1].checked)
	{
		cf.pppoe_ipaddr.value=cf.pppoe_ip1.value+'.'+cf.pppoe_ip2.value+'.'+cf.pppoe_ip3.value+'.'+cf.pppoe_ip4.value;
		if(checkipaddr(cf.pppoe_ipaddr.value)==false)
		{
			alert(invalid_ip);
			return false;
		}
		if(isSameSubNet(cf.pppoe_ipaddr.value,lan_subnet,lan_ip,lan_subnet) == true)
		{
			cf.conflict_wanlan.value=1;
		}
		if(isSameIp(cf.pppoe_ipaddr.value,lan_ip) == true)
		{
			cf.conflict_wanlan.value=1;
		}
	}	
	if(cf.DNSAssign[1].checked)
	{
		cf.pppoe_dnsaddr1.value=cf.pppoe_dnsp1.value+'.'+cf.pppoe_dnsp2.value+'.'+cf.pppoe_dnsp3.value+'.'+cf.pppoe_dnsp4.value;
                cf.pppoe_dnsaddr2.value=cf.pppoe_dnss1.value+'.'+cf.pppoe_dnss2.value+'.'+cf.pppoe_dnss3.value+'.'+cf.pppoe_dnss4.value;
                if(cf.pppoe_dnsaddr2.value=="...")
                        cf.pppoe_dnsaddr2.value="";

		if(checkipaddr(cf.pppoe_dnsaddr1.value)==false)
		{
			alert(invalid_primary_dns);
			return false;
		}
		if(cf.pppoe_dnsaddr2.value!="" && cf.pppoe_dnsaddr2.value!="0.0.0.0" )
			if(checkipaddr(cf.pppoe_dnsaddr2.value)==false)
			{
				alert(invalid_second_dns);
				return false;
			}
	}
	if(cf.pppoe2_session.selectedIndex!=0)
	{
		if(cf.pppoe2_username.value=="")
		{
			alert(login_name_null);
			return false;
		}
		for(i=0;i<cf.pppoe2_username.value.length;i++)
	        {
        	        if(isValidChar(cf.pppoe2_username.value.charCodeAt(i))==false)
                	{
                        	alert(loginname_not_allowed);
                        	return false;
                	}
        	}
       	 	for(i=0;i<cf.pppoe2_password.value.length;i++)
        	{
                	if(isValidChar(cf.pppoe2_password.value.charCodeAt(i))==false)
                	{
                        	alert(password_not_allowed);
                        	return false;
                	}
        	}
        	for(i=0;i<cf.pppoe2_servicename.value.length;i++)
        	{
                	if(isValidChar(cf.pppoe2_servicename.value.charCodeAt(i))==false)
                	{
                        	alert(servname_not_allowed);
                        	return false;
                	}
        	}
	
	}
	if( !( old_wan_type=="mulpppoe1"))
        	cf.change_wan_type.value=0;
	else if ( old_pppoe_wan_assign == "1")
	{
        	if( old_wan_ip!=cf.pppoe_ipaddr.value && cf.WANAssign[1].checked)
                	cf.change_wan_type.value=0;
        	else if(cf.WANAssign[0].checked)
                	cf.change_wan_type.value=0;
        	else
                	cf.change_wan_type.value=1;
	}
	else if( old_pppoe_wan_assign == "0")
	{
        	if( old_wan_ip!=cf.pppoe_ipaddr.value && cf.WANAssign[1].checked)
                	cf.change_wan_type.value=0;
        	else
                	cf.change_wan_type.value=1;
	}
	if (check == 1)
		cf.run_test.value="test"
	else
		cf.run_test.value="no"	
	return true;
}

function set_gray(check)
{
	cf=document.forms[0];
	if(check == 0)
	{
		cf.pppoe2_username.disabled = true;
		cf.pppoe2_password.disabled = true;
		cf.pppoe2_servicename.disabled = true;
	}
	else
	{
		cf.pppoe2_username.disabled = false;
		cf.pppoe2_password.disabled = false;
		cf.pppoe2_servicename.disabled = false;	
	}
}

function change_session()
{
	cf=document.forms[0];
	if( cf.pppoe2_session[0].selected == true )
	{
		cf.pppoe2_username.value=username;
		cf.pppoe2_password.value=password;
		set_gray(0);
	}
	else if( cf.pppoe2_session[1].selected == true )
	{
		set_gray(1);
		cf.pppoe2_username.value=west_username;
        cf.pppoe2_password.value=west_password;
	}
	else if( document.forms[0].pppoe2_session[2].selected == true )
	{
		set_gray(1);
		cf.pppoe2_username.value=east_username;
        cf.pppoe2_password.value=east_password;
	}
	else if( document.forms[0].pppoe2_session[3].selected == true )
	{
		set_gray(1);
		cf.pppoe2_username.value=other_username;
        cf.pppoe2_password.value=other_password;
	}
	
}


function check_mulpppoe_del(cf)
{
	if( array_num == "" )
	{
		alert(no_serv_del);
		return false;
	}
	var count_select=0;
	var select_num;
	if( array_num == 1)
	{
		if(cf.select_mulpppoe.checked == true)
		{
			count_select++;
			select_num=1;
		}
	}
	else for(i=0;i<array_num;i++)
		if(cf.select_mulpppoe[i].checked == true)
		{
			count_select++;
			select_num=i+1;
		}
	if(count_select==0)
	{
		alert(select_serv_del);
		return false;
	}
	else
	{
		cf.select_del.value=select_num;
		cf.submit_flag.value="mulpppoe_del";
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/bas_mulpppoe.html";
		return true;
	}
}
