config_block_services_add()
{
	add_num=$(ls /tmp/configs | grep block_services | grep -v ^size | wc -l)
	add_num=$(($add_num+1))
	$nvram set block_services$add_num="$1 $2 $3 $4 $5 $6 $7"
}

config_block_services_editnum()
{
	$nvram set blockserv_editnum=$1
}

config_block_services_edit()
{
	edit_num=$($nvram get blockserv_editnum)
	$nvram set block_services$edit_num="$1 $2 $3 $4 $5 $6 $7"
}

config_block_services_del()
{
	rm -f /tmp/configs/block_services$1 
	$nvram show | grep block_services | grep -v ^size | sort -n > /tmp/aa
	cat /tmp/aa | /bin/grep 'block_services[0-9]=' > /tmp/cc
	cat /tmp/aa | /bin/grep 'block_services[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/aa
	line=`grep "block_services" -c /tmp/aa`
	num=1
	while (test $num -le $line)
	do
		name=`sed ''"$num"'p' -n /tmp/aa | sed 's/block_services.*=//'`
		block_services_name=block_services$num
		$nvram set $block_services_name="$name"
		num=$(($num+1))
	done
	if [ $1 != $num ];then
		rm -f /tmp/configs/block_services$num 
	fi
	rm -f /tmp/aa
}

config_block_services_apply()
{
	$nvram set blockserv_ctrl=$1
}
