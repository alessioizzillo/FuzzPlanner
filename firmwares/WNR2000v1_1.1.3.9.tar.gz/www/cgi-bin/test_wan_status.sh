#!/bin/sh
# test if route has valid Internet connection

SUCC_FILE=/tmp/determine_wan_success
FAIL_FILE=/tmp/determine_wan_fail

nvram=/usr/sbin/nvram
wan_status="down"
info_get_wanproto=$($nvram get wan_proto)

if [ "$info_get_wanproto" = "dhcp" ]; then
	eth1_value=`ifconfig eth1 | grep "inet addr:"`
	if [ "x$eth1_value" != "x" ]; then
		wan_status="up"
	fi
elif [ "$info_get_wanproto" = "static" ]; then
	eth1_value=`ifconfig eth1 | grep "inet addr:"`
	if [ "x$eth1_value" != "x" ]; then
		wan_status="up"
	fi
elif [ "$info_get_wanproto" = "bigpond" ]; then
	info_get_bpa_status=$(cat /tmp/bpa_info | awk '{print $1}')
	eth1_value=`ifconfig eth1 | grep "inet addr:"`
	if [ "x$eth1_value" != "x" -a "$info_get_bpa_status" = "up" ]; then
		wan_status="up"
	fi
elif [ "$info_get_wanproto" = "pppoe" ]; then
	pppoe_status=/etc/ppp/ppp0-status
	pppoe_alive=0

	if [ -f $pppoe_status ]; then
		status=$(cat $pppoe_status)
		if [ "x$status" = "x1" ]; then
			pppoe_alive=1
		fi
	fi
	
	if [ "$pppoe_alive" = "1" ]; then
		ppp0_value=`ifconfig | grep ^ppp0`
		if [ "x$ppp0_value" != "x" ]; then
			wan_status="up"
		fi
	fi
elif [ "$info_get_wanproto" = "pptp" ]; then
	pptp_status=/etc/ppp/ppp0-status
	pptp_alive=0
	
	if [ -f $pptp_status ]; then
		status=$(cat $pptp_status)
		if [ "x$status" = "x1" ]; then
			pptp_alive=1
		fi
	fi

	if [ "$pptp_alive" = "1" ]; then
		ppp0_value=`ifconfig | grep ^ppp0` 
		if [ "x$ppp0_value" != "x" ]; then      
			wan_status="up"
		fi
	fi
elif [ "$info_get_wanproto" = "mulpppoe1" ]; then
#ppp1
	IP_FILE0=/etc/ppp/pppoe1-ip
	PPP0_STATUS=/etc/ppp/pppoe1-status
	info_get_wanip="0.0.0.0"
	if [ -f $PPP0_STATUS ]; then
		status=$(cat $PPP0_STATUS)
		if [ "x$status" = "x1" -a -f $IP_FILE0 ]; then
			wan_status="up"
		fi	
	fi
#ppp2	
	IP_FILE1=/etc/ppp/pppoe2-ip
	PPP1_STATUS=/etc/ppp/pppoe2-status
	info_get_wanip2="0.0.0.0"
	if [ -f $PPP1_STATUS ]; then
		status=$(cat $PPP1_STATUS)
		if [ "x$status" = "x1" -a -f $IP_FILE1 ]; then
			wan_status="up"
		fi	
	fi
fi

if [ "$wan_status" = "up" ]; then
	echo "There is an active internet connection!" > /dev/console
	touch $SUCC_FILE
        /www/cgi-bin/webupgrade_get_confile.sh "$1" &> /dev/null &
else
	echo "There is not an active internet connection!" > /dev/console
	touch $FAIL_FILE
fi

#sleep 30
#rm -f $SUCC_FILE
#rm -f $FAIL_FILE
