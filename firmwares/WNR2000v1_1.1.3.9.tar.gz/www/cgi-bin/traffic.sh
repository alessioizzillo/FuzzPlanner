config_traffic_apply ()
{
	$nvram set endis_traffic="$1"
if [ "$1" = "1" ];then
	$nvram set ctrl_volumn_time="$2"
	$nvram set restart_counter_time="$3"
	$nvram set traffic_restart_day="$4"
	$nvram set left_time_volumn="$5"
	$nvram set traffic_led="$6"
	$nvram set traffic_block_all="$7"
	if [ "$2" = "0" ];then
		$nvram set limit="$8"
		$nvram set mon_volumn_limit="$9"
		$nvram set round_up="${10}"
	else
		$nvram set mon_time_limit="${11}"	
	fi
fi
}

config_show_traffic_reset ()
{
	$nvram set show_traffic_timereset="$1"
}
