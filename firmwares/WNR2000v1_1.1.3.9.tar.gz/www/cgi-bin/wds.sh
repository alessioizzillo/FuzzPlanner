wds_ip_conflict ()
{
	if [ "$1" = "1" -a "$2" = "0" ];then
		/usr/bin/arping -b -c 2 -I br0 "$3" > /tmp/wds_conflict 2>&1
	fi
}
config_wds ()
{
	$nvram set wds_endis_fun="$1"
	if [ "$1" = "1" ];then
		$nvram set endis_wl_radio=1
		$nvram set wds_repeater_basic="$2"
		$nvram set repeater_ip="$3"
		$nvram set wds_endis_ip_client="$4"
		$nvram set basic_station_mac="$5"
		$nvram set wds_endis_mac_client="$6"
		$nvram set repeater_mac1="$7"
		$nvram set repeater_mac2="$8"
		$nvram set repeater_mac3="$9"
		$nvram set repeater_mac4="${10}"	
	fi
}
