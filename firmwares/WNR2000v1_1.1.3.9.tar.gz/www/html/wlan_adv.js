function checkadv(form)
{
	if(form.szRts_11g.value == "")
	{	
		alert(rts_null);
		return false;
	}
	if(form.szFrag_11g.value == "")
	{
		alert(fragmentation_null);
		return false;
	}

	if(!(form.szRts_11g.value > 0 && form.szRts_11g.value <= 2347))
	{	
		alert(rts_range);
		return false;
	}
	if(!(form.szFrag_11g.value > 255 && form.szFrag_11g.value < 2347))
	{
		alert(fragmentation_range);
		return false;
	}

	if(form.endis_ssid_broadcast.checked == true)
                form.enable_ssid_broadcast.value="1";
	else
	        form.enable_ssid_broadcast.value="0";
	if(form.endis_router.checked == true)
	        form.enable_router.value="1";
	else
	        form.enable_router.value="0";
	if(form.endis_wps.checked == true )
		form.endis_pin.value="1";
	else
		form.endis_pin.value="0";
	if(form.keep_exist.checked == true)
		form.endis_wsc_config.value="5";
	else
		form.endis_wsc_config.value="1";
/*	if(form.endis_wmm.checked ==true)
		form.endis_hidden_wmm.value="1";
	else
		form.endis_hidden_wmm.value="0";
*/
	if ( old_endis_wl_radio =="0" && form.enable_router.value == "0")
		form.wds_change_ip.value="still_lanip"
	else if( old_endis_wl_radio =="0" && form.enable_router.value == "1" )
	{
		if ( old_wds_endis_fun == "1" &&  old_wds_repeater_basic == "0" )
		{
			if(security_mode=="3" ||  security_mode=="4" || security_mode == "5")
	                {
        	                if(!confirm(wds_not_wpa))
                   	  	      	return false;
                        	else
				{
                                	location.href="wlan.html"
					return false;
				}
                	}
			else
			{
				if ( old_wds_endis_fun == '1' && old_wds_repeater_basic == '0' && old_endis_wl_radio == '1' )
	                                top.contents.location.href="menu_no_link_wds.html";
				else
					top.contents.location.href="menu_no_link.html";
				form.wds_change_ip.value="to_repeatip"
			}
		}
		else
			form.wds_change_ip.value="still_lanip"	
	}
	else if ( old_endis_wl_radio =="1" && form.enable_router.value == "0")
	{
		if ( old_wds_endis_fun == "1" &&  old_wds_repeater_basic == "0" )
                {
			if ( old_wds_endis_fun == '1' && old_wds_repeater_basic == '0' && old_endis_wl_radio == '1' )
                                top.contents.location.href="menu_no_link_wds.html";
			else
				top.contents.location.href="menu_no_link.html";
		        form.wds_change_ip.value="to_lanip"
               	}
		 else
                        form.wds_change_ip.value="still_lanip"
	}
	else
	{
		if ( old_wds_endis_fun == "1" &&  old_wds_repeater_basic == "0" )
			form.wds_change_ip.value="still_repeatip"
		else
			form.wds_change_ip.value="still_lanip"	
	}	
	return true;
}
