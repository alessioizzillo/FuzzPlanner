#!/bin/sh

EBTABLES="/usr/sbin/ebtables"
TC="/usr/sbin/tc"
IN="eth0"
OUT="vlan0002"
insmod=/sbin/insmod
rmmod=/sbin/rmmod
nvram=/usr/sbin/nvram
start()
{
	[ "x$(/usr/sbin/nvram get qos_endis_on)" = "x0" ] && return

	$insmod ebtables
	$insmod ebtable_filter
	$insmod ebt_ip
	$insmod ebt_mark

	qos_totalnum=$($nvram show | grep qos_list | grep -v ^size | wc -l)
	i=1
	#echo $qos_totalnum
	while [ $i -le $qos_totalnum ]
	do
		para=$(/usr/sbin/nvram get qos_list$i)
		#echo $para
		case $(echo $para | awk '{print $2}') in
		
			0)

			START=$(echo $para | awk '{print $6}')
			END=$(echo $para | awk '{print $7}')
			RANGE=$(echo $START $END | awk -F"[ ,]" '{for(m=1; m<=NF/2; m++){n=m+NF/2; print $m, $n}}')
			case $(echo $para | awk '{print $4}') in
				0)
				PRIO=1
				;;
				1)
				PRIO=2
				;;
				2)
				PRIO=4
				;;
				3)
				PRIO=8
				;;
			esac
			PROTO=$(echo $para | awk '{print $5}')
			if [ "x$(echo $PROTO | awk -F/ '{print $2}')" != "x" ]; then
				echo "$RANGE" | while read a b
				do 
				$EBTABLES -A FORWARD -p IPv4 --ip-proto 6 --ip-source-port $a:$b -j mark --set-mark $PRIO
				$EBTABLES -A FORWARD -p IPv4 --ip-proto 6 --ip-destination-port $a:$b -j mark --set-mark $PRIO
				$EBTABLES -A FORWARD -p IPv4 --ip-proto 17 --ip-source-port $a:$b -j mark --set-mark $PRIO
				$EBTABLES -A FORWARD -p IPv4 --ip-proto 17 --ip-destination-port $a:$b -j mark --set-mark $PRIO
				done
			elif [ "x$PROTO" = "xTCP" ]; then
				echo "$RANGE" | while read a b
				do
				$EBTABLES -A FORWARD -p IPv4 --ip-proto 6 --ip-source-port $a:$b -j mark --set-mark $PRIO
				$EBTABLES -A FORWARD -p IPv4 --ip-proto 6 --ip-destination-port $a:$b -j mark --set-mark $PRIO
				done
			elif [ "x$PROTO" = "xUDP" ]; then
				echo "$RANGE" | while read a b
				do
				$EBTABLES -A FORWARD -p IPv4 --ip-proto 17 --ip-source-port $a:$b -j mark --set-mark $PRIO
				$EBTABLES -A FORWARD -p IPv4 --ip-proto 17 --ip-destination-port $a:$b -j mark --set-mark $PRIO
				done
			fi
			;;	

			1)

			LPORT=$(echo $para | awk '{print $3}')
			PORT=$((4 - $LPORT))
			LPRIO=$(echo $para | awk '{print $4}')
			PRIO=$(($LPRIO + 1))
			echo ${PORT}${PRIO} > /proc/lan_prio_map
			;;
			
			2)

			MAC=$(echo $para | awk '{print $9}')
			case $(echo $para | awk '{print $4}') in
				0)
				PRIO=1
				;;
				1)
				PRIO=2
				;;
				2)
				PRIO=4
				;;
				3)
				PRIO=8
				;;
			esac
			$EBTABLES -A FORWARD --source $MAC -j mark --set-mark $PRIO
			$EBTABLES -A FORWARD --destination $MAC -j mark --set-mark $PRIO
			;;
		esac
		i=$(($i + 1))
	done

	if [ $i -gt 1 ]; then

		if [ $i -lt 5 ]; then
			BURST=12k
		elif [ $i -lt 10 ]; then
			BURST=11k
		elif [ $i -lt 15 ]; then
			BURST=10k
		elif [ $i -lt 20 ]; then
			BURST=8k
		elif [ $i -lt 25 ]; then
			BURST=6k
		elif [ $i -lt 30 ]; then
			BURST=5k
		else
			BURST=4k
		fi

		$TC qdisc add dev $OUT root handle 1: htb default 1
		$TC class add dev $OUT parent 1: classid 1:1 htb rate 100mbit burst $BURST
		$TC qdisc add dev $OUT parent 1:1 handle 10: prio bands 4 priomap 2 3 3 3 2 3 1 1 2 2 2 2 2 2 2 2
		$TC qdisc add dev $OUT parent 10:1 handle 11: sfq
		$TC qdisc add dev $OUT parent 10:2 handle 12: sfq
		$TC qdisc add dev $OUT parent 10:3 handle 13: sfq
		$TC qdisc add dev $OUT parent 10:4 handle 14: sfq

		$TC filter add dev $OUT parent 10: protocol ip prio 1 handle 1 fw classid 10:1
		$TC filter add dev $OUT parent 10: protocol ip prio 2 handle 2 fw classid 10:2
		$TC filter add dev $OUT parent 10: protocol ip prio 3 handle 4 fw classid 10:3
		$TC filter add dev $OUT parent 10: protocol ip prio 4 handle 8 fw classid 10:4
	
		$TC filter add dev $OUT parent 10: protocol ip prio 5 u32 match ip tos 0x00 0xfc flowid 10:3
		$TC filter add dev $OUT parent 10: protocol ip prio 6 u32 match ip tos 0xc0 0xc0 flowid 10:1
		$TC filter add dev $OUT parent 10: protocol ip prio 7 u32 match ip tos 0x80 0xc0 flowid 10:2
		$TC filter add dev $OUT parent 10: protocol ip prio 8 u32 match ip tos 0x40 0xc0 flowid 10:3
		$TC filter add dev $OUT parent 10: protocol ip prio 9 u32 match ip tos 0x00 0xc0 flowid 10:4  
	fi
}

stop()
{
	$EBTABLES -F 

	# $TC qdisc del dev $IN root
	$TC qdisc del dev $OUT root

	$rmmod ebt_mark
	$rmmod ebt_ip
	$rmmod ebtable_filter
	$rmmod ebtables
	echo "STOP OK"
}

status()
{
	$EBTABLES -L --Lc

	# $TC -s class ls dev $IN
	$TC -s class ls dev $OUT
}

case "$1" in
	start)
	start
	;;

	stop)
	stop
	;;

	restart)
	stop
	start
	;;

	status)
	status
	;;

	*)
	echo $"Usage:$0 {start|stop|restart|status}"
	exit 1
	;;

esac
