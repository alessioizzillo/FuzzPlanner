config_fdefault() 
{
    $nvram set restore_defaults=$1
}
