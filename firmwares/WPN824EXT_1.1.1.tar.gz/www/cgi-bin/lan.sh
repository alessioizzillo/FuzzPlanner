config_lan() #$1:ap name
             #$2:dhcp mode 1--enable 0--disable
             #$3:spanning tree 1--enable 0--disable
             #$4,$5,$6: ip address, subnet, gateway
{
    $nvram set netbiosname="$1"
    $nvram set lan_dhcp=$2
    $nvram set lan_stp=$3
    if [ $2 -eq 0 ]; then
        $nvram set lan_ipaddr=$4
        $nvram set lan_netmask=$5
        $nvram set lan_gateway=$6
    fi
}
active_lan()
{
    stp_enable=$($nvram get lan_stp)
    dhcp_enable=$($nvram get lan_dhcp)
    [ "$stp_enable" = "1" ] && $brctl stp br0 on || $brctl stp br0 off
    if [ "$dhcp_enable" = "0" ]; then
	killall udhcpc
	/sbin/ifconfig br0 "$($nvram get lan_ipaddr)" netmask "$($nvram get lan_netmask)"
    else
	killall udhcpc
	/sbin/ifconfig br0 0.0.0.0
	/sbin/udhcpc -i br0 &
    fi
}
