config_scienario() 
{
	$nvram set scienario=$1
}

config_scienario2()
{
        $nvram set scienario2=$1
}
