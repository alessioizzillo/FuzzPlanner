config_ureboot() 
{
    $nvram set reboot_ap=$1
}
