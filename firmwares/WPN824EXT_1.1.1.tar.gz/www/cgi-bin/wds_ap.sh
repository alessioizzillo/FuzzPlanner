config_wdsap() 
{
    $nvram set wds_mode=$1
	$nvram set wl_usermode="ap"
}
