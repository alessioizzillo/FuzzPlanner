config_multi_addmac() 
{
    $nvram set wds_add_maclist=$1
	$nvram set wds_btn_mode=$2
    $nvram set wds_add_ssidlist="ssid_1,ssid_2,ssid_3,ssid_4"
	$nvram set wds_add_chanlist="channel_1,channel_2,channel_3,channel_4"
	$nvram set wds_add_signallist="signal_1,signal_2,signal_3,signal_4"
}
