config_wdsptp() 
{
    $nvram set wds_mode=$1
	$nvram set wds_ptpmaconoff=$2
	$nvram set wds_ptpentry=$3
	$nvram set wl_ptplist=$3
	/sbin/iwlist wds1 scan
	/sbin/wlanconfig wds1 list scan > /tmp/a
	select_line=`grep $3 /tmp/a`
	if [ "x$select_line" = "x" ]; then
	{
		$nvram set wds_ptp_ssid=""
		$nvram set wds_ptp_channel=""
		$nvram set wds_ptp_signalstrength=""
	}
	else
	{
		show_line=`for i in \`echo "$select_line"\` ; do echo "$i" ; done`
		$nvram set wds_ptp_ssid=`echo "$show_line" | sed -n '1p'`
		$nvram set wds_ptp_channel=`echo "$show_line" | sed -n '3p'`
		$nvram set wds_ptp_signalstrength=`echo "$show_line" | sed -n '5p'`
	}
	fi
	$nvram set wl_usermode="ptp"
	rm /tmp/a
}
