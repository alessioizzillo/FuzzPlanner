config_wdsrepeater() 
{
    $nvram set wds_mode=$1
	$nvram set wds_repeaterentry=$2
	$nvram set wds_re_ssid="test_ssid"
	$nvram set wds_re_channel="test_channel"
	$nvram set wds_re_signalstrength="test_signalstrength" 
	$nvram set wl_usermode="rep"
}
