config_wdssta() 
{
    $nvram set wds_mode=$1	
	$nvram set wds_stadhcp=$2
	if [ $2 -eq 0 ];then
		$nvram set wds_staipaddr=$3
		$nvram set wds_stasubnet=$4
		$nvram set wds_stadfgate=$5
	fi
}
