#!/bin/sh 
. /www/cgi-bin/functions.sh
. /www/cgi-bin/webupgrade.sh

prepare_for_upgrade

check_wan_link ()
{
	return 0
}

#if ! check_wan_link ; then
#	giveup_webupgrade_in_download_control_file $STATUS_WAN_LINK_ERROR
#fi

#write_webupgrade_status_of_download_control_file $STATUS_INITIALIZING
write_webupgrade_status_of_download_control_file $STATUS_0_PERCENT
check_webupgrade_cancelled_in_download_control_file
if ! oc /bin/snarf "$NETGEAR_SITE_1$CTL_FILE_FULLNAME" "/tmp/$CTL_FILE"; then
	check_webupgrade_cancelled_in_download_control_file
	write_webupgrade_status_of_download_control_file $STATUS_33_PERCENT
	if ! oc /bin/snarf "$NETGEAR_SITE_2$CTL_FILE_FULLNAME" "/tmp/$CTL_FILE"; then
		write_webupgrade_status_of_download_control_file $STATUS_66_PERCENT
		check_webupgrade_cancelled_in_download_control_file
		if ! oc /bin/snarf "$NETGEAR_SITE_3$CTL_FILE_FULLNAME" "/tmp/$CTL_FILE"; then
			giveup_webupgrade_in_download_control_file $STATUS_DOWNLOAD_ERROR
		fi
	fi
fi
write_webupgrade_status_of_download_control_file $STATUS_100_PERCENT
oc echo "got $CTL_FILE successfully !" 

prepare_ctl_file_cln "/tmp/$CTL_FILE" $CTL_FILE_CLN

if ! get_ctl_file_parameters $CTL_FILE_CLN ; then
	giveup_webupgrade_in_download_control_file $STATUS_CONTROL_FILE_ERROR
fi

oc echo "image_file=$g_image_file_fullname"
oc echo "image_server=$g_image_server"
oc echo "image_file_size=$g_image_file_size"
oc echo "old_version=$g_image_ver_old"
oc echo "new_version=$g_image_ver_new"

if ! is_newer $g_image_ver_new $g_image_ver_old ; then
	giveup_webupgrade_in_download_control_file $STATUS_NO_NEWER_VER_ERROR
fi

write_webupgrade_status_of_download_control_file $STATUS_FINISH

