#!/bin/sh
. /www/cgi-bin/functions.sh
. /www/cgi-bin/webupgrade.sh

write_webupgrade_status_of_download_image_file $STATUS_INITIALIZING
get_ctl_file_parameters $CTL_FILE_CLN 
ftp_server1="ftp://$g_image_server"
ftp_server2=`echo $ftp_server1 |sed 's/1\./2./'`
ftp_server3=`echo $ftp_server1 |sed 's/1\./3./'`

write_webupgrade_status_of_download_image_file $STATUS_0_PERCENT
/www/cgi-bin/dl_ratio.cgi "$g_image_file_size" &
check_webupgrade_cancelled_in_download_image_file
if ! oc /bin/snarf "$ftp_server1$g_image_file_fullname" "$IMAGE_FILE"; then
	check_webupgrade_cancelled_in_download_image_file
	if ! oc /bin/snarf "$ftp_server2$g_image_file_fullname" "$IMAGE_FILE"; then
		check_webupgrade_cancelled_in_download_image_file
		if ! oc /bin/snarf "$ftp_server3$g_image_file_fullname" "$IMAGE_FILE"; then
			giveup_webupgrade_in_download_image_file $STATUS_DOWNLOAD_ERROR
		fi
	fi
fi
write_webupgrade_status_of_download_image_file $STATUS_100_PERCENT
/usr/bin/killall dl_ratio.cgi

check_webupgrade_cancelled_in_download_image_file
write_webupgrade_status_of_download_image_file $STATUS_FINISH
