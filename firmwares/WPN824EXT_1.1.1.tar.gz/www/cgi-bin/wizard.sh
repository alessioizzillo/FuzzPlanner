config_thank_login()
{
	$nvram set thank_login="$1"
}

config_auto_check()
{
	$nvram set auto_check_for_upgrade="$1"
}
