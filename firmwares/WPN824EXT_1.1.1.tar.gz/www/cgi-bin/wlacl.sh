config_wlacl_add()
{
	add_num=$($nvram show | grep wlacl | grep -v ^size | wc -l)
	add_num=$(($add_num+1))
	$nvram set wlacl$add_num="$1 $2"
	$nvram set wl_acl_num="$add_num"
}

config_wlacl_editnum()
{
	$nvram set wl_acl_editnum=$1
}

config_wlacl_edit()
{
	edit_num=$($nvram get wl_acl_editnum)
	$nvram set wlacl$edit_num="$1 $2"
}

config_wlacl_del()
{
	#rm -f /tmp/configs/wlacl$1
	$nvram unset wlacl$1
	$nvram show | grep wlacl | grep -v ^size > /tmp/aa
	cat /tmp/aa | /bin/grep 'wlacl[0-9]=' > /tmp/cc
	cat /tmp/aa | /bin/grep 'wlacl[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/aa
	line=`grep "wlacl" -c /tmp/aa`
	num=1
	while (test $num -le $line)
	do
		name=`sed ''"$num"'p' -n /tmp/aa | sed 's/wlacl.*=//'`
		wlacl_name=wlacl$num
		$nvram set $wlacl_name="$name"
		num=$(($num+1))
	done
	if [ $1 != $num ];then
	#	rm -f /tmp/configs/wlacl$num
		$nvram unset wlacl$num
	fi
	add_num=$($nvram show | grep wlacl | grep -v ^size | wc -l)
	$nvram set wl_acl_num="$add_num"
	rm -f /tmp/aa
}

config_wlacl_apply()
{
	$nvram set wl_access_ctrl_on=$1
}
