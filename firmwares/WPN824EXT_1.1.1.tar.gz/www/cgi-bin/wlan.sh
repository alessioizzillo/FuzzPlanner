config_wlan() #$1:ssid $2:broadcast 1--enable 0--disable
              #$3:country 0~11 
              #$4:channel $5:mode 0--b 1--auto 2--g $6:rate 0~12
{
    $nvram set wl_ssid="$1"
    #$nvram set wl_country="$2"
    $nvram set wl_hidden_channel=$3
    if [ $3 -eq 0 ];then
    	$nvram set wl_channel="11"
    else
	$nvram set wl_channel="$3"		
    fi
    $nvram set wl_mode=$4
}
