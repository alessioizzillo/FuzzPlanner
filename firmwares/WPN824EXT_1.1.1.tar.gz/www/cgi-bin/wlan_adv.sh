config_wladv() 
{
    $nvram set endis_ssid_broadcast=$1
    $nvram set wl_rts=$2
    $nvram set wl_frag=$3
    $nvram set wl_plcphdr=$4
    $nvram set endis_108=$5
    $nvram set endis_xr=$6
	$nvram set endis_wl_radio=$7
}
