function allow_click()
{
	location.href="acl_allow.html";
}

function block_click()
{
	location.href="acl_block.html";
}

function disable_click()
{
	location.href="acl_disable.html";
}


function changebtnmode(form)
{
	form.btn_mode.value=1;
	return true;
}

function maccheck(form)
{
	var mac11 = form.mac_addr1.value;
    mac11 = mac11.substr(1,1);
    if((mac11=="1")||(mac11=="3")||(mac11=="5")||(mac11=="7")||
       (mac11=="9")||(mac11=="b")||(mac11=="d")||(mac11=="f")||
       (mac11=="B")||(mac11=="D")||(mac11=="F"))
    {
		alert(invalid_mac);
        return false;
    }
    if((form.mac_addr1.value=="")||(form.mac_addr2.value=="")||
	   (form.mac_addr3.value=="")||(form.mac_addr4.value=="")||
       (form.mac_addr5.value=="")||(form.mac_addr6.value==""))
	{
		alert(enter_full_mac);
		return false;
	}
    if(((form.mac_addr1.value=="00")&&(form.mac_addr2.value=="00")&&
        (form.mac_addr3.value=="00")&&(form.mac_addr4.value=="00")&&
        (form.mac_addr5.value=="00")&&(form.mac_addr6.value=="00"))||
       ((form.mac_addr1.value=="ff")&&(form.mac_addr2.value=="ff")&&
        (form.mac_addr3.value=="ff")&&(form.mac_addr4.value=="ff")&&
        (form.mac_addr5.value=="ff")&&(form.mac_addr6.value=="ff"))||
       ((form.mac_addr1.value=="FF")&&(form.mac_addr2.value=="FF")&&
        (form.mac_addr3.value=="FF")&&(form.mac_addr4.value=="FF")&&
        (form.mac_addr5.value=="FF")&&(form.mac_addr6.value=="FF")))
	{
		alert(invalid_mac);
		return false;
	}
	if((form.mac_addr1.value.length!=2)||(form.mac_addr2.value.length!=2)||
	   (form.mac_addr3.value.length!=2)||(form.mac_addr4.value.length!=2)||
       (form.mac_addr5.value.length!=2)||(form.mac_addr6.value.length!=2))
	{
		alert(invalid_mac);
		return false;
	}
	return true;
}




function add_acl_mac(form,mode)
{
	var the_allow_entry = new Array();                                                          
	var the_block_entry = new Array();
	the_allow_entry = form.add_allowlist.value.split(',');
	the_block_entry = form.add_blocklist.value.split(',');
	
	if(form.add_allowlist.value.length < 17)
		the_allow_entry.length = 0;
	if(form.add_blocklist.value.length < 17)
		the_block_entry.length = 0;
	var all_entry_no = the_allow_entry.length + the_block_entry.length;
	var all_entry = new Array();
	
	var j = 0;
	for(i=0;i<the_allow_entry.length;i++)
	{
		all_entry[j++] = the_allow_entry[i];
		all_entry[j++] = 1;
	}
	for(i=0;i<the_block_entry.length;i++)
	{
        all_entry[j++] = the_block_entry[i];
        all_entry[j++] = 2;
	}
	
	var the_entry = new Array();
	var the_allow_entry_no = the_allow_entry.length;
	var the_block_entry_no = the_block_entry.length;
	for(i=0;i<all_entry_no;i++)	
	{
		the_entry[i]= [all_entry[i*2],all_entry[i*2+1]];
	}
	form.hidden_acl_mode.value=mode;
	if(form.hidden_acl_mode.value == 1)
	{
		if(the_allow_entry.length>127)
		{
			alert(allowed128);
			return;
		}
	}
	else if(form.hidden_acl_mode.value == 2)
	{	
		if(the_block_entry.length>127)
		{
			alert(blocked128);
			return;
		}
	}
	
	if(maccheck(form))
	{
		var the_mac = form.mac_addr1.value+":"+
					  form.mac_addr2.value+":"+
					  form.mac_addr3.value+":"+
					  form.mac_addr4.value+":"+
					  form.mac_addr5.value+":"+
                      form.mac_addr6.value;
		
		for(i=0;i<all_entry_no;i++)
		{
			if(the_mac == the_entry[i][0] || the_mac.toUpperCase() == the_entry[i][0])
			{
				if(the_entry[i][1]==1)
				{
					alert(duplicate_allowed_mac);
					return;
				}
				else if(the_entry[i][1]==2)
				{
					alert(duplicate_blocked_mac);
					return;
				}
			}
		}
		if(form.hidden_acl_mode.value == 1)
		{
			if(form.add_allowlist.value.length < 17)
				form.add_allowlist.value = the_mac.toUpperCase();
			else
				form.add_allowlist.value = form.add_allowlist.value + "," + the_mac.toUpperCase();
		}
		else if(form.hidden_acl_mode.value == 2)
		{
			if(form.add_blocklist.value.length < 17)
			{
				form.add_blocklist.value = the_mac.toUpperCase();
			}
			else
			{	
				form.add_blocklist.value = form.add_blocklist.value + ","+ the_mac.toUpperCase();
			}
		}
		
		form.btn_mode.value=2;
		form.submit_flag.value="acl_addmac"
		form.submit();      

	}
}


function mac_delete(number,form,mode)
{
	var buf = "";
		var the_allow_entry = new Array();                                                          
	var the_block_entry = new Array();
	the_allow_entry = form.add_allowlist.value.split(',');
	the_block_entry = form.add_blocklist.value.split(',');
	if(form.add_allowlist.value.length < 17)
		the_allow_entry.length = 0;
	if(form.add_blocklist.value.length < 17)
		the_block_entry.length = 0;
	var all_entry_no = the_allow_entry.length + the_block_entry.length;
	var all_entry = new Array();
	
	var j = 0;
	for(i=0;i<the_allow_entry.length;i++)
	{
		all_entry[j++] = the_allow_entry[i];
		all_entry[j++] = 1;
	}
	for(i=0;i<the_block_entry.length;i++)
	{
        all_entry[j++] = the_block_entry[i];
        all_entry[j++] = 2;
	}
	
	var the_entry = new Array();
	var the_allow_entry_no = the_allow_entry.length;
	var the_block_entry_no = the_block_entry.length;
	for(i=0;i<all_entry_no;i++)	
	{
		the_entry[i]= [all_entry[i*2],all_entry[i*2+1]];
	}
	
	if(mode == 1)
	{
		if(the_allow_entry.length == 1)
		{
			form.add_allowlist.value = "";
			the_allow_entry_no=0;
		}
		else
		{
			for(i=number;i<the_allow_entry.length-1;i++)
				the_allow_entry[i] = the_allow_entry[i+1];		
			the_allow_entry_no = the_allow_entry_no - 1;
			for(i=0;i<the_allow_entry_no-1;i++)
				buf = buf + the_allow_entry[i]+ ","; 
			buf = buf + the_allow_entry[i]; 	
			form.add_allowlist.value = buf;
		}
	}
	else if(mode == 2)
	{
		if(the_block_entry.length == 1)
		{
			form.add_blocklist.value = "";
			the_block_entry_no=0;
		}
		else
		{
			for(i=number;i<the_block_entry.length-1;i++)
                the_block_entry[i] = the_block_entry[i+1];    
		  
			the_block_entry_no = the_block_entry_no - 1;
			for(i=0;i<the_block_entry_no-1;i++)
				buf = buf + the_block_entry[i]+ ","; 
			buf = buf + the_block_entry[i]; 
			form.add_blocklist.value = buf;
		} 
	}
	
		form.btn_mode.value=2;
		form.submit_flag.value="acl_addmac";
		form.submit();     
}
