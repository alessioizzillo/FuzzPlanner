function click_backup()
{
	document.forms[0].action="NETGEAR_wpn824ext.cfg";
	document.forms[0].submit();
}

function check_restore()
{
	cf=document.forms[0];
	if(cf.filename.value.length == 0)
 	{
 		alert(filename_null);
		return false;
	}
	var filestr=cf.filename.value;
	var file_format=filestr.substr(filestr.lastIndexOf(".")+1);
	if(file_format!="cfg")
  	{
  		alert(not_cfg);
  		return false;
  	} 
	
	var win_file_name=filestr.substr(filestr.lastIndexOf("\\")+1);
	var unix_file_name=filestr.substr(filestr.lastIndexOf("/")+1);
	if(win_file_name == filestr && unix_file_name != filestr)
		file_name=unix_file_name;
	else if( win_file_name != filestr && unix_file_name == filestr)
		file_name=win_file_name;
	else if ( win_file_name == filestr && unix_file_name == filestr )
		file_name=win_file_name;	
	else
	{
		alert(invalid_filename);
		return false;
	}
	if(confirm(ask_for_restore))
	{	
		cf.action="/cgi-bin/upg_restore.cgi?/cgi-bin/restore_process.html"
		//if ( wds_endis_fun == '1' && wds_repeater_basic == '0' && endis_wl_radio == '1' )
        //		top.contents.location.href="menu_no_link_wds.html";
		//else
		//	top.contents.location.href="menu_no_link.html";
		cf.submit();
	}
	else 
		return false;
}

function click_yesfactory()
{
	cf=document.forms[0];
	cf.action="/cgi-bin/upg_factory.cgi?/pls_wait_reboot.html";
	//if ( wds_endis_fun == '1' && wds_repeater_basic == '0' && endis_wl_radio == '1' )
    //            top.contents.location.href="menu_no_link_wds.html";
    //else
	//	top.contents.location.href="menu_no_link.html";
	cf.submit();
		
}
