function setIP(cf)
{
	var dflag = cf.LANAssign[0].checked;
	setDisabled(dflag,cf.ether_ip1,cf.ether_ip2,cf.ether_ip3,cf.ether_ip4,cf.ether_mask1,cf.ether_mask2,cf.ether_mask3,cf.ether_mask4,cf.ether_gtw1,cf.ether_gtw2,cf.ether_gtw3,cf.ether_gtw4);
	if (cf.LANAssign[1].checked)
	{
		cf.DNSAssign[1].checked = true;
		setDNS(cf);
		cf.test.disabled =true;
	}
	else
		cf.test.disabled =false;
	DisableFixedIP = dflag;
}

function setDNS(cf)
{
	var dflag = cf.DNSAssign[0].checked;
	if (cf.LANAssign[1].checked)
	{
		cf.DNSAssign[1].checked=true;
		dflag = false;
	}
	setDisabled(dflag,cf.ether_dnsp1,cf.ether_dnsp2,cf.ether_dnsp3,cf.ether_dnsp4,cf.ether_dnss1,cf.ether_dnss2,cf.ether_dnss3,cf.ether_dnss4);
	DisableFixedDNS = dflag;
}

function check_wizard_dhcp(check)
{
	cf=document.forms[0];
/*	
	if(cf.ac_name.value=="")
	{
		alert(account_name_null);
		return false;
	}
	for(i=0;i<cf.ac_name.value.length;i++)
        {
                if(isValidChar_space(cf.ac_name.value.charCodeAt(i))==false)
                {
                        alert(acname_not_allowed);
                        return false;
                }
        }
	for(i=0;i<cf.do_name.value.length;i++)
        {
                if(isValidChar_space(cf.do_name.value.charCodeAt(i))==false)
                {
                        alert(doname_not_allowed);
                        return false;
                }
        }
*/
	if (check == 1)
		cf.run_test.value="test"
	else
		cf.run_test.value="no"
	return true;
}

function check_static_ip_mask_gtw()
{
	cf=document.forms[0];
	cf.ether_ipaddr.value=cf.ether_ip1.value+'.'+cf.ether_ip2.value+'.'+cf.ether_ip3.value+'.'+cf.ether_ip4.value;
	cf.ether_subnet.value=cf.ether_mask1.value+'.'+cf.ether_mask2.value+'.'+cf.ether_mask3.value+'.'+cf.ether_mask4.value;
	cf.ether_gateway.value=cf.ether_gtw1.value+'.'+cf.ether_gtw2.value+'.'+cf.ether_gtw3.value+'.'+cf.ether_gtw4.value;
	if(checkipaddr(cf.ether_ipaddr.value)==false)
	{
		alert(invalid_ip);
		return false;
	}
	if(checksubnet(cf.ether_subnet.value)==false)
	{
		alert(invalid_mask);
		return false;
	}
	if(checkgateway(cf.ether_gateway.value)==false)
	{
		alert(invalid_gateway);
		return false;
	}
	if(isSameSubNet(cf.ether_ipaddr.value,cf.ether_subnet.value,cf.ether_gateway.value,cf.ether_subnet.value) == false)
	{
		alert(same_subnet_ip_gtw);
		return false;
	}
	return true;
}

function check_static_dns()
{
	var cf=document.forms[0];
	cf.ether_dnsaddr1.value=cf.ether_dnsp1.value+'.'+cf.ether_dnsp2.value+'.'+cf.ether_dnsp3.value+'.'+cf.ether_dnsp4.value;
	cf.ether_dnsaddr2.value=cf.ether_dnss1.value+'.'+cf.ether_dnss2.value+'.'+cf.ether_dnss3.value+'.'+cf.ether_dnss4.value;
	if(checkipaddr(cf.ether_dnsaddr1.value)==false)
	{
		alert(invalid_primary_dns);
		return false;
	}
	if(cf.ether_dnsaddr2.value=="...")
		cf.ether_dnsaddr2.value="";
	if(cf.ether_dnsaddr2.value!="")
	{
		if(checkipaddr(cf.ether_dnsaddr2.value)==false)
		{
			alert(invalid_second_dns);
			return false;
		}
	}
	return true;
}

function check_ether_samesubnet()
{
	var cf=document.forms[0];
        cf.ether_ipaddr.value=cf.ether_ip1.value+'.'+cf.ether_ip2.value+'.'+cf.ether_ip3.value+'.'+cf.ether_ip4.value;
        cf.ether_subnet.value=cf.ether_mask1.value+'.'+cf.ether_mask2.value+'.'+cf.ether_mask3.value+'.'+cf.ether_mask4.value;
        cf.ether_gateway.value=cf.ether_gtw1.value+'.'+cf.ether_gtw2.value+'.'+cf.ether_gtw3.value+'.'+cf.ether_gtw4.value;
	return true;
}

function check_wizard_static(check)
{
	var cf=document.forms[0];
	if(check_static_ip_mask_gtw()==false)
		return false;
	if(check_ether_samesubnet()==false)
		return false;	
	if(check_static_dns()==false)
		return false;		
	if (check == 1)
		cf.run_test.value="test"
	else
		cf.run_test.value="no"	
	return true;
}

function check_ether(cf,check)
{
        cf.ether_ipaddr.value=cf.ether_ip1.value+'.'+cf.ether_ip2.value+'.'+cf.ether_ip3.value+'.'+cf.ether_ip4.value;
        cf.ether_subnet.value=cf.ether_mask1.value+'.'+cf.ether_mask2.value+'.'+cf.ether_mask3.value+'.'+cf.ether_mask4.value;
        cf.ether_gateway.value=cf.ether_gtw1.value+'.'+cf.ether_gtw2.value+'.'+cf.ether_gtw3.value+'.'+cf.ether_gtw4.value;
    if((cf.ether_subnet.value=="0.0.0.0")||(cf.ether_subnet.value=="255.255.255.255")) 
    {
	  alert(invalid_mask);
	  return false;
	}
	if(check_wizard_dhcp(check)==false)
		return false;

	if(cf.LANAssign[1].checked == true)
	{
		if(check_static_ip_mask_gtw()==false)
			return false;
	}
	if(cf.DNSAssign[1].checked)
	{

		if(check_static_dns()==false)
			return false;
	}
        if(isSameIp(cf.ether_ipaddr.value,old_lan_ip)==false)
        {
                var askstr=changelanip+cf.ether_ipaddr.value+" ?";
                if(!confirm(askstr))
                        return false;
                alert(changelanip_renew);
                cf.changeip_flag.value=1;
                cf.action="/cgi-bin/setobject.cgi?/cgi-bin/welcomeok.html"
                return true;
        }
/*
		if(cf.LANAssign[0].checked == true)
		{
			var askstr = changelanip_auto;
			if(!confirm(askstr))
				return false;
			alert(changelanip_renew);
			cf.changeip_flag.value=1;
			cf.action="/cgi-bin/setobject.cgi?/cgi-bin/welcomeok.html"
            return true;
		}
*/		
	return true;
}

function check_welcome_dhcp()
{
	var cf = document.forms[0];
	//parent.welcome_wan_type=2;
	location.href="ca_05_SSID.html";
}

function check_welcome_static()
{
	var cf = document.forms[0];
        cf.ether_ipaddr.value=cf.ether_ip1.value+'.'+cf.ether_ip2.value+'.'+cf.ether_ip3.value+'.'+cf.ether_ip4.value;
        cf.ether_subnet.value=cf.ether_mask1.value+'.'+cf.ether_mask2.value+'.'+cf.ether_mask3.value+'.'+cf.ether_mask4.value;
        cf.ether_gateway.value=cf.ether_gtw1.value+'.'+cf.ether_gtw2.value+'.'+cf.ether_gtw3.value+'.'+cf.ether_gtw4.value;
        cf.ether_dnsaddr1.value=cf.ether_dnsp1.value+'.'+cf.ether_dnsp2.value+'.'+cf.ether_dnsp3.value+'.'+cf.ether_dnsp4.value;
        cf.ether_dnsaddr2.value=cf.ether_dnss1.value+'.'+cf.ether_dnss2.value+'.'+cf.ether_dnss3.value+'.'+cf.ether_dnss4.value;
	if(cf.ether_dnsaddr2.value=="...")
		cf.ether_dnsaddr2.value="";
	if(check_wizard_static(0)==false)
			return false;	
/*			
	parent.welcome_wan_type=1;
	parent.static_ip=cf.ether_ipaddr.value;
	parent.static_subnet=cf.ether_subnet.value;
	parent.static_gateway=cf.ether_gateway.value;
	parent.static_dns1=cf.ether_dnsaddr1.value;
	parent.static_dns2=cf.ether_dnsaddr2.value;*/
	location.href="ca_05_SSID.html";
}
