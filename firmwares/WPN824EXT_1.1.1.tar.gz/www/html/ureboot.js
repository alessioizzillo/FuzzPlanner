function clickReboot(form)
{
	if(form.reboot_ap[0].checked)
	{
		if(confirm("This will reboot the AP."))
		{
			top.contents.location.href="menu.html";
			return true;
		}
	}
	else
	{
		alert("Please select 'yes' and then press [ Apply ] to reboot the AP.");
		return false;
	}
}