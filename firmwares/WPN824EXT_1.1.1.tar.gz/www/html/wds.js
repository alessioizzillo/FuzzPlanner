function wdsWaring()
{
    var cf=document.forms[0];
    if(cf.enable_wds_fun.checked)
	{
		if ( wlan_channel == 0 )
	                {
	                        alert(wds_auto_channel);
	                        location.href="wlan.html";
	                }
	    if(security_mode=="3" ||  security_mode=="4" || security_mode == "5")
	    {
	        alert(wds_not_wpa)
	        location.href="wlan.html"
	    }
	}
}

function click_endis_wds()
{
	var cf=document.forms[0];
    var dflag;
    dflag=(!(cf.enable_wds_fun.checked));
    setDisabled ( dflag, cf.wds_repeater_basic[0], cf.disable_ip_client,cf.re_ip1,cf.re_ip2,cf.re_ip3,cf.re_ip4, cf.disable_mac_client, cf.basic_station_mac, cf.wds_repeater_basic[1], cf.disable_mac_client, cf.repeater_mac1, cf.repeater_mac2, cf.repeater_mac3, cf.repeater_mac4);
	if(cf.enable_wds_fun.checked)
		click_repeater_basic();
}

function click_repeater_basic()
{
	var cf=document.forms[0];
    var aflag;
	aflag=(!(cf.wds_repeater_basic[0].checked));
	bflag=(!(cf.wds_repeater_basic[1].checked));
	setDisabled ( aflag, cf.disable_ip_client,cf.re_ip1,cf.re_ip2,cf.re_ip3,cf.re_ip4,cf.disable_mac_client, cf.basic_station_mac);
	setDisabled ( bflag, cf.disable_mac_client, cf.repeater_mac1, cf.repeater_mac2, cf.repeater_mac3, cf.repeater_mac4);
}

function check_wds (cf)
{
	var count_mac=0;
	cf.change_ip_flag.value=0;
	if(cf.enable_wds_fun.checked)
	{
		cf.wds_endis_fun.value=1;
		if(cf.wds_repeater_basic[0].checked == true)
		{
			cf.repeater_ip.value=cf.re_ip1.value+'.'+cf.re_ip2.value+'.'+cf.re_ip3.value+'.'+cf.re_ip4.value;
			if( checkipaddr(cf.repeater_ip.value)== false )
			{	
				alert(invalid_wds_ip);
				return false;
			}
			if (old_wds_endis_fun == 1 && old_wds_repeater_basic == 0)
			{
				if(isSameIp(old_repeater_ip,cf.repeater_ip.value) == false)
					cf.change_ip_flag.value=1;
				else
					cf.change_ip_flag.value=0;
			}	
			else
			{
				if(isSameIp(old_lanip,cf.repeater_ip.value) == false)
					cf.change_ip_flag.value=1;
				else
					cf.change_ip_flag.value=0;
			}
			if(cf.disable_ip_client.checked == true)
				cf.wds_endis_ip_client.value=1;
			else
				cf.wds_endis_ip_client.value=0;
				
			if(cf.basic_station_mac.value.length==12) 
			{ 
				var mac=cf.basic_station_mac.value; 
  
				cf.basic_station_mac.value=mac.substr(0,2)+":"+mac.substr(2,2)+":"+mac.substr(4,2)+":"+mac.substr(6,2)+":"+mac.substr(8,2)+":"+mac.substr(10,2); 
			} 				
			if(maccheck_wds(cf.basic_station_mac.value) == 1 )
			{
				alert(invalid_mac_basic_station);
				return false;
			}
			else if(maccheck_wds(cf.basic_station_mac.value) == 2)
			{
				alert(mac_basic_station_null);
				return false;
			}
		}
		else if(cf.wds_repeater_basic[1].checked == true)
		{
			if(cf.disable_mac_client.checked == true)
				cf.wds_endis_mac_client.value=1;
			else
				cf.wds_endis_mac_client.value=0;
				
			if(cf.repeater_mac1.value.length==12) 
			{ 
				var mac=cf.repeater_mac1.value; 
  
				cf.repeater_mac1.value=mac.substr(0,2)+":"+mac.substr(2,2)+":"+mac.substr(4,2)+":"+mac.substr(6,2)+":"+mac.substr(8,2)+":"+mac.substr(10,2); 
			} 				
			if(maccheck_wds(cf.repeater_mac1.value) == 1)
			{
				alert(invalid_mac1);
				return false;
			}
			else if(maccheck_wds(cf.repeater_mac1.value) == 2)
			{
				count_mac++;
			}

			if(cf.repeater_mac2.value.length==12) 
			{ 
				var mac=cf.repeater_mac2.value; 
  
				cf.repeater_mac2.value=mac.substr(0,2)+":"+mac.substr(2,2)+":"+mac.substr(4,2)+":"+mac.substr(6,2)+":"+mac.substr(8,2)+":"+mac.substr(10,2); 
			} 			
			if(maccheck_wds(cf.repeater_mac2.value) == 1)
			{
				alert(invalid_mac2);
				return false;
			}
			else if(maccheck_wds(cf.repeater_mac2.value) == 2)
			{
				count_mac++;
			}	

			if(cf.repeater_mac3.value.length==12) 
			{ 
				var mac=cf.repeater_mac3.value; 
  
				cf.repeater_mac3.value=mac.substr(0,2)+":"+mac.substr(2,2)+":"+mac.substr(4,2)+":"+mac.substr(6,2)+":"+mac.substr(8,2)+":"+mac.substr(10,2); 
			}			
			if(maccheck_wds(cf.repeater_mac3.value) == 1)
			{
				alert(invalid_mac3);
				return false;
			}
			else if(maccheck_wds(cf.repeater_mac3.value) == 2)
			{
				count_mac++;
			}		

			if(cf.repeater_mac4.value.length==12) 
			{ 
				var mac=cf.repeater_mac4.value; 
  
				cf.repeater_mac4.value=mac.substr(0,2)+":"+mac.substr(2,2)+":"+mac.substr(4,2)+":"+mac.substr(6,2)+":"+mac.substr(8,2)+":"+mac.substr(10,2); 
			}			
			if(maccheck_wds(cf.repeater_mac4.value) == 1)
			{
				alert(invalid_mac4);
				return false;
			}
			else if(maccheck_wds(cf.repeater_mac4.value) == 2)
			{
				count_mac++;
			}		

			if(count_mac==4)
			{
				alert(all_mac_null);
				return false;
			}
		}
		if(security_mode=="3" ||  security_mode=="4" || security_mode == "5")
		{
			if(!confirm(wds_not_wpa))
				return false;
			else
				location.href="wlan.html"
		}
		else
		{
			//if ( old_wds_endis_fun == '1' && old_wds_repeater_basic == '0' && endis_wl_radio == '1' )
	        //                top.contents.location.href="menu_no_link_wds.html";
			//else
			//	top.contents.location.href="menu_no_link.html";
			cf.submit();
		}
	}
	else
	{
		cf.wds_endis_fun.value=0;
		if(old_wds_endis_fun==0)
			cf.change_ip_flag.value=0;
		else
			cf.change_ip_flag.value=1;
		//if ( old_wds_endis_fun == '1' && old_wds_repeater_basic == '0' && endis_wl_radio == '1' )
          //              top.contents.location.href="menu_no_link_wds.html";
		//else
		//	top.contents.location.href="menu_no_link.html";
		cf.submit();
	}

}
