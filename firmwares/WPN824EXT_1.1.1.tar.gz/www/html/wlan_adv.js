function checkadv(form)
{
	if(form.szRts_11g.value == "")
	{	
		alert('RTS Threshold value is NULL.');
		return false;
	}
	if(form.szFrag_11g.value == "")
	{
		alert('Fragmentation Length value is NULL.');
		return false;
	}	
	if(form.szRts_11g.value < 1 || form.szRts_11g.value > 2347)
	{	
		alert('CTS / RTS Threshold value is out of range [1 - 2347].');
		return false;
	}
	if(form.szFrag_11g.value < 256 || form.szFrag_11g.value > 2346)
	{
		alert('Fragmentation Length value is out of range [256 - 2346].');
		return false;
	}	
        if(form.endis_ssid_broadcast.checked == true)
                form.enable_ssid_broadcast.value="1";
        else
                form.enable_ssid_broadcast.value="0";
        if(form.endis_router.checked == true)
                form.enable_router.value="1";
        else
                form.enable_router.value="0";
	if(form.dis_feat.checked == true )
                form.endis_108.value="1";
        else
                form.endis_108.value="0";
        if(form.en_feat.checked == true)
                form.endis_xr.value="1";
        else
                form.endis_xr.value="0";
	return true;
}
