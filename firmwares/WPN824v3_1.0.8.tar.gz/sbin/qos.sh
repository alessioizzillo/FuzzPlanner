#!/bin/sh
TC="/usr/sbin/tc"
IPTABLES="/usr/sbin/iptables"
NVRAM="/usr/sbin/nvram"
ECHO="/bin/echo"
IFCONFIG="/sbin/ifconfig"
WAN_IF="$($NVRAM get wan_ifnames)"
WAN_PROTO="$($NVRAM get wan_proto)"
FILTER_ADD="$TC filter add dev $WAN_IF"
UPRATE="$($NVRAM get qos_uprate)"
QoS_ENABLE="$($NVRAM get qos_endis_on)"
BANDCTL="$($NVRAM get qos_threshold)"

start(){
	if [ "x$QoS_ENABLE" != "x1" ]; then
		$ECHO -n 0:$BANDCTL > /proc/MFS
		return
	fi

	if [ "x$WAN_PROTO" = "xpptp" ]; then
                if [ "x$BANDCTL" = "x0" ] || [ $UPRATE -le 0 ] || [ $UPRATE -gt 24576 ]; then
                        UPRATE=24576
                fi
        elif [ "x$WAN_PROTO" = "xpppoe" ]; then
                if [ "x$BANDCTL" = "x0" ] || [ $UPRATE -le 0 ] || [ $UPRATE -gt 31744 ]; then
                        UPRATE=31744
                fi
        else
                if [ "x$BANDCTL" = "x0" ] || [ $UPRATE -le 0 ] || [ $UPRATE -gt 41984 ]; then
                        UPRATE=41984
                fi
        fi

	$ECHO -n $UPRATE:$BANDCTL > /proc/MFS
}

stop(){
	$ECHO -n 0:$BANDCTL > /proc/MFS
}

status(){
	$IPTABLES -t mangle -nvL
}

case "$1" in
        stop)
        stop
        ;;
        start | restart )
        start
        ;;
        status)
        status
        ;;
        *)
        echo $"Usage:$0 {start|stop|restart|status}"
        exit 1
esac
