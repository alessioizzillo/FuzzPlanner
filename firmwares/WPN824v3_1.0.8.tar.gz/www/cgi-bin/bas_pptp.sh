config_pptp()
{
	$nvram set wan_proto="pptp"
	$nvram set internet_type="0"
	$nvram set internet_ppp_type="1"
	$nvram set wan_pptp_username="$1"
	$nvram set wan_pptp_password="$2"
	$nvram set wan_pptp_idle_time=$(($3*60))
	$nvram set wan_pptp_local_ip="$4"
	$nvram set wan_pptp_server_ip="$5"
	$nvram set wan_pptp_connection_id="$6"
	$nvram set wan_pptp_dns_assign=$7
	$nvram set wan_ether_dns1=$8
	$nvram set wan_ether_dns2=$9	
	$nvram set wan_pptp_mac_assign=${10}
	if [ "${10}" = "2" ];then
		$nvram set wan_pptp_this_mac=${11}	
	fi
	$nvram set wan_pptp_wan_assign=${12}
	$nvram set wan_proto="pptp"
	$nvram set change_wan_type=${13}
	$nvram set run_test="${14}"
	$nvram set wan_endis_dod="${15}"
	$nvram set pptp_gw_static_route="${16}"
}
