#!/bin/sh

nvram="/usr/sbin/nvram"
fw_sh="/www/cgi-bin/firewall_function.sh"

firewall_stop()
{
	/usr/sbin/net-wall stop
}

firewall_start()
{
	$fw_sh sched_rule
	/usr/sbin/net-wall start
}

config_net_wall()
{
	if [ "$1" = "lan_setup" -o "$1" = "wan_setup" -o "$1" = "remote_management" -o "$1" = "port_forward" ] ; then
		/usr/sbin/net-wall rule
	fi
}

case "$1" in
	stop)
		firewall_stop
	;;
	start)
		config_net_wall "$($nvram get forfirewall)"
		firewall_start
		$nvram set forfirewall=0
	;;
	restart)
		config_net_wall "$($nvram get forfirewall)"
		firewall_start
		$nvram set forfirewall=0
	;;
	*)
		logger -- "I donnt know what you want the firewall to do"
	;;
esac

