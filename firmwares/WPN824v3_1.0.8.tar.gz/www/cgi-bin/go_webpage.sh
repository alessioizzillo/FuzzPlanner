#!/bin/sh

SUCC_FILE=/tmp/determine_wan_success
FAIL_FILE=/tmp/determine_wan_fail

if [ -f $SUCC_FILE ]; then
#	rm -f $SUCC_FILE
	echo 0	# wan has valid connection
elif [ -f $FAIL_FILE ]; then
#	rm -f $FAIL_FILE
	echo 1	# wan doesn't have valid connection
else
	echo 2	# not determined wan connection yet
fi
