config_reservation_add()
{
	add_num=$(ls /tmp/configs | grep reservation | grep -v ^size | wc -l)
	add_num=$(($add_num+1))
	$nvram set reservation$add_num="$1 $2 $3"
}

config_reservation_editnum()
{
	$nvram set resev_editnum=$1
}

config_reservation_edit()
{
	edit_num=$($nvram get resev_editnum)
	$nvram set reservation$edit_num="$1 $2 $3"
}

config_reservation_del()
{
	rm -f /tmp/configs/reservation$1 
	$nvram show | grep reservation | grep -v ^size | sort -n > /tmp/aa
	cat /tmp/aa | /bin/grep 'reservation[0-9]=' > /tmp/cc
	cat /tmp/aa | /bin/grep 'reservation[0-9][0-9]=' >> /tmp/cc
	mv /tmp/cc /tmp/aa
	line=`grep "reservation" -c /tmp/aa`
	num=1
	while (test $num -le $line)
	do
		name=`sed ''"$num"'p' -n /tmp/aa | sed 's/reservation.*=//'`
		reservation_name=reservation$num
		$nvram set $reservation_name="$name"
		num=$(($num+1))
	done
	if [ $1 != $num ];then
		rm -f /tmp/configs/reservation$num 
	fi
	rm -f /tmp/aa
}

