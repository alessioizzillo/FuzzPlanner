#!/bin/sh
touch /tmp/static_conflict
/www/cgi-bin/conflict_wanlan.sh
/sbin/cmdlan stop
/sbin/ip_conflict.sh  stop
#echo 0 > /tmp/configs/dns_hijack	
/sbin/ip_conflict.sh start &
