function countmask(num)
{
   	var i = 0;
      	var count=0;
        var numArr = [128, 64, 32, 16, 8, 4, 2, 1];
	for ( i = 0; i < numArr.length; i++ )
		if ( (num & numArr[i]) != 0 )
			count++;
	return count;
}
function check_router_add(cf,flag)
{
	if(flag == 'add' && array_num == 10 )
	{
		alert(routes_length_10);
		return false;
	}
	if(cf.route_name.value == "" )
	{
		alert(routes_name_null);
		return false;
	}
	cf.SRouteDestAddr.value=cf.dest_ip1.value+'.'+cf.dest_ip2.value+'.'+cf.dest_ip3.value+'.'+cf.dest_ip4.value;
	var ipaddr_array=cf.SRouteDestAddr.value.split('.');
	if(checkIP(ipaddr_array[0],ipaddr_array[1],ipaddr_array[2],ipaddr_array[3],254)==false)
	{
		alert(invalid_ip);
		return false;
	}
	if(ipaddr_array[0]=="127")
	{
		alert(invalid_ip);
                return false;
	}
	if(parseInt(ipaddr_array[0])>=224)
	{
		alert(invalid_ip);
		return false;
	}
	cf.SRouteSubnetMask.value=cf.mask1.value+'.'+cf.mask2.value+'.'+cf.mask3.value+'.'+cf.mask4.value;
	if(checksubnet(cf.SRouteSubnetMask.value)==false)
	{
		alert(invalid_mask);
		return false;
	}
	cf.SRouteGatewayAddr.value=cf.gtw_ip1.value+'.'+cf.gtw_ip2.value+'.'+cf.gtw_ip3.value+'.'+cf.gtw_ip4.value;
	if(checkgateway(cf.SRouteGatewayAddr.value)==false)
	{
		alert(invalid_gateway);
		return false;
	}
	if(wan_ip == "0.0.0.0" && isSameSubNet(cf.SRouteGatewayAddr.value,lan_mask,lan_ip,lan_mask) == false )
	{
		alert(routes_diff_wan_gateway);
        return false;
	}
	 else if ( wan_proto == "pptp" )
        {
                if(isSameSubNet(cf.SRouteGatewayAddr.value,wan_mask,wan_ip,wan_mask) == false && isSameSubNet(cf.SRouteGatewayAddr.value,pptp_eth1_wanmask,pptp_eth1_wanip,pptp_eth1_wanmask) == false && isSameSubNet(cf.SRouteGatewayAddr.value,lan_mask,lan_ip,lan_mask) == false )
                {
                        alert(routes_diff_wan_gateway);
                        return false;
                }
        }

	else if(isSameSubNet(cf.SRouteGatewayAddr.value,wan_mask,wan_ip,wan_mask) == false && isSameSubNet(cf.SRouteGatewayAddr.value,lan_mask,lan_ip,lan_mask) == false)	
	{
		alert(routes_diff_wan_gateway);
		return false;
	}
	var ipArray = cf.SRouteDestAddr.value.split(".");
	var subnetArray = cf.SRouteSubnetMask.value.split(".");
	var addr = new Array();
	var count = 0;
	for (i=0;i<4;i++)
	{
		addr[i] = ipArray[i] & subnetArray[i];
		count += countmask(subnetArray[i]);
	}
	cf.count.value = count;
	var route_dest = addr[0]+'.'+addr[1]+'.'+addr[2]+'.'+addr[3];
	document.forms[0].route_dest.value=route_dest;
	if(!(parseInt(cf.route_metric.value)>=2&&parseInt(cf.route_metric.value)<=15))
	{
		alert(routes_metric_error);
		return false;
	}
	for(i=1;i<=array_num;i++)
    {
		var str = eval ( 'routerArray' + i );
		var each_info=str.split(' ');
		if(flag == 'edit')
		{	
			if( cf.route_name.value == each_info[0]&& select_editnum != i)
			{
				alert(routes_name_dup);
				return false;
			}
			if( route_dest == each_info[3] && cf.SRouteGatewayAddr.value ==each_info [5] && select_editnum != i)
			{
				alert(routes_condition_dup);
				return false;
			}
		}
		else
		{
			if( cf.route_name.value == each_info[0])
			{
				alert(routes_name_dup);
				return false;
			}
			if( route_dest == each_info[3] && cf.SRouteGatewayAddr.value ==each_info [5] )
			{
				alert(routes_condition_dup);
				return false;
			}
		}
	}
	
	if (cf.SRouteActive.checked==false)
		cf.route_ac.value = 0;
	else
		cf.route_ac.value = 1;
	if (cf.SRoutePrivate.checked==false)
		cf.route_pr.value = 0;
	else
		cf.route_pr.value = 1;
	return true;
}
function check_router_editnum()
{
	if( totalnum == "" )
	{
		alert(no_serv_edit);
		return false;
	}
	var count_select=0;
	var select_num;
	if(totalnum == 1)
	{
		if(document.forms[0].select_route.checked == true)
		{
			count_select++;
			select_num=1;
		}
	}
	else for(i=0;i<totalnum;i++)
		if(document.forms[0].select_route[i].checked == true)
		{
			count_select++;
			select_num=i+1;
		}
	if(count_select==0)
	{
		alert(select_serv_edit);
		return false;
	}
	else
	{
		document.forms[0].select_edit.value=select_num;
		document.forms[0].submit_flag.value="st_router_editnum";
		document.forms[0].action="/cgi-bin/setobject.cgi?/cgi-bin/STR_routes_edit.html";
		return true;
	}
}

function check_router_del()
{
	if( totalnum == 0 )
	{
		alert(no_serv_del);
		location.href="STR_router.html";
		return false;
	}
	var count_select=0;
	var del_num;
	if( totalnum == 1)
	{
		if(document.forms[0].select_route.checked == true)
			del_num=1;
		else
		{
			alert(select_serv_del);
			location.href="STR_router.html";
			return false;
		}
	}
	else
	{
		for(i=0;i<totalnum;i++)
			if(document.forms[0].select_route[i].checked == true)
			{
				count_select++;
				del_num=i+1;
			}
		if(count_select==0)
		{
			alert(select_serv_del);
			location.href="STR_router.html";
			return false;
		}	
	}
	document.forms[0].select_del.value=del_num;
	document.forms[0].submit_flag.value="st_router_del";
	document.forms[0].action="/cgi-bin/setobject.cgi?/cgi-bin/STR_router.html";
	return true;
}
