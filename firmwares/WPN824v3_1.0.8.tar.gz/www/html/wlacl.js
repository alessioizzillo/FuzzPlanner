function check_wlacl_add(cf,flag)
{
	if( array_num == 64 )
	{
		alert(acl_length_64);
		return false;
	}
	if(cf.device.value=="")
    	{
        	alert(device_name_null);
        	return false;
    	}	
	for(i=0;i<cf.device.value.length;i++)
         {
                if(isValidChar(cf.device.value.charCodeAt(i))==false)
                {
                        alert(device_name_error);
                        return false;
                }
        }
	for(i=1;i<=array_num;i++)
    	{
		var str = eval ( 'wlaclArray' + i );
		var each_info=str.split(' ');
		if (flag == 'add')
		{		
        	if(each_info[0]==cf.device.value)
        	{
            	alert(device_name_dup);
            	return false;
        	}
		}
		else
		{
			if( each_info[0]==cf.device.value && i != select_edit )
	        {
	        	alert(device_name_dup);
				return false;
			}
		}
    }
    if(cf.this_mac.value.length==12)
    {
        var mac=cf.this_mac.value;
 
        cf.this_mac.value=mac.substr(0,2)+":"+mac.substr(2,2)+":"+mac.substr(4,2)+":"+mac.substr(6,2)+":"+mac.substr(8,2)+":"+mac.substr(10,2);
        
    }

	if(maccheck(cf.this_mac.value) == false)
        	return false;
	for(i=1;i<=array_num;i++)
    {
		var str = eval ( 'wlaclArray' + i );
		var each_info=str.split(' ');
		if (flag == 'add')
		{
        	if(each_info[1]==cf.this_mac.value)
        	{
            		alert(mac_dup);
            		return false;
        	}
		}
		else
		{
			if( each_info[1] == cf.this_mac.value && i!= select_edit )
			{
				alert(mac_dup);
				return false;
			}
		}
    }	
	return true;
}

function check_wlacl_edit(cf,flag)
{
if(cf.device.value=="")
        {
            alert(device_name_null);
            return false;
        }
    for(i=0;i<cf.device.value.length;i++)
         {
                if(isValidChar(cf.device.value.charCodeAt(i))==false)
                {
                        alert(device_name_error);
                        return false;
                }
        }
    for(i=1;i<=array_num;i++)
        {
        var str = eval ( 'wlaclArray' + i );
        var each_info=str.split(' ');
        if (flag == 'add')
        {
            if(each_info[0]==cf.device.value)
            {
                alert(device_name_dup);
                return false;
            }
        }
        else
        {
            if( each_info[0]==cf.device.value && i != select_edit )
            {
                alert(device_name_dup);
                return false;
            }
        }
    }
    if(maccheck(cf.this_mac.value) == false)
            return false;
    for(i=1;i<=array_num;i++)
    {
        var str = eval ( 'wlaclArray' + i );
 var each_info=str.split(' ');
        if (flag == 'add')
        {
            if(each_info[1]==cf.this_mac.value)
            {
                    alert(mac_dup);
                    return false;
            }
        }
        else
        {
            if( each_info[1] == cf.this_mac.value && i!= select_edit )
            {
                alert(mac_dup);
                return false;
            }
        }
    }
    return true;
}

function check_wlacl_editnum(cf)
{
	if( array_num == "" )
	{
		alert(no_serv_edit);
		return false;
	}
	var count_select=0;
	var select_num;
	if( array_num == 1)
	{
		if(cf.select_wlacl.checked == true)
		{
			count_select++;
			select_num=1;
		}
	}
	else for(i=0;i<array_num;i++)
		if(cf.select_wlacl[i].checked == true)
		{
			count_select++;
			select_num=i+1;
		}
	if(count_select==0)
	{
		alert(select_serv_edit);
		return false;
	}
	else
	{
		cf.select_edit.value=select_num;
		cf.submit_flag.value="wlacl_editnum";
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/wlacl_edit.html";
		return true;
	}
}

function check_wlacl_del(cf)
{
	if( array_num == "" )
	{
		alert(no_serv_del);
		return false;
	}
	var count_select=0;
	var select_num;
	if( array_num == 1)
	{
		if(cf.select_wlacl.checked == true)
		{
			count_select++;
			select_num=1;
		}
	}
	else for(i=0;i<array_num;i++)
		if(cf.select_wlacl[i].checked == true)
		{
			count_select++;
			select_num=i+1;
		}
	if(count_select==0)
	{
		alert(select_serv_del);
		return false;
	}
	else
	{
		cf.select_del.value=select_num;
		cf.submit_flag.value="wlacl_del";
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/wlacl.html";
		return true;
	}
}

function check_wlacl_apply(cf)
{
	if( cf.accessLimit.checked == true )
		cf.wl_access_ctrl_on.value=1;
	else
		cf.wl_access_ctrl_on.value=0;
		cf.submit_flag.value="wlacl_apply";
		cf.action="/cgi-bin/setobject.cgi?/cgi-bin/wlacl.html";
	return true;
}

function mac_data_select(num)
{
	var cf = document.forms[0];
	cf.device.value = sta_name_array[num];
	cf.this_mac.value=sta_mac_array[num];
}
