function set_channel(form, modeflag)
{
	var countrycode =form.wlan_coun.options[form.wlan_coun.selectedIndex].value;
	var channel = form.wlan_chan;
	var i;
	var old_channel = form.wlan_chan.value;
	if(wds_endis_fun=="0")
	{
		var start = 0;
		var end = 13;
		var chan_t = new Array("Auto","01", "02", "03", "04","05", "06", "07", "08","09", "10", "11", "12","13", "14");
		var chan_v = new Array();
		var j = 0;

		for(i = 0; i < 15; i++){
			chan_v[i] = i;
		}
		var comflag; 
		comflag=true;
		if(comflag)
			do
			{
				channel.options[0] = null;
	        } while(channel.length);
		if(modeflag == false ||	comflag ){ 
			if ( form.wlan_mode.selectedIndex == 3 )
			{
				start = 6; end = 6;
			}
			else if(countrycode == 0 || countrycode == 1 || countrycode == 2
			   || countrycode == 4 || countrycode == 5 || countrycode == 6
	  		   || countrycode == 7 || countrycode == 9)
			{
				start = 0; end = 13;
			}
			else if( countrycode == 3 || countrycode == 10  || countrycode == 8 )
			{
				start = 0; end = 11;
			}
			else if( countrycode == 11)
			{
				start =11;end =11;
			}
			for(i = start; i <= end; i ++){
				channel.options[j] = new Option(chan_t[i], chan_v[i]);
				if(channel.options[j].value == old_channel) channel.options[j].selected = true;
				j ++;
			}
		}
	}
	else
	{
		var start = 0;
		var end = 12;
		var chan_t = new Array("01", "02", "03", "04","05", "06", "07", "08","09", "10", "11", "12","13", "14");
		var chan_v = new Array();
		var j = 0;

		for(i = 0; i < 14; i++){
			chan_v[i] = i+1;
		}
		var comflag; 
		comflag=true;
		if(comflag)
			do
			{
				channel.options[0] = null;
	        } while(channel.length);
		if(modeflag == false ||	comflag ){ 
			if ( form.wlan_mode.selectedIndex == 3 )
			{
				start = 5; end = 5;
			}
			else if(countrycode == 0 || countrycode == 1 || countrycode == 2
			   || countrycode == 4 || countrycode == 5 || countrycode == 6
	  		   || countrycode == 7 || countrycode == 9)
			{
				start = 0; end = 12;
			}
			else if( countrycode == 3 || countrycode == 10  || countrycode == 8 )
			{
				start = 0; end = 10;
			}
			else if( countrycode == 11)
			{
				start =10;end =10;
			}
			for(i = start; i <= end; i ++){
				channel.options[j] = new Option(chan_t[i], chan_v[i]);
				if(channel.options[j].value == old_channel) channel.options[j].selected = true;
				j ++;
			}
		}
	
	}
}


function check_wlan()
{
	var cf=document.forms[0];
        var ssid = document.forms[0].wlan_ssid.value;
        var space_flag=0
		if(ssid == "")
        {
                alert(ssid_null);
                return false;
        }
        if(ssid.toLowerCase() == "any")
        {
                alert(ssid + ssid_not_allowed);
                return false;
        }
		for(i=0;i<ssid.length;i++)
        {
                if(isValidChar_space(ssid.charCodeAt(i))==false)
                {
                        alert(ssid + ssid_not_allowed);
                        return false;
                }
        }
	    for(i=0;i<ssid.length;i++)
        {
            	if(ssid.charCodeAt(i)!=32)
                	space_flag++;
        }
		if(space_flag==0)
		{
			alert(ssid_null);
        	return false;

		}
	if(cf.wlan_coun.selectedIndex == 0)
	{
		alert(coun_select);
		return false;
	}			
	if(cf.sec_type[1].checked == true)
	{
		if( checkwep(cf)== false)
			return false;
		cf.hidden_sec_type.value=2;
	}
	else if(cf.sec_type[2].checked == true)
	{
		if( checkpsk(cf)== false)
			return false;
		cf.hidden_sec_type.value=3;
	}
	else if(cf.sec_type[3].checked == true)
	{
		if( checkpsk(cf)== false)
			return false;
		cf.hidden_sec_type.value=4;
	}	
	else if(cf.sec_type[4].checked == true)
	{
		if( checkpsk(cf)== false)
			return false;
		cf.hidden_sec_type.value=5;
	}	
	else
		cf.hidden_sec_type.value=1;
	return true;	
}
