#!/bin/sh

status_file="/tmp/configs/welcome_wan_type"
status_initializing=0001
status_0_percent=1000
status_25_percent=1025
status_50_percent=1050
status_75_percent=1075
status_90_percent=1090
status_100_percent=1100
status_finish=9999
status_error=10000
status_dynamic=10001
status_pppoe=10002
status_static=10003
status_static_ornot=10004
status_already=10005
status_bigpond=10006
status_pptp=10007
status_plug_off=10008

wan_status="down"
test_wan_status() #$1:wan_mode_ori, test if ori_wan is up or down
{
	info_get_wanproto="$1"

	if [ "$info_get_wanproto" = "dhcp" ]; then
		eth1_value=`ifconfig eth1 | grep "inet addr:"`
		if [ "x$eth1_value" != "x" ]; then
			wan_status="up"
		fi
	elif [ "$info_get_wanproto" = "static" ]; then
		eth1_value=`ifconfig eth1 | grep "inet addr:"`
		if [ "x$eth1_value" != "x" ]; then
			wan_status="up"
		fi
	elif [ "$info_get_wanproto" = "bigpond" ];then
		info_get_bpa_status=$(cat /tmp/bpa_info | awk '{print $1}')
		eth1_value=`ifconfig eth1 | grep "inet addr:"`
		if [ "x$eth1_value" != "x" -a "$info_get_bpa_status" = "up" ]; then
			wan_status="up"
		fi	
	elif [ "$info_get_wanproto" = "pppoe" ]; then
		pppoe_status=/etc/ppp/ppp0-status
		pppoe_alive=0

		if [ -f $pppoe_status ]; then
			status=$(cat $pppoe_status)
			if [ "x$status" = "x1" ]; then
				pppoe_alive=1
			fi
		fi
		
		if [ "$pppoe_alive" = "1" ]; then
			ppp0_value=`ifconfig | grep ^ppp0`
			if [ "x$ppp0_value" != "x" ]; then
				wan_status="up"
			fi
		fi
	elif [ "$info_get_wanproto" = "pptp" ]; then
		pptp_status=/etc/ppp/ppp0-status
		pptp_alive=0
		
		if [ -f $pptp_status ]; then
			status=$(cat $pptp_status)
			if [ "x$status" = "x1" ]; then
				pptp_alive=1
			fi
		fi

		if [ "$pptp_alive" = "1" ]; then
			ppp0_value=`ifconfig | grep ^ppp0` 
			if [ "x$ppp0_value" != "x" ]; then      
				wan_status="up"
			fi
		fi
	elif [ "$info_get_wanproto" = "mulpppoe1" ]; then
	#ppp1
		IP_FILE0=/etc/ppp/pppoe1-ip
		PPP0_STATUS=/etc/ppp/pppoe1-status
		info_get_wanip="0.0.0.0"
		if [ -f $PPP0_STATUS ]; then
			status=$(cat $PPP0_STATUS)
			if [ "x$status" = "x1" -a -f $IP_FILE0 ]; then
				wan_status="up"
			fi	
		fi
	#ppp2	
		IP_FILE1=/etc/ppp/pppoe2-ip
		PPP1_STATUS=/etc/ppp/pppoe2-status
		info_get_wanip2="0.0.0.0"
		if [ -f $PPP1_STATUS ]; then
			status=$(cat $PPP1_STATUS)
			if [ "x$status" = "x1" -a -f $IP_FILE1 ]; then
				wan_status="up"
			fi	
		fi
	fi
	echo "test wan_status=$wan_status" > /dev/console 
}
write_status() # $1: status_number, $2: status_file
{
	echo "$1" > $2
}
detect_dhcp()
{
	local r_val=1

	/sbin/ifconfig eth1 up
	if /sbin/udhcpc -n -i eth1; then
		r_val=0
	fi
	/sbin/ifconfig eth1 down
	/sbin/ifconfig eth1 0.0.0.0
	return $r_val
}
detect_pptp() # $1: status_number, $2: status_file
{
	local r_val=1
	/sbin/ifconfig eth1 up
	/sbin/ifconfig eth1 10.0.0.1 netmask 255.255.255.0
	if /sbin/detport 10.0.0.138 1723; then
		r_val=0
	fi	
	/sbin/ifconfig eth1 down
	/sbin/ifconfig eth1 0.0.0.0
	return $r_val

}

detect_bigpond()
{
	local r_val=1

	/sbin/ifconfig eth1 up
	/sbin/udhcpc -n -i eth1 && local tmp=$(awk '/^search.*bigpond\.net\.au$/ {print }' /tmp/resolv.conf)
	if [ -n "$tmp" ]; then
		r_val=0
	fi
	/sbin/ifconfig eth1 down
	/sbin/ifconfig eth1 0.0.0.0
	return $r_val
}

detect_pppoe()
{
	local r_val=1
	/sbin/ifconfig eth1 up
	/usr/sbin/pd
	if [ "$?" = "0" ]; then
		r_val=0
	fi
	/sbin/ifconfig eth1 down
	return $r_val
}

mac_spoofing()
{
	/sbin/ifconfig eth1 down
	/sbin/ifconfig eth1 hw ether $(/usr/sbin/nvram get wan_remote_mac)
	return 0;
}

write_final_status() # $1: wan_mode_det, $2: wan_mode_ori, $3: status_file
{
	local wan_mode_det="$1"
	local wan_mode_det_tmpfile="/tmp/wanmode"
	local status_number
	test_wan_status "$2"
	echo "write wan_status=$wan_status" > /dev/console
	if [ "$1" = "unknow" -a "$2" = "static" ]; then
		wan_mode_det="static"
	fi
	
	case "$wan_mode_det" in
		dhcp)
			echo "wanmode 0 (dynamic)" > $wan_mode_det_tmpfile
			status_number="$status_dynamic"
			;;
		pppoe)
			echo "wanmode 2 (pppoe)" > $wan_mode_det_tmpfile
			status_number="$status_pppoe"
			;;
		static)
			echo "wanmode 1 (static)" > $wan_mode_det_tmpfile
			status_number="$status_static"
			;;
		bigpond)
			echo "wanmode 4 (bigpond)" > $wan_mode_det_tmpfile
                        status_number="$status_bigpond"
			;;
		 pptp)
                        echo "wanmode 5 (pptp)" > $wan_mode_det_tmpfile
                        status_number="$status_pptp"
                        ;;
		*)
			echo "wanmode 3 (unknown)" > $wan_mode_det_tmpfile
			status_number="$status_static_ornot"
			;;
	esac

	if [ "$wan_mode_det" = "$2" -a "$wan_mode_det" != "unknown" -a "$wan_status" = "up" ]; then
		status_number="$status_already"
	fi
	write_status $status_number $3
}

#----------------------------------

write_status $status_initializing $status_file
wan_mode_ori=$(nvram get wan_proto)
write_status $status_0_percent $status_file
/usr/bin/detcable
wan_status=$([ -f /tmp/WAN_status ] && cat /tmp/WAN_status || echo "Link down")
if [ "$wan_status" != "Link down" ]; then
#	. /demo/firewall.sh stop > /dev/null 2>&1
	/sbin/cmd_raw_wan stop > /dev/null 2>&1
	write_status $status_25_percent $status_file
	wan_mode_det="unknown"
	if write_status $status_25_percent $status_file && detect_pppoe; then
		write_status $status_50_percent $status_file
		sleep 3
		wan_mode_det="pppoe"
	elif write_status $status_25_percent $status_file && detect_bigpond; then
		write_status $status_50_percent $status_file
		sleep 3
		wan_mode_det="bigpond"
	elif write_status $status_50_percent $status_file && detect_pptp; then
		sleep 3
		wan_mode_det="pptp"
	elif write_status $status_50_percent $status_file && detect_dhcp; then
		write_status $status_50_percent $status_file
		wan_mode_det="dhcp"
	elif write_status $status_75_percent $status_file && mac_spoofing && detect_dhcp; then
		/usr/sbin/nvram set wan_ether_mac_assign=1
		wan_mode_det="dhcp"
	elif write_status $status_75_percent $status_file && mac_spoofing && detect_pptp; then
		/usr/sbin/nvram set wan_pptp_mac_assign=1
		wan_mode_det="pptp"
	fi	
	write_status $status_75_percent $status_file
	/sbin/cmd_raw_wan restart > /dev/null 2>&1
	write_status $status_100_percent $status_file
	sleep 3
	write_final_status "$wan_mode_det" "$wan_mode_ori" "$status_file"
else	# /usr/bin/detcable fail
	sleep 3	
	write_status $status_100_percent $status_file
	sleep 3
	write_status $status_plug_off $status_file
fi

