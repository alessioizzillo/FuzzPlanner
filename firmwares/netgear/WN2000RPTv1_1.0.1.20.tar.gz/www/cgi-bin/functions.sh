#!/bin/sh
. /www/cgi-bin/webupgrade.sh
rc=/sbin/rc
cmd_lan=/etc/init.d/net-lan
cmd_plugin=/sbin/cmd_plugin
nvram=/usr/sbin/nvram
brctl=/usr/sbin/brctl
ifconfig=/sbin/ifconfig
bing=/usr/sbin/bing
lansh=/www/cgi-bin/lan.sh
wlansh=/www/cgi-bin/wlan.sh
securitysh=/www/cgi-bin/security.sh
access_ctrlsh=/www/cgi-bin/access_control.sh
systemsh=/www/cgi-bin/system.sh
passwdsh=/www/cgi-bin/passwd.sh
upgradesh=/www/cgi-bin/upgrade.sh

bas_ethersh=/www/cgi-bin/bas_ether.sh
wlaclsh=/www/cgi-bin/wlacl.sh
wlan_advsh=/www/cgi-bin/wlan_adv.sh

enable_telnetsh=/www/cgi-bin/enable_telnet.sh

shawk=/www/cgi-bin/shawk.sh
logsh=/www/cgi-bin/log.sh

welcomesh=/www/cgi-bin/welcome.sh
wizardsh=/www/cgi-bin/wizard.sh
infosh=/www/cgi-bin/info.sh

cahidden=/www/cgi-bin/cahidden.sh
change_languagesh=/www/cgi-bin/change_language.sh
#wps
wsccmd=/usr/sbin/wsccmd
wsc_cfg=/usr/sbin/wsc_cfg

CONSOLE=/dev/console

oc () { "$@" >> $CONSOLE 2>&1 ; } # stdout & stderr to /dev/console

DEV_NULL=/dev/null
qt () { "$@" >> $DEV_NULL 2>&1 ; } # stdout & stderr to /dev/null

Enable_GUIStringTable=$($nvram get Enable_GUIStringTable)
GUI_Region=$($nvram get GUI_Region)
dns_hijack=$($nvram get dns_hijack)
wire_message=$($nvram get wire_message)
CHARSET="iso-8859-1"
print_charset()
{
        CHARSET="UTF-8"
        echo -n  "$CHARSET"
}
print_js_call() #$1: js name
{
	echo "<script language=javascript type=text/javascript src=$1></script>"
}

print_cgi_header () # $1: content_type
{
        time_stamp_dni=$(cat /proc/uptime)
        local content_type date
        content_type="$1"
        [ "x$content_type" = "x" ] && content_type="text/html"
        date=`date -u '+%a, %d %b %Y %H:%M:%S %Z'`

cat <<EOF
Content-type: $content_type

EOF
}

lock_cgiwait_top ()
{
        if [ -f /tmp/lock_web -a -f /tmp/lock_refreshpage ];then
                ipaddr=$(cat /tmp/lock_refreship)
                page=$(cat /tmp/lock_refreshpage)
		print_top_refresh "$ipaddr/cgi-bin/top.html" "5"
            exec >&-
            exit 0
        fi
}

lock_cgiwait_catop ()
{
        if [ -f /tmp/lock_web -a -f /tmp/lock_refreshpage ];then
                ipaddr=$(cat /tmp/lock_refreship)
                page=$(cat /tmp/lock_refreshpage)
                print_catop_refresh "$ipaddr/cgi-bin/ca_top.html" "5"
            exec >&-
            exit 0
        fi
}

lock_cgiwait ()
{
	if [ -f /tmp/lock_web -a -f /tmp/lock_refreshpage ];then
		ipaddr=$(cat /tmp/lock_refreship)
		page=$(cat /tmp/lock_refreshpage)
		print_http_refresh "$ipaddr/cgi-bin/pls_wait.html" "1"
	    exec >&-
	    exit 0
	fi	
}

lock_cgiwait_ca_connect ()
{
	if [ -f /tmp/lock_web -a -f /tmp/lock_refreshpage ];then
		ipaddr=$(cat /tmp/lock_refreship)
		page=$(cat /tmp/lock_refreshpage)
		print_http_refresh "$ipaddr/cgi-bin/wait_for_connect.html" "1"
	    exec >&-
	    exit 0
	fi	
}

lock_cgiwait_show ()
{	
        if [ -f /tmp/lock_web -a -f /tmp/lock_show_refreshpage ];then
                ipaddr=$(cat /tmp/lock_refreship)
                page=$(cat /tmp/lock_show_refreshpage)
                print_http_refresh "$ipaddr/cgi-bin/pls_wait_show.html"
            exec >&-
            exit 0
        fi
}

use_default_language()
{
        #if [ "$GUI_Region" != "English" ];then
        #        $nvram set GUI_Region="English"
        #fi

	if [ "$GUI_Region" = "German" ];then
		print_js_call "/languages_gr.js"
	elif [ "$GUI_Region" = "France" ];then
		print_js_call "/languages_fr.js"
	elif [ "$GUI_Region" = "Italy" ];then
		print_js_call "/languages_it.js"
	elif [ "$GUI_Region" = "Russian" ];then
		print_js_call "/languages_ru.js"
	else
        	print_js_call "/languages.js"
	fi
}
print_language_js()
{
	local language_region
	if [ "$Enable_GUIStringTable" = 1 -a "x$GUI_Region" != "x" ];then
                   if [ -f "/www/html/multi_lang/languages_nonEnglish.js" ];then
                           language_region=$(cat /tmp/multi_lang/language_region)
                           language_region=$(echo -n $language_region)
                           if [  "$GUI_Region" = "$language_region" ];then
                                   firm_lang_version=$(cat /firmware_language_version)
                                   multi_lang_version=$(cat /tmp/multi_lang/language_version)
                                   if is_newer $firm_lang_version $multi_lang_version ;then
                                           if [ "$GUI_Region" = "English" -o "$GUI_Region" = "German" -o "$GUI_Region" = "France" -o "$GUI_Region" = "Italy" -o "$GUI_Region" = "Russian" ];then
						   use_default_language
                                           else
	                                           print_js_call "/multi_lang/languages_nonEnglish.js"
                                           fi
                                   else
                                           print_js_call "/multi_lang/languages_nonEnglish.js"
                                   fi
                           else
				use_default_language
                           fi
                   else
                           use_default_language
                   fi
         else
		use_default_language
	 fi
}
print_http_header() #$1:the first js $2:the second js $3:the third js....
{
    local tmp 
    echo "<html><head>"
    if [ "$1" = "help" ]; then
    	echo '<link rel="stylesheet" href="/help.css">'
    else
    	echo '<link rel="stylesheet" href="/form.css">'
    fi
	echo '<Meta http-equiv="Pragma" Content="no-cache">'
	echo '<META HTTP-equiv="Cache-Control" content="no-cache">'
	echo '<Meta http-equiv="Expires" Content="0">'
	echo "<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>"
	print_language_js
    for tmp in $@
      do
      if echo $tmp | grep -q 'js$'; then
	  print_js_call $tmp
      fi
    done

cat <<EOF
	<script>window.document.title=device_title</script>
    <title>Wireless Access Point</title>
    </head>
EOF
}
print_httpIA_header() #$1:the first js $2:the second js $3:the third js....
{
    local tmp 
    echo "<html><head>"
	echo '<Meta http-equiv="Pragma" Content="no-cache">'
	echo '<META HTTP-equiv="Cache-Control" content="no-cache">'
	echo '<Meta http-equiv="Expires" Content="0">'
	echo "<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>"
	print_language_js
    for tmp in $@
      do
      if echo $tmp | grep -q 'js$'; then
	  print_js_call $tmp
      fi
    done

cat <<EOF
	<script>window.document.title=device_title</script>
EOF
}
print_menu_header()
{
    echo '<HTML><HEAD><TITLE>WN2000RPT</TITLE>'
    echo "<META http-equiv=content-type content='text/html;charset=$(print_charset)'>"
    echo '<META content="MSHTML 6.00.2800.1141" name=GENERATOR>'
	print_language_js
}
print_ca_http_header() #$1:the first js $2:the second js $3:the third js....
{
    local tmp
    echo "<html><head>"
    echo '<link rel="stylesheet" href="/style.css">'
	echo '<Meta http-equiv="Pragma" Content="no-cache">'
	echo '<META HTTP-equiv="Cache-Control" content="no-cache">'
    echo '<Meta http-equiv="Expires" Content="0">'
	echo "<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>"
	print_language_js
    for tmp in $@
      do
      if echo $tmp | grep -q 'js$'; then
          print_js_call $tmp
      fi
    done

cat <<EOF
    <title>${device_title}</title>
    </head>
EOF
}

print_body_header() #$1, help function $2, target html
{
	echo "<body onLoad=\"loadhelp('$1');loadvalue();\" bgcolor=#ffffff>"
	echo "<form method=\"post\" action=\"/cgi-bin/setobject.cgi?/cgi-bin/$2\" target=formframe>"
	echo "<input type=hidden name=submit_flag value=\"$3\">"
	
	$nvram set time_stamp_all="$time_stamp_dni"
	echo "<script>"
	echo "var time_stamp_dni='$time_stamp_dni';"
	echo "time_stp();"
	echo "</script>"
}

print_nobody_header() #$1, help function $2, target html
{
	echo "<body bgcolor=#ffffff>"
	echo "<form method=\"post\" action=\"/cgi-bin/setobject.cgi?/cgi-bin/$1\" >"
	echo "<input type=hidden name=submit_flag value=\"$2\">"
	
	$nvram set time_stamp_all="$time_stamp_dni"
	echo "<script>"
	echo "var time_stamp_dni='$time_stamp_dni';"
	echo "time_stp();"
	echo "</script>"
}

print_nohelp_header() #$1, help function $2, target html
{
	echo "<body onLoad=\"loadvalue();\" bgcolor=#ffffff>"
	echo "<form method=\"post\" action=\"/cgi-bin/setobject.cgi?/cgi-bin/$1\" target=IA_frame>"
	echo "<input type=hidden name=submit_flag value=\"$2\">"
	
	$nvram set time_stamp_all="$time_stamp_dni"
				echo "<script>"
				echo "var time_stamp_dni='$time_stamp_dni';"
				echo "time_stp();"
				echo "</script>"
}

print_nocommit_header() #$1, help function $2, target html
{
	if [ "x$1" = "x" ];then
		echo "<body onLoad=\"loadvalue();\" bgcolor=#ffffff>"
	else	
		echo "<body onLoad=\"loadhelp('$1');loadvalue();\" bgcolor=#ffffff>"
	fi
	echo "<form method=\"post\" action=\"/cgi-bin/no_commit.cgi?/cgi-bin/$2\" >"
	echo "<input type=hidden name=submit_flag value=$3>"
	
	$nvram set time_stamp_all="$time_stamp_dni"
	echo "<script>"
	echo "var time_stamp_dni='$time_stamp_dni';"
	echo "time_stp();"
	echo "</script>"
}

print_noload_header()
{
        echo "<body onLoad=\"loadhelp('$1');\" bgcolor=#ffffff>"
        echo "<form method=\"post\" action=\"/cgi-bin/setobject.cgi?/cgi-bin/$2\" >"
        echo "<input type=hidden name=submit_flag value=\"$3\">"
        
        $nvram set time_stamp_all="$time_stamp_dni"
				echo "<script>"
				echo "var time_stamp_dni='$time_stamp_dni';"
				echo "time_stp();"
				echo "</script>"
}

print_nocommitload_header()
{
	if [ "x$1" = "x" ];then
		echo "<body bgcolor=#ffffff>"
    else
		echo "<body onLoad=\"loadhelp('$1');\" bgcolor=#ffffff>"
	fi
	echo "<form method=\"post\" action=\"/cgi-bin/no_commit.cgi?/cgi-bin/$2\" >"
    echo "<input type=hidden name=submit_flag value=$3>"
    
    $nvram set time_stamp_all="$time_stamp_dni"
		echo "<script>"
		echo "var time_stamp_dni='$time_stamp_dni';"
		echo "time_stp();"
		echo "</script>"
}

print_table_header() #$1 table header
{
	echo "<table width=100% border=0 cellpadding=0 cellspacing=3>"
	echo "<TR><TD colSpan=2><H1>$1</H1></TD></TR>"
	echo "<TR><TD colSpan=2></TD></TR><TR><td colspan=2><img src=/liteblue.gif width=100% height=12></td></TR>"
}

print_http_refresh () # $1: page to be refresh, $2: delay_time
{
        local delay_time

        delay_time="$2"
        [ "x$delay_time" = "x" ] && delay_time="0"

print_cgi_header "text/html"
cat <<EOF
<HTML>
<HEAD>  <meta http-equiv="Refresh" content="$delay_time; url=$1">
<Meta http-equiv="Pragma" Content="no-cache">
<META HTTP-equiv="Cache-Control" content="no-cache">
<Meta http-equiv="Expires" Content="0">
<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>
EOF
print_language_js
cat <<EOF
<link rel="stylesheet" href="/form.css">
</HEAD>
<BODY bgcolor=#ffffff>
<tr><td colspan=2><br><img src=/liteblue.gif width=100% height=12></td></tr>
<script>document.write(wait_message)</script>
</BODY>
</HTML>
EOF
}

print_http_ca_refresh () # $1: page to be refresh, $2: delay_time
{
        local delay_time

        delay_time="$2"
        [ "x$delay_time" = "x" ] && delay_time="0"
refresh_message=$($nvram get refresh_message)
dns_hijack=$($nvram get dns_hijack)
iswireless=no

if [ $refresh_message -eq 1 ];then
	#To find out the connection is wireless or not.
	$($nvram set iswireless="no")
	$($nvram set continue_ca_settings="summery_show")
	ap_mode=$($nvram get ap_mode)
	if [ "$ap_mode" = "1" ];then
        amdin_pc_mac=$($nvram get wan_remote_mac)
        wlanconfig ath0 list sta > /tmp/iswireless
        list_totalnum=$(cat /tmp/iswireless | grep -v ^size |wc -l)
        list_totalnum=$(($list_totalnum + 1))
        if [ $list_totalnum != 0 ]; then
                count=1
                while (test $count -lt $list_totalnum )
	                do
	                        dev_mac=$(sed -n $count'p' /tmp/iswireless | awk '{print $1}')
                                if [ "$dev_mac" = "$amdin_pc_mac" ]; then
                                        iswireless=yes
					$($nvram set iswireless="yes")
                                fi
                                count=$(($count + 1))
				done
        fi
	fi

	if [ "$iswireless" = "no" ];then
		if [ "$dns_hijack" = "0" ];then
			$($nvram set refresh_page="summery_show")
		fi
	else
		if [ "$dns_hijack" = "1" ];then
			$($nvram set continue_ca_settings="connect_status")
		else
			$($nvram set refresh_page="client_setting")
		fi
	fi
else
	$($nvram set ca_wlan_finish="1")
	#echo 0 > /proc/sys/net/ipv4/dns_hijack
fi

ap_client=$(nvram get ap_client)
lan_dhcp=$($nvram get lan_dhcp)
wlan_ap_wifi="$($nvram get sta_wl_ssid | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g'  -e 's/</&lt;/g' -e 's/>/&gt;/g')"
wlan_get_ssid="$($nvram get wl_ssid | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g'  -e 's/</&lt;/g' -e 's/>/&gt;/g')"
wl_ap_sectype=$($nvram get sta_wl_sectype)
wl_sectype=$($nvram get wl_sectype)
wl_get_keylength=$($nvram get key_length)
wl_get_ap_keylength=$($nvram get sta_wl_key_length)

weppassphrase=$($nvram get weppassphrase)
ap_wl_key1=$($nvram get sta_wl_key1 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wl_key2=$($nvram get sta_wl_key2 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wl_key3=$($nvram get sta_wl_key3 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wl_key4=$($nvram get sta_wl_key4 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wep_64_key1=$($nvram get sta_wl_wep_64_key1 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wep_64_key2=$($nvram get sta_wl_wep_64_key2 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wep_64_key3=$($nvram get sta_wl_wep_64_key3 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wep_64_key4=$($nvram get sta_wl_wep_64_key4 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wep_128_key1=$($nvram get sta_wl_wep_128_key1 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wep_128_key2=$($nvram get sta_wl_wep_128_key2 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wep_128_key3=$($nvram get sta_wl_wep_128_key3 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_wep_128_key4=$($nvram get sta_wl_wep_128_key4 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_get_wpa1=$($nvram get sta_wl_wpa1_psk | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_get_wpa2=$($nvram get sta_wl_wpa2_psk | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
ap_get_wpas=$($nvram get sta_wl_wpas_psk | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')

sta_wl_weppassphrase=$($nvram get sta_wl_weppassphrase)
wl_key1=$($nvram get wl_key1 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wl_key2=$($nvram get wl_key2 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wl_key3=$($nvram get wl_key3 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wl_key4=$($nvram get wl_key4 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wep_64_key1=$($nvram get wep_64_key1 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wep_64_key2=$($nvram get wep_64_key2 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wep_64_key3=$($nvram get wep_64_key3 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wep_64_key4=$($nvram get wep_64_key4 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wep_128_key1=$($nvram get wep_128_key1 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wep_128_key2=$($nvram get wep_128_key2 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wep_128_key3=$($nvram get wep_128_key3 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
wep_128_key4=$($nvram get wep_128_key4 | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
get_wpa1=$($nvram get wl_wpa1_psk | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
get_wpa2=$($nvram get wl_wpa2_psk | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')
get_wpas=$($nvram get wl_wpas_psk | sed -e 's/\\/\\\\/g' -e 's/\"/\\\"/g')

sta_list=$(cat /tmp/check_link)
link_status=$(cat /tmp/link_status)
print_cgi_header "text/html"
cat <<EOF
<HTML>
<HEAD>
<script>
if("$iswireless" != "yes" && "$refresh_message"=="1")
	document.write('<meta http-equiv="Refresh" content="$delay_time; url=$1">');
</script>
<Meta http-equiv="Pragma" Content="no-cache">
<META HTTP-equiv="Cache-Control" content="no-cache">
<Meta http-equiv="Expires" Content="0">
<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>
EOF
print_language_js
cat <<EOF
<script language=javascript type=text/javascript src=/funcs.js></script>
<link rel="stylesheet" href="/form.css">
<STYLE type=text/css>  
.prgbar1 { font-family:Arial; padding:0px; height: 20px; width: 250px; font-weight: bolder; font-size: 10pt; border: 1px solid; border-color: #09c; color: #0000FF}  
</STYLE>
<script type="text/javascript">
var ap_client="$ap_client";
var lan_dhcp="$lan_dhcp";
wlan_ap_wifi="$wlan_ap_wifi";
var wlan_get_ssid="$wlan_get_ssid";
var wl_ap_sectype="$wl_ap_sectype";
var wl_sectype="$wl_sectype";
var wl_get_ap_keylength="$wl_get_ap_keylength";
var wl0_ssid="";
var passwd_phrase="";
var ap_passwd_phrase="";
var dns_hijack="$dns_hijack";
if(ap_client=="1"){
	if(wlan_get_ssid.indexOf("<")>-1){
		wlan_get_ssid=wlan_get_ssid.replace(/<lt;/g,'&lt;');
		wlan_get_ssid=wlan_get_ssid.replace(/>gt;/g,'&gt;');
		wl0_ssid=wlan_get_ssid;
	}else{
		wl0_ssid=wlan_get_ssid;
	}
	wlan_ap_wifi=wlan_ap_wifi.replace(/<lt;/g,'&lt;');
        wlan_ap_wifi=wlan_ap_wifi.replace(/>gt;/g,'&gt;');
}else{
	if(parent.wl0_ssid.indexOf("<")>-1){
		wl0_ssid=parent.wl0_ssid.replace(/\</g,'&lt;');
		wl0_ssid=wl0_ssid.replace(/\>/g,'&gt;');
	}else{
		wl0_ssid=parent.wl0_ssid;
	}
}

if(wl_ap_sectype==2){
	ap_passwd_phrase="$wl_key1";
	ap_sectype="WEP";
}else if(wl_ap_sectype==3){
	ap_passwd_phrase="$ap_get_wpa1";
	ap_sectype="WPA-PSK";
}else if(wl_ap_sectype==4){
	ap_passwd_phrase="$ap_get_wpa2";
	ap_sectype="WPA2-PSK";
}else if(wl_ap_sectype==5){
	ap_sectype="WPA/WPA2-PSK";
	ap_passwd_phrase="$ap_get_wpas";
}else
	ap_sectype="NONE";

if(wl_sectype==2){
	sectype="WEP";
	passwd_phrase="$wl_key1";
}else if(wl_sectype==3){
	passwd_phrase="$get_wpa1";
	sectype="WPA-PSK";
}else if(wl_sectype==4){
	passwd_phrase="$get_wpa2";
	sectype="WPA2-PSK";
}else if(wl_sectype==5){
	sectype="WPA/WPA2-PSK";
	passwd_phrase="$get_wpas";
}else
	sectype="NONE";

var link_status="$link_status";
var sta_list="$sta_list";
var maxchars = 10;
var delay_time = 5000; // msecs
var charcount = 0;
pro1="<br><table width=90% border=0 cellpadding=0 cellspacing=0 height=30><tr bgcolor=#dddddd><td width="
pro2="\% bgcolor=#0099cc align=right><font color=#0099cc>"
pro3="%</font></td><td width="
pro4="\%></td><td width=10% bgcolor=#ffffff>"
pro5="%</td></tr></table>"
function updateProgress()
{   
    var pro=charcount*10;
    var progress=pro1+pro+pro2+pro+pro3+(100-pro)+pro4+"<b>"+charcount*10+"</b>"+pro5;
    document.getElementById("view").innerHTML=progress;
	if( "$refresh_message"=="1")
		load_default(4);
	else
		load_default(5);
    if (charcount < maxchars)
    {  
        charcount=charcount+0.5;		
        setTimeout("updateProgress()",delay_time);
    }
   else
   {
	if($refresh_message == 1)
	{
		if("$iswireless" == "yes")
		{
			document.getElementById("countdown").style.display="none";
			document.getElementById("summary").style.display="block";
			load_default(5);
		}
	}
	else
	{
	 	if($dns_hijack==1)
			url_change_to_index();		
	}
   }

} 
function url_change_to_index()
{
        var browser=eval ( '"' + top.location + '"' );

        if  ( lan_dhcp == 1)
        {
                 if (browser.indexOf("www.mywifiext.net") > -1 )
                 {
                         parent.location.href="http://www.mywifiext.com/cgi-bin/index.html";
                 }
                 else if (browser.indexOf("www.mywifiext.com")>-1 )
                 {
                         parent.location.href="http://www.mywifiext.net/cgi-bin/index.html";
                 }
                 else if (browser.indexOf("mywifiext.net") > -1 )
                 {
                         parent.location.href="http://mywifiext.com/cgi-bin/index.html";
                 }
                 else if (browser.indexOf("mywifiext.com")>-1 )
                 {
                         parent.location.href="http://mywifiext.net/cgi-bin/index.html";
                 }
                 else
                         parent.location.href="http://www.mywifiext.net/cgi-bin/index.html";
	}
	else
		parent.location.href="index.html";		
}

function url_change_ornot ()
{
        var browser=eval ( '"' + top.location + '"' );

        var no_change_url="ca_connect_rightpage.html";
        var changed_url="welcome.html"

        if( dns_hijack == 0 )
        {
                no_change_url="info.html";
                changed_url="index.html";
        }

        if  ( lan_dhcp == 1)
        {
                if (browser.indexOf("www.mywifiext.net") > -1 )
                {
                        parent.location.href="http://www.mywifiext.com/cgi-bin/"+changed_url;
                }
                else if (browser.indexOf("www.mywifiext.com")>-1 )
                {
                        parent.location.href="http://www.mywifiext.net/cgi-bin/"+changed_url;
                }
                else if (browser.indexOf("mywifiext.net") > -1 )
                {
                        parent.location.href="http://mywifiext.com/cgi-bin/"+changed_url;
                }
                else if (browser.indexOf("mywifiext.com")>-1 )
                {
                        parent.location.href="http://mywifiext.net/cgi-bin/"+changed_url;
                }
                else
                {
                        parent.location.href="http://www.mywifiext.net/cgi-bin/"+changed_url;
                }
        }
        else
        {
                location.href=no_change_url;
        }

}
function msg_close()
{
 	alert(ca_close_alert);
  	CloseWindow();
}
function CloseWindow()
{
        top.window.opener=null;
        top.window.close();
}
</script>
</HEAD>
<body bgcolor="#ffffff" onLoad="updateProgress()">
<div id="countdown" style="display:block">
<table align=left border=0 width=100%>
<tr>
		<script>document.write(hd)</script> 
		<table align=left border=0 cellpadding=20 cellspacing=0 width=80%>
		<tr>
		<script>
		if("$dns_hijack"==1)
		{
			document.write('<td  rowspan=100 width=70 align=center valign=top>');document.write(ca_icon+"<br>");icons_show_status();document.write('&nbsp;</td>');
		}
		</script>
		<td>
		<h1><script>
		if ($refresh_message==1)
		{
			if($dns_hijack==0&&$wire_message==0)
 				document.write(wait_for_connect2);
			else if($dns_hijack==0&&$wire_message==1)
				document.write(wait_for_connect3);
			else
				document.write(wait_for_connect);
		}
		else if ($refresh_message==2)
		document.write(wait_for_summary_show);
		</script></h1></td></tr>
		<script>document.write(bluebar)</script>		
		<tr><td colspan=2><script>
		
		</script></td></tr>	
		<tr>
		<td>	
		<div id="view">
        </div></td></tr>
		<script>document.write(bluebar)</script>
	</table>
	</td>
  </tr>
</table>
</div><!-- end countdown-->

<div id="summary" style="display:none">
<table  align=left border=0 width=100%>
	<tr><td><h1><font color=#0099cc><b><script>
	if( "$dns_hijack" == "1" )
		document.write(ca_15_logging_1);
	else
		document.write(extender_info);
	</script></b></font></h1></td></tr>

	<script>document.write(bluebar)</script>

	<tr><td><script>
	if( "$dns_hijack" == "1" )
		document.write(ca_15_logging_2);
	</script></td></tr>

	<tr><td><script>document.write(spacebar)</script><b>
	<!--<script>document.write(ca_15_details);</script></b></td><td> -->
	<b><script>document.write(ca_15_repeater);</script></b></td></tr>
	<script>
		//line1
		document.write("<tr>")
//		document.write(hd+spacebar+ca_15_ssid+":&nbsp;")
//		document.write(wlan_ap_wifi+"</td>")
		document.write(hd+spacebar+ca_15_ssid+":&nbsp;")
		document.write(wl0_ssid+"</td></tr>")
		//line2
		document.write("<tr>");
//		document.write(hd+spacebar);document.write(ca_15_sec+":&nbsp;");
//		document.write(ap_sectype+"</td>");
		document.write(hd);
		document.write(spacebar);
		document.write(ca_15_sec+":&nbsp;");
		document.write(sectype+"</td></tr>");
		// line 3
		document.write('<tr>');
/*		if(ap_sectype=="WEP"){
			document.write(hd+spacebar);document.write(sec_enc); document.write(':&nbsp;');
			if("$wl_get_ap_keylength"=="5")
				document.write(sec_64);
			else if("$wl_get_ap_keylength"=="13")
				document.write(sec_128);
			document.write('</td>');
		}else if(ap_sectype=="WPA-PSK" || ap_sectype=="WPA2-PSK" || ap_sectype=="WPA/WPA2-PSK"){
			document.write(hd+spacebar+ca_15a_passphrase+":&nbsp;");
			document.write(ap_passwd_phrase+"</td>");
		}else
			document.write("<td></td>");
*/
		document.write(hd);document.write(spacebar);
		if(sectype=="WEP"){
			document.write(sec_enc); document.write(':&nbsp;');
			if("$wl_get_keylength"=="5")
				document.write(sec_64);
			else if("$wl_get_keylength"=="13")
				document.write(sec_128);
			document.write('</td></tr>');
		}else if (sectype=="WPA-PSK" || sectype=="WPA2-PSK" || sectype=="WPA/WPA2-PSK"){
			document.write(ca_15a_passphrase+":&nbsp;");
			document.write(passwd_phrase+"</td></tr>");
		}else
			document.write("</td></tr>");
		// line 4
		document.write('<tr>');
/*		if(ap_sectype=="WEP"){
			document.write(hd+spacebar);document.write(ca_12a_passphrase); document.write(':&nbsp;');
			document.write('$sta_wl_weppassphrase</td>');
		}else
			document.write("<td></td>");
*/
		if(sectype=="WEP"){
			document.write(hd);document.write(spacebar);document.write(ca_12a_passphrase); document.write(':&nbsp;');
			document.write('$weppassphrase</td></tr>');
		}else
			document.write("<td></td></tr>");
		// line 5
		document.write('<tr>');
/*		if(ap_sectype=="WEP"){
			document.write(hd+spacebar);document.write(sec_key1);
			document.write('$ap_wl_key1</td>');
		}else
			document.write("<td></td>");
*/
		if(sectype=="WEP"){
			document.write(hd);document.write(spacebar);document.write(sec_key1);
			document.write('$wl_key1</td></tr>');
		}else
			document.write("<td></td></tr>");
		// line 6
		document.write('<tr>');
/*		if(ap_sectype=="WEP"){
			document.write(hd+spacebar);document.write(sec_key2);
			document.write('$ap_wl_key2</td>');
		}else
			document.write("<td></td>");
*/
		if(sectype=="WEP"){
			document.write(hd);document.write(spacebar);document.write(sec_key2);
			document.write('$wl_key2</td></tr>');
		}else
			document.write("<td></td></tr>");
		// line 7
		document.write('<tr>');
/*		if(ap_sectype=="WEP"){
			document.write(hd+spacebar);document.write(sec_key3);
			document.write('$ap_wl_key3</td>');
		}else
			document.write("<td></td>");
*/
		if(sectype=="WEP"){
			document.write(hd);document.write(spacebar);document.write(sec_key3);
			document.write('$wl_key3</td></tr>');
		}else
			document.write("<td></td></tr>");
		// line 8
		document.write('<tr>');
/*		if(ap_sectype=="WEP"){
			document.write(hd+spacebar);document.write(sec_key4);
			document.write('$ap_wl_key4</td>');
		}else
			document.write("<td></td>");
*/
		if(sectype=="WEP"){
			document.write(hd);document.write(spacebar);document.write(sec_key4);
			document.write('$wl_key4</td></tr>');
		}else
			document.write("<td></td></tr>");
	</script>
	<tr><td>&nbsp;&nbsp;</td></tr>
	<tr><td><img src="/WZC.JPG"></td></tr>
	<script>document.write(bluebar)</script>
<tr><td>
<script>document.write('<input type="button" name="continue" value="'+ca_next_mark+'" onClick="url_change_ornot();">');</script></td>
</tr>
</table>
</div><!-- end summary -->
</BODY>
</HTML>
EOF
}

print_top_refresh () # $1: page to be refresh, $2: delay_time
{
        local delay_time
	local lang_ori="English French Italian German"

        delay_time="$2"
        [ "x$delay_time" = "x" ] && delay_time="0"

flag=0
realArray=0
for name in $lang_ori;do
	if [ "$GUI_Region" = "$name" ];then
		realArray=$flag
                break
        fi
        flag=$(($flag+1))
done

print_cgi_header "text/html"
cat <<EOF
<HTML>
<HEAD>  <meta http-equiv="Refresh" content="$delay_time; url=$1">
<link rel="stylesheet" href="/form.css">
EOF
	echo "<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>"
	print_language_js
cat <<EOF
</HEAD>
<STYLE type=text/css>BODY {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; BACKGROUND: #ffffff; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px

}
</STYLE>
<script>language_showArray=lang_ori.split(" ");</script>
<BODY bgcolor=#ffffff marginwidth="0" marginheight="0">
<table width=100% border=0 cellpadding="0" cellspacing="3">
  <tr><td colspan="2"><IMG height=12 src="/darkblue.gif" width="100%" border=1></td></tr>
  <tr>
    	<td rowspan="4" width=85%><IMG alt="NETGEAR Access Point Settings" hspace=0 src="/settings.jpg" align=top border=0></td>
  </tr>
  <tr>
	<td><script>document.write(select_language)</script></td>
  </tr>
  <tr>
    <td>
        <select name="lang_avi" size=1 disabled>
          <script>document.write('<option>'+language_showArray[$realArray]+'</option>');</script> 
  </td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<img src="/spacer.gif" width="25" height="18" border="0" alt="" /><script>document.write('<input type="submit"  value="'+apply_mark+'" disabled>&nbsp;&nbsp;')</script></td>
  </tr>
</table>
</BODY>
</HTML>
EOF
}
print_catop_refresh () # $1: page to be refresh, $2: delay_time
{
        local delay_time

        delay_time="$2"
        [ "x$delay_time" = "x" ] && delay_time="0"

print_cgi_header "text/html"
cat <<EOF
<HTML>
<HEAD>  <meta http-equiv="Refresh" content="$delay_time; url=$1">
<link rel="stylesheet" href="/form.css">
EOF
	echo "<META http-equiv='Content-Type' content='text/html; charset=$(print_charset)'>"
	print_language_js
cat <<EOF
</HEAD>
<STYLE type=text/css>BODY {
	PADDING-RIGHT: 0px; PADDING-LEFT: 0px; BACKGROUND: #ffffff; PADDING-BOTTOM: 0px; MARGIN: 0px; PADDING-TOP: 0px

}
</STYLE>
<BODY bgcolor=#ffffff marginwidth="0" marginheight="0">
<table width=100% border=0 cellpadding="0" cellspacing="3">
  <tr><td colspan="2"><IMG height=12 src="/darkblue.gif" width="100%" border=1></td></tr>
  <tr>
  <script>
    if( "$GUI_Region " == "English" )
    {
    document.write('<td rowspan="3" width=85%><IMG alt="NETGEAR Access Point Settings" hspace=0 src="/ca_settings.jpg" align=top border=0></td>')
     }
    else
    {
      document.write('<td rowspan="3" width=85%><IMG alt="NETGEAR Access Point Settings" hspace=0 src="/ca_settings.jpg" align=top border=0></td>')
     }
  </script>
	<td><script>document.write(select_language)</script></td>
  </tr>
  <script>
var language_list="1 2 3";
function languageShowlist()
{
	language_oriArray=lang_ori.split(" ");
	if ( language_list != "" )
	{
		language_nowArray=language_list.split(" ");
		for ( i=0; i<language_nowArray.length; i++ )
		{
			for ( j=0; j<language_oriArray.length; j++)
			{
				if ( language_nowArray[i] == parseInt(j+1) )
				{
					document.write('<option value='+j+'>'+language_oriArray[j]+'</option>');
					break;
				}	
			}
		}	
	}
	else
		document.write('<option value=English>'+language_oriArray[0]+'</option>');
}
</script>
  <tr>
    <td>
        <select name="lang_avi" size=1 disabled>
         <script>languageShowlist();</script>  
  </td>
  </tr>
  <tr>
    <td>&nbsp;&nbsp;<img src="/spacer.gif" width="25" height="18" border="0" alt="" /><script>document.write('<input type="submit"  value="'+apply_mark+'" disabled>&nbsp;&nbsp;')</script></td>
  </tr>
</table>
</BODY>
</HTML>
EOF
}
print_http_footer()
{
	echo "</body>"
	echo "</html>"
	if [ -f /tmp/lock_refreshpage ];then
		sleep 2
		rm /tmp/lock_refreshpage
		rm /tmp/lock_refreship
	fi
}
show_charset()
{
    if [ "$Enable_GUIStringTable" = 1 -a "x$GUI_Region" != "x" ];then
        case "$GUI_Region" in
            English)
                echo -n "iso-8859-1"
                ;;
            German)
                echo -n "iso-8859-1"
                ;;
            Japanese)
                echo -n "Shift_JIS"
                ;;
            Chinese)
                echo -n "GB2312"
                ;;
            *)
                echo -n "iso-8859-1"
                ;;
            esac
    else
        echo -n "iso-8859-1"
    fi
}
show_src()
{
	local language_region
	if [ "$Enable_GUIStringTable" = 1 -a "x$GUI_Region" != "x" ];then
        	if [ "$GUI_Region" != "English" ];then
			if [ -f /www/html/cherry_test/languages_nonEnglish.js ];then
                        	language_region=$(cat /tmp/multi_lang/language_region)
                        	language_region=$(echo -n $language_region)
                        	if [  "$GUI_Region" = "$language_region" ];then
					echo -n "/cherry_test/languages_nonEnglish.js"
                        	else
					echo -n "/languages.js"
				fi
			else
				echo -n "/languages.js"
			fi
        	else
            		echo -n "/languages.js"
        	fi
    	else
        	echo -n "/languages.js"
    	fi
}
print_http_footer_wait()
{
	echo "</body>"
	echo "</html>"
}

print_http_footer_show()
{
        echo "</html>"
	if [ -f /tmp/lock_show_refreshpage ];then
		sleep 2
		rm /tmp/lock_show_refreshpage
	fi
}
		

show_en_dis() #$1: 1--enable 0--disable
{
    [ "$1" = "1" ] && echo -n $r_enable || echo -n $r_disable
}

show_yes_no()
{
     [ "$1" = "1" ] && echo -n $r_no || echo -n $r_yes
}
radio_check()
{
    [ "$1" = "$2" ] && echo -n CHECKED
}
enabled_check()
{
    [ "$1" = "$2" ] || echo -n DISABLED
}

select_check()
{
    [ "$1" = "$2" ] && echo -n SELECTED
}

get_wanif() #$1: wan proto
{
	local wan_if=$($nvram get wan_ifname)
	if [ "$1" = "pppoe" -o "$1" = "pptp" -o "$1" = "l2tp" ]; then
		wan_if=ppp0
	fi
	echo -n $wan_if
}

get_dns() #$1: 1 or 2
{
	local dns_file=/tmp/resolv.conf
	local local_tmp_file=/tmp/ABCDEFXXXX
	local dns_addr
	
	[ -f $dns_file ] && cat $dns_file | grep ^nameserver | sed 's/nameserver//g' > $local_tmp_file
	dns_addr=$(sed ''"$1"'p' -n $local_tmp_file)
	echo -n $dns_addr
}
