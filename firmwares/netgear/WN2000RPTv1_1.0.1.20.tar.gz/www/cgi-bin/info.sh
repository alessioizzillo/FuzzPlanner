show_mode()
{
        case "$1" in
                3)
                        echo -n "<script>document.write(wlan_mode_300)</script>"
                ;;
                2)
                        echo -n "<script>document.write(wlan_mode_145)</script>"
                ;;
                1)
                        echo -n "<script>document.write(wlan_mode_54)</script>"
                ;;
        4)
            echo -n "<script>document.write(wlan_mode_300)</script>"
                ;;
        5)
            echo -n "<script>document.write(wlan_mode_300)</script>"
                ;;
                *)
                        echo -n "<script>document.write(wlan_mode_54)</script>"
                ;;
        esac
}
show_on_off()
{
        case "$1" in
                0)
                        echo -n "<script>document.write(off_mark)</script>"
                        ;;
                1)
                        echo -n "<script>document.write(on_mark)</script>"
                        ;;
                *)
                        echo -n "<script>document.write(off_mark)</script>"
                        ;;
        esac
}
show_wps()
{
        case "$1" in
                1)
                        echo -n "<script>document.write(not_configured)</script>"
                ;;
                5)
                        echo -n "<script>document.write(configured)</script>"
                ;;
                *)
                        echo -n "<script>document.write(not_configured)</script>"
                ;;
        esac
}
show_region() #$1: country number
{
    case "$1" in
        0)
            echo -n "<script>document.write(coun_af)</script>"
            ;;
        1)
            echo -n "<script>document.write(coun_as)</script>"
            ;;
        2)
            echo -n "<script>document.write(coun_au)</script>"
            ;;
        3)
            echo -n "<script>document.write(coun_ca)</script>"
            ;;
        4)
            echo -n "<script>document.write(coun_eu)</script>"
            ;;
        5)
                echo -n "<script>document.write(coun_is)</script>"
            ;;
        6)
            echo -n "<script>document.write(coun_jp)</script>"
            ;;
        7)
            echo -n "<script>document.write(coun_ko)</script>"
            ;;
                8)
            echo -n "<script>document.write(coun_mx)</script>"
            ;;
        9)
            echo -n "<script>document.write(coun_sa)</script>"
            ;;
        10)
            echo -n "<script>document.write(coun_us)</script>"
            ;;

        11)
	    echo -n "<script>document.write(coun_me)</script>"
	    ;;
	*)    
	    echo -n "<script>document.write(coun_eu)</script>"
            ;;
    esac
}

show_enc()
{
    case "$1" in
        2)
            echo -n "<script>document.write(r_wep)</script>"
            ;;
        3)
            echo -n "<script>document.write(r_wpa)</script>"
            ;;
        4)
            echo -n "<script>document.write(r_wpa2)</script>"
            ;;
        5)
            echo -n "<script>document.write(r_wpas)</script>"
            ;;
        *)
            echo -n "<script>document.write(r_off)</script>"
            ;;
    esac
}
show_channel() #$1 for info_get_channel, $2 for gmode
{
	local pri_channel sec_channel tmp_channel
	if [ "$2" -eq 3 -o "$2" -eq 4 -o "$2" -eq 5 ];then	
                if [ "$1" = 0 ];then
			tmp_channel=$(iwlist ath0 channel | grep "Frequency" | awk '/Channel/{print $5}' | awk -F"\)" '{print $1}')
		else
			tmp_channel=$1
		fi
		if [ "x$tmp_channel" != "x" ];then
			if [ "$tmp_channel" -le 6 ];then
				pri_channel=$tmp_channel
				sec_channel=$(($tmp_channel+4))
			else
				pri_channel=$tmp_channel
				sec_channel=$(($tmp_channel-4))
			fi	
			echo -n "$pri_channel(p) + $sec_channel(s)"		
		else
			echo -n "--"
		fi
	else
		if [ "$1" = 0 ];then
			tmp_channel=$(iwlist ath0 channel | grep "Frequency" | awk '/Channel/{print $5}' | awk -F"\)" '{print $1}')
			if [ "x$tmp_channel" != "x" ];then
				echo -n "auto($tmp_channel)"
			else
				echo -n "--"
			fi
		else
			echo -n "$1"
		fi
	fi	
}

show_channel_new() #$1 for info_get_channel, $2 for gmode
{
	local pri_channel sec_channel tmp_channel mode
	wlan_mode=$(iwpriv ath0 get_mode | awk -F: '{print $2}' )
	tmp_channel=$(iwlist ath0 channel | grep "Frequency" | awk '/Channel/{print $5}' | awk -F"\)" '{print $1}')
	if [ "x$tmp_channel" != "x" ];then
		if [ "$wlan_mode" = "11ng40-" ];then
			pri_channel=$tmp_channel
			sec_channel=$(($tmp_channel-4))
			echo -n "$pri_channel(p) + $sec_channel(s)"
		elif [ "$wlan_mode" = "11ng40+" ];then
			pri_channel=$tmp_channel
			sec_channel=$(($tmp_channel+4))
			echo -n "$pri_channel(p) + $sec_channel(s)"
		else
			if [ "$1" = 0 ];then
				echo -n "auto($tmp_channel)"
			else
				echo -n "$tmp_channel"
			fi
		fi
	else
		if [ "$1" = 0 ];then
			echo -n "--"
		else
			echo -n "$1"
		fi
	fi
}
config_show_statistic()
{
	$nvram set timereset="$1"
}
