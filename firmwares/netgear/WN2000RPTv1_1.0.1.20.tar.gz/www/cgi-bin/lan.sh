config_lan() #$1: lan ip, $2:lan netmask, $3:lan dhcp mode, $4:dhcp ip start, $5:dhcp ip end,  $6:network_flag $7:ip_flag $8:network $9:dmz_ip ${10{:bs_trustedip $13:network2_flag, if lan ip is not changed, and subnet is changed.
{
	endis_wl_radio=$($nvram get endis_wl_radio)
	wds_endis_fun=$($nvram get wds_endis_fun)
	wds_repeater_basic=$($nvram get wds_repeater_basic)
	if [ $endis_wl_radio -eq 1 -a $wds_endis_fun -eq 1 -a $wds_repeater_basic -eq 0 ];then
		$nvram set repeater_ip=$1
	else
		$nvram set lan_ipaddr=$1
	fi
	$nvram set lan_netmask=$2
	if [ "$3" = "1" ];then
		$nvram set lan_dhcp=1
		$nvram set dhcp_start=$4
		$nvram set dhcp_end=$5
	else
		$nvram set lan_dhcp=0
	fi
	if [ "$6" = "1" ];then
		for file in `ls /tmp/configs | grep forwarding | grep -v ^size`
		do
			 new_info=`sed "s/[0-9]*\.[0-9]*\.[0-9]*/$8/" /tmp/configs/$file`
			 $nvram set $file="$new_info"
		done
		for file in `ls /tmp/configs | grep triggering | grep -v ^size`
		do
			 new_info=`sed "s/[0-9]*\.[0-9]*\.[0-9]*/$8/" /tmp/configs/$file`
			 $nvram set $file="$new_info"
		done
		for file in `ls /tmp/configs | grep reservation | grep -v ^size`
		do
			 new_info=`sed "s/[0-9]*\.[0-9]*\.[0-9]*/$8/" /tmp/configs/$file`
			 $nvram set $file="$new_info"
		done
		for file in `ls /tmp/configs | grep block_services | grep -v ^size`
		do
			 new_info=`sed "s/[0-9]*\.[0-9]*\.[0-9]*/$8/g" /tmp/configs/$file`
			 $nvram set $file="$new_info"
		done		
		$nvram set dmz_ipaddr="$9"
		$nvram set block_trustedip="${10}"
	fi
	if [ "x${11}" = "x" ];then
		$nvram set rip_version=0
        $nvram set rip_direction=0
	else
		$nvram set rip_version=${11}
		$nvram set rip_direction=${12}
	fi
	if [ "${14}" = "1" ];then
		rm -f /tmp/configs/forwarding*
		rm -f /tmp/configs/triggering*
		rm -f /tmp/configs/reservation*
		rm -f /tmp/configs/block_services*
	fi
	$nvram set netbiosname="${13}"
	$nvram set forfirewall="lan_setup"
}
