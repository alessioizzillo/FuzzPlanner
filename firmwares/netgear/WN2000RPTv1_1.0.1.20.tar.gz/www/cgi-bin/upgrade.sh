#!/bin/sh

chmod a+x /tmp/upgrade.sh
. /tmp/upgrade.sh
