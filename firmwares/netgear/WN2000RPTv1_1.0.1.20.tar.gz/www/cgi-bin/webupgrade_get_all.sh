#!/bin/sh
. /www/cgi-bin/functions.sh
. /www/cgi-bin/webupgrade.sh
. /www/cgi-bin/change_language.sh

#init download status
write_webupgrade_status_of_download_language_table $STATUS_INITIALIZING
write_webupgrade_status_of_download_language_table $STATUS_0_PERCENT

#download language table
get_ctl_file_language_table_parameters $CTL_FILE_CLN 
#/www/cgi-bin/dl_ratio.cgi "$g_language_table_size" "$LANGUAGE_TABLE_FILE" &
check_webupgrade_cancelled_in_download_language_table
oc rm -f $LANGUAGE_TABLE_FILE
if ! oc /bin/snarf "$NETGEAR_SITE_1$g_language_table_path" "$LANGUAGE_TABLE_FILE"; then
	check_webupgrade_cancelled_in_download_language_table
	echo "2" > /tmp/language_change_status # 1: No Internet Connection 2: Download failed
	giveup_webupgrade_in_download_language_table $STATUS_DOWNLOAD_ERROR
fi
#/usr/bin/killall dl_ratio.cgi
lang_md5_com=`md5sum $LANGUAGE_TABLE_FILE`
lang_md5=`echo $lang_md5_com | awk '{print tolower($1)}'`
if [ "$g_language_table_md5" != "$lang_md5" ];then
        echo "md5 checksum error!" > /dev/console
        echo "2" > /tmp/language_change_status
fi
check_webupgrade_cancelled_in_download_language_table

/bin/mv $LANGUAGE_TABLE_FILE $PRE_LANGUAGE_TABLE
language_table_upgrade

#download img
get_ctl_file_image_parameters $CTL_FILE_CLN
/www/cgi-bin/dl_ratio.cgi "$g_image_file_size" "$IMAGE_FILE" &
check_webupgrade_cancelled_in_download_image_file
if ! oc /bin/snarf "$NETGEAR_SITE_1$IMG_FILENAME$g_image_file_path" "$IMAGE_FILE"; then
        check_webupgrade_cancelled_in_download_image_file
        /usr/bin/killall dl_ratio.cgi
        giveup_webupgrade_in_download_image_file $STATUS_DOWNLOAD_ERROR
fi
/usr/bin/killall dl_ratio.cgi

check_webupgrade_cancelled_in_download_image_file
oc /usr/sbin/nvram set auto_upgrade_flag=1

img_md5_com=`md5sum $IMAGE_FILE`
img_md5=`echo $img_md5_com | awk '{print tolower($1)}'`
if [ $img_md5 != $g_image_md5 ]; then
	echo "md5 checksum error" > /dev/console
	giveup_webupgrade_in_imginstall $STATUS_MD5_CHECK_ERROR
fi

write_webupgrade_status_of_download_image_file $STATUS_100_PERCENT
write_webupgrade_status_of_download_image_file $STATUS_FINISH

