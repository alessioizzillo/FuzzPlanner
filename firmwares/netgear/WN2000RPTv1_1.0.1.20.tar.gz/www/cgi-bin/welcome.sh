config_welcome()
{
	#$nvram set internet_type="$1"
	$nvram set dns_hijack="0"
}

config_welcome_adva_hijack()
{
	$nvram set wl_country="$1"
	$nvram set wl_country_code="${1}"
}

config_welcome_adva_nohijack()
{
	$nvram set dns_hijack=0
	$nvram set endis_wl_radio=1
	$nvram set view_wizard="0"
	$nvram set after_welcome="1"
}

config_countryset()
{
    $nvram set wl_country="${1}"
	$nvram set wl_country_code="${1}"
}

config_wl_mode()
{
    $nvram set wl_simple_mode="${1}"
}

config_same_sec()
{
	$nvram set wl_same_sec="$1"
}
