config_mode()
{
	$nvram set wl_simple_mode=$1
}
config_wlan() #$1:ssid $2:broadcast 1--enable 0--disable
              #$3:country 0~11 
              #$4:channel $5:mode 0--b 1--auto 2--g $6:rate 0~12
{
    $nvram set wl_ssid="$1"
	current_channel=$($nvram get wl_hidden_channel)
		if [ $2 -eq 3 ];then
            if [ $current_channel -gt 4 ];then
                $nvram set wl_simple_mode="5"
			else
				$nvram set wl_simple_mode=$2
            fi
		else
			$nvram set wl_simple_mode=$2
        fi
   
    if [ $2 -eq 4 ];then
    	$nvram set endis_xr=0
    fi
	#Up to 300Mbps, Europe, channel is larger than 7, set wl_simple_mode to 5
	#if [ $2 -eq 4 -a $4 -eq 3 ];then
	#	if [ $3 -gt 7 ];then
	#		$nvram set wl_simple_mode="5"
	#	fi
	#fi
	#UP to 300Mbps, channel is larger than 6, set wl_simple_mode to 5; channel is Auto, set wl_simple_mode to 6
        #if [ $2 -eq 3 ];then
                #if [ $3 -gt 6 ];then
                        #$nvram set wl_simple_mode="5"
                #elif [ $3 -eq 0 ];then
                        #$nvram set wl_simple_mode="6"
                #fi
        #fi
	$nvram set wps_status=5
#	$nvram set ap_mode=$3
#	if [ "x${3}" = "x" ];then
#   	$nvram set ap_client=0
#   fi
	$nvram set sta_wl_ssid="$5"
#	$nvram set wl_same_sec=$4
#	if [ "x${4}" = "x" ];then
#   		$nvram set wl_same_sec=0
#    	fi

	$nvram set wl_country=$6

}

config_wlan_cl()
{
	$nvram set ap_mode="$1"
}

config_ssid_same()
{
	$nvram set wl_ssid="$1"  
	if [ "x$2" != "x" ];then
		$nvram set wl_same_sec="$2"
	fi
}

config_temp_ssid_same()
{
	$nvram set wl_temp_ssid="$1"
}

config_ca_wlan()
{  
    $nvram set sta_wl_ssid="$1"	
	$nvram set wl_channel="$2"	
	$nvram set wl_hidden_channel="$2"	
	wl_simple_mode=$($nvram get wl_simple_mode)
	if [ $wl_simple_mode -eq 3 ];then
	    if [ $2 -gt 4 ];then
	        $nvram set wl_simple_mode="5"
	    fi
	elif [ $wl_simple_mode -eq 5 ];then
		if [ $2 -le 4 ];then
	        $nvram set wl_simple_mode="3"
	    fi
	fi
}

config_ca_status()
{
	# this value continue_ca_settings is used in welcome.html
	# $1 = ap_settings : next page is ca_ap_settings.html
	# $1 = summery_show : next page is ca_summery.html
	# $1 = connect_status : next page is ca_connect_rightpage.html
	$nvram set continue_ca_settings="$1" 
}

config_refresh_url()
{
	$nvram set refresh_url="$1"	
	$nvram set refresh_page="$2"
}

config_finish_url(){
	$nvram set ca_finish="$1"
	$nvram set configured="$1"
	if [ $1 = 1 ];then
		echo 0 > /proc/sys/net/ipv4/dns_hijack
	fi
	$nvram set dns_hijack="$2"
}

config_wizard()
{
        #$1 1:from index. 0: from ca

        $nvram set set_from_index="$1"

}

config_hidden_wlan()
{
	$nvram set ap_client="$1"
	$nvram set wl_ssid="$2"
	$nvram set wl_hidden_channel="$3"
	$nvram set wl_simple_mode="$4"

        if [ $4 -eq 3 ];then
            if [ $3 -gt 4 ];then
                $nvram set wl_simple_mode="5"
            fi
        fi
}
config_hidd_wlan()
{
	$nvram set dis_wizd="$1"
	$nvram set wl_hidden_channel="$2"
	$nvram set wl_simple_mode="$3"
	$nvram set hidden_wlan_ca="$4"
	$nvram set ap_client="$5"

        if [ $3 -eq 3 ];then
            if [ $2 -gt 4 ];then
                $nvram set wl_simple_mode="5"
            fi
        fi
}
