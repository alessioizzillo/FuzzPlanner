config_wladv() 
{
    $nvram set ap_mode=$1
    $nvram set endis_ssid_broadcast=$2
    $nvram set endis_pin=$3
	$nvram set wps_status=$4
}
