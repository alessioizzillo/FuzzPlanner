#!/bin/sh
insmod /lib/modules/2.6.15/io/keypad.ko
